@javax.xml.bind.annotation.XmlSchema(namespace =
                                     "http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/ListFiles_Input",
                                     elementFormDefault =
                                     javax.xml.bind.annotation.XmlNsForm.QUALIFIED) package com.oracle.xmlns.iesn_batchfileadapter_27xapplication1.test.listfiles_input;

