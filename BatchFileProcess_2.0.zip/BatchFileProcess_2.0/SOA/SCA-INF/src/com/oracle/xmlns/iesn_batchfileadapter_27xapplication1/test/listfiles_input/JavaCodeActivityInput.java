
package com.oracle.xmlns.iesn_batchfileadapter_27xapplication1.test.listfiles_input;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for javaCodeActivityInput complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="javaCodeActivityInput"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="rootPath" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="fileExtensions" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "javaCodeActivityInput", propOrder = { "rootPath", "fileExtensions" })
public class JavaCodeActivityInput {

    @XmlElement(required = true)
    protected String rootPath;
    protected String[] fileExtensions;

    /**
     * Gets the value of the rootPath property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getRootPath() {
        return rootPath;
    }

    /**
     * Sets the value of the rootPath property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setRootPath(String value) {
        this.rootPath = value;
    }


    public void setFileExtensions(String[] fileExtensions) {
        this.fileExtensions = fileExtensions;
    }

    public String[] getFileExtensions() {
        return fileExtensions;
    }

}
