package CommonProcesses.listFiles;

import com.oracle.xmlns.iesn_batchfileadapter_27xapplication1.test.listfiles_input.JavaCodeActivityInput;
import com.oracle.xmlns.iesn_batchfileadapter_27xapplication1.test.listfiles_input.JavaCodeActivityOutput;
import com.oracle.xmlns.iesn_batchfileadapter_27xapplication1.test.listfiles_input.ObjectFactory;

import org.apache.commons.beanutils.BeanUtilsBean;

public class listFilesInFolders_Sub extends listFilesInFolders implements IlistFilesInFolders {
    public listFilesInFolders_Sub() {
        super();
    }
    
    public JavaCodeActivityOutput invoke(JavaCodeActivityInput input)

        {
        JavaCodeActivityOutput output=null;
        try {
            BeanUtilsBean.getInstance().copyProperties(input, this);
           
            invoke();
             
            ObjectFactory factory = new ObjectFactory();
            
            output = factory.createJavaCodeActivityOutput();
            BeanUtilsBean.getInstance().copyProperties(this,output );

        } catch (Exception e) {
            e.printStackTrace();
        }
        return output;
    }

}
