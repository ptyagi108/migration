package CommonProcesses.listFiles;

import com.oracle.xmlns.iesn_batchfileadapter_27xapplication1.test.listfiles_input.JavaCodeActivityInput;
import com.oracle.xmlns.iesn_batchfileadapter_27xapplication1.test.listfiles_input.JavaCodeActivityOutput;

public interface IlistFilesInFolders{

JavaCodeActivityOutput invoke(JavaCodeActivityInput obj);
}
