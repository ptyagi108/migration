@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/IESN_BatchFileAdapter_27X/inBoundBatchFileAdapter/listFiles/InFolders_input", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.iesn_batchfileadapter_27x.inboundbatchfileadapter.listfiles.infolders_input;
