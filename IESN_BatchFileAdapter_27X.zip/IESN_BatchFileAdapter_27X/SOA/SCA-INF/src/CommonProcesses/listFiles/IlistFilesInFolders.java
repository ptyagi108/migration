

package CommonProcesses.listFiles;

import com.oracle.xmlns.iesn_batchfileadapter_27x.inboundbatchfileadapter.listfiles.infolders_input.JavaCodeActivityInput;
import com.oracle.xmlns.iesn_batchfileadapter_27x.inboundbatchfileadapter.listfiles.infolders_output.JavaCodeActivityOutput;

public interface IlistFilesInFolders{

JavaCodeActivityOutput invoke(JavaCodeActivityInput obj);
}
