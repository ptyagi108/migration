package mapper;

import java.util.Map;

/**
 * Created by Manoj_Mehta on 3/29/2017.
 */
public class MigrationMapper
{
    private String tibcoComponent;
    private String soaComponent;
    Map<String,String> tibcoToSAOmapper;


    private final String TIBCO_File_PollerActivity="FileEventSource";
    private final String TIBCO_List_FilesActivity="ListFilesActivity";
    private final String TIBCO_FTP_Put="FTPPutActivity";


    private final String SOA_FilePoller="FilePoller";
    private final String SOA_ListFiles="ListFiles";
    private final String SOA_FTP_Put="FTPPut";

    public MigrationMapper() {
        tibcoToSAOmapper.put(TIBCO_File_PollerActivity,SOA_FilePoller);
        tibcoToSAOmapper.put(TIBCO_List_FilesActivity,SOA_ListFiles);
        tibcoToSAOmapper.put(TIBCO_FTP_Put,SOA_FTP_Put);
    }

    public String getSOAComponent(String tibcoComponent)
    {

        if(tibcoToSAOmapper.containsKey(tibcoComponent))
        {
            return tibcoToSAOmapper.get(tibcoComponent);
        }
        else
        {
            return "No Mapping Found";
        }
    }
}
