package soa.output;

import oracle.migrationtool.parser.model.JCDDocument;
import oracle.migrationtool.parser.model.Reference;
import oracle.migrationtool.parser.model.Service;


public class JMSWSDLJCAGeneratorForSpring
{
  public static String buildJMSWSDL(String name, String tns, String target)
  {
    StringBuffer buffer = new StringBuffer();





    buffer.append("   <wsdl:definitions \n");
    buffer.append("\t     name=\"" + name + "\"\n");
    buffer.append("\t     targetNamespace=\"" + tns + "\"\n");
    buffer.append("\t     xmlns:jca=\"http://xmlns.oracle.com/pcbpel/wsdl/jca/\"\n");
    buffer.append("\t     xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\"\n");
    buffer.append("\t     xmlns:tns=\"" + tns + "\"\n");
    buffer.append("\t     xmlns:opaque=\"http://xmlns.oracle.com/pcbpel/adapter/opaque/\"\n");
    buffer.append("\t     xmlns:plt=\"http://schemas.xmlsoap.org/ws/2003/05/partner-link/\"\n");
    buffer.append("\t    >\n");
    buffer.append("\t  <plt:partnerLinkType name=\"" + target + "_plt\" >\n");
    buffer.append("\t    <plt:role name=\"" + target + "_role\" >\n");
    buffer.append("\t      <plt:portType name=\"tns:" + target + "_ptt\" />\n");
    buffer.append("\t    </plt:role>\n");
    buffer.append("\t  </plt:partnerLinkType>\n");
    buffer.append("\t    <wsdl:types>\n");
    buffer.append("\t    <schema targetNamespace=\"http://xmlns.oracle.com/pcbpel/adapter/opaque/\"\n");
    buffer.append("\t            xmlns=\"http://www.w3.org/2001/XMLSchema\" >\n");
    buffer.append("\t      <element name=\"opaqueElement\" type=\"base64Binary\" />\n");
    buffer.append("\t    </schema>\n");
    buffer.append("\t    </wsdl:types>\n");
    buffer.append("\t    <wsdl:message name=\"" + target + "_msg\">\n");
    buffer.append("\t        <wsdl:part name=\"opaque\" element=\"opaque:opaqueElement\"/>\n");
    buffer.append("\t    </wsdl:message>\n");
    buffer.append("\t    <wsdl:portType name=\"" + target + "_ptt\">\n");
    buffer.append("\t        <wsdl:operation name=\"" + target + "\">\n");
    buffer.append("\t            <wsdl:input message=\"tns:" + target + "_msg\"/>\n");

    buffer.append("\t        </wsdl:operation>\n");
    buffer.append("\t    </wsdl:portType>\n");
    buffer.append("\t</wsdl:definitions>\n");

    return buffer.toString();
  }






  public static String getJMSInConsume_Message_pttJCA(Service service, JCDDocument jcdDoc)
  {
    String destination = service.getDestination();
    String messageSelector = service.getMessageSelector();




    StringBuffer buffer = new StringBuffer();
    buffer.append("<adapter-config name=\"" + service.getServiceName() + "\" adapter=\"JMS Adapter\" wsdlLocation=\"" + service.getServiceName() + ".wsdl\"\n");


    buffer.append("    xmlns=\"http://platform.integration.oracle/blocks/adapter/fw/metadata\">\n");
    buffer.append("<connection-factory UIJmsProvider=\"THIRDPARTY\" location=\"eis/Jms/JmsAdapter\"/>\n");
    buffer.append("<endpoint-activation portType=\"Consume_Message_ptt\"\n");
    buffer.append("\t\t\t\t\t\t\toperation=\"Consume_Message\">\n");
    buffer.append("\t<activation-spec className=\"oracle.tip.adapter.jms.inbound.JmsConsumeActivationSpec\">\n");
    buffer.append("\t\t\t  <property name=\"PayloadType\" value=\"TextMessage\"/>\n");
    if (messageSelector != null)
      buffer.append("\t\t\t  <property name=\"MessageSelector\" value=\"" + messageSelector + "\"/>\n");
    buffer.append("\t  <property name=\"UseMessageListener\" value=\"false\"/>\n");
    buffer.append("\t  <property name=\"DestinationName\" value=\"" + destination + "\"/>\n");
    buffer.append("\t</activation-spec>\n");
    buffer.append("\t</endpoint-activation>\n");
    buffer.append("</adapter-config>\n");
    return buffer.toString();
  }



  public static String getJMSOutProduce_Message_pttJCA(Reference reference, String jcdName)
  {
    String destination = reference.getDestination();



    StringBuffer buffer = new StringBuffer();
    buffer.append("<adapter-config name=\"" + reference.getReferenceName() + "\" adapter=\"JMS Adapter\" wsdlLocation=\"" + reference.getReferenceName() + ".wsdl\"\n");


    buffer.append("    xmlns=\"http://platform.integration.oracle/blocks/adapter/fw/metadata\">\n");
    buffer.append("\t\t<connection-factory UIJmsProvider=\"THIRDPARTY\" location=\"eis/Jms/JmsAdapter\"/>\n");
    buffer.append("\t\t<endpoint-interaction portType=\"Produce_Message_ptt\"\n");
    buffer.append("            operation=\"Produce_Message\">\n");
    buffer.append("\t\t <interaction-spec className=\"oracle.tip.adapter.jms.outbound.JmsProduceInteractionSpec\">\n");
    buffer.append("\t\t\t<property name=\"TimeToLive\" value=\"0\"/>\n");
    buffer.append("\t\t\t<property name=\"PayloadType\" value=\"TextMessage\"/>\n");
    buffer.append("\t\t\t<property name=\"DeliveryMode\" value=\"Persistent\"/>\n");
    buffer.append("\t\t\t<property name=\"DestinationName\" value=\"" + destination + "\"/>\n");
    buffer.append("\t\t </interaction-spec>\n");
    buffer.append("\t\t</endpoint-interaction>\n");
    buffer.append("</adapter-config>\n");
    return buffer.toString();
  }


  public static String buildCAPSJMSWSDL()
  {
    StringBuffer buffer = new StringBuffer();

    buffer.append("<definitions xmlns=\"http://schemas.xmlsoap.org/wsdl/\"\n");
    buffer.append("\t\t\txmlns:varprop=\"http://docs.oasis-open.org/wsbpel/2.0/varprop\"\n");
    buffer.append("\t\t\txmlns:ewaytype=\"http://xml.netbeans.org/schema/eWayTypes\"\n");
    buffer.append("\t\t\txmlns:opaque=\"http://xmlns.oracle.com/pcbpel/adapter/opaque/\"\n");
    buffer.append("\t\t\txmlns:eways=\"urn:seebeyond:wsdl:extension:binding:eways\"\n");
    buffer.append("\t\t\txmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\"\n");
    buffer.append("\t\t\txmlns:sbynpx=\"http://bpel.seebeyond.com/hawaii/5.0/privateExtension/\"\n");
    buffer.append("\t\t\txmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:otdjce=\"tns\"\n");
    buffer.append("             xmlns:plink=\"http://docs.oasis-open.org/wsbpel/2.0/plnktype\"\n");
    buffer.append("             xmlns:tns=\"urn:jmsservice\" targetNamespace=\"urn:jmsservice\"\n");
    buffer.append("             name=\"JMS\">\n");
    buffer.append("    <types>\n");
    buffer.append("        <schema targetNamespace=\"http://xml.netbeans.org/schema/eWayTypes\"\n");
    buffer.append("                xmlns=\"http://www.w3.org/2001/XMLSchema\">\n");
    buffer.append("            <element name=\"Message\" type=\"string\"/>\n");
    buffer.append("        </schema>\n");
    buffer.append("        <schema targetNamespace=\"http://xmlns.oracle.com/pcbpel/adapter/opaque/\"\n");
    buffer.append("                xmlns=\"http://www.w3.org/2001/XMLSchema\">\n");
    buffer.append("            <element name=\"Message\" type=\"base64Binary\"/>\n");
    buffer.append("            <element name=\"empty\">\n");
    buffer.append("            \t\t<complexType/>\n");
    buffer.append("            </element>\n");
    buffer.append("        </schema>\n");
    buffer.append("    </types>\n");
    buffer.append("    <message name=\"Message\">\n");
    buffer.append("        <part name=\"Message\" element=\"ewaytype:Message\"/>\n");
    buffer.append("        <!-- This is opaque message type, comment out Message part defined above \n ");
    buffer.append("\t\t\t\t\tand uncomment following Message part to use opaque message type\n\t\t\t<part name=\"Message\" element=\"opaque:Message\"/> \n\t\t\t-->\n");
    buffer.append("    </message>\n");


    buffer.append("    <message name=\"sendInput\">\n");
    buffer.append("        <part name=\"JMS\" element=\"ewaytype:Message\"/>\n");
    buffer.append("    </message>\n");

    buffer.append("    <message name=\"Empty_msg\">\n");
    buffer.append("    \t\t<part name=\"Empty\" element=\"opaque:empty\"/>\n");
    buffer.append("    </message>\n");

    buffer.append("    <portType name=\"JMSMessageListener\">\n");
    buffer.append("        <operation name=\"receive\">\n");
    buffer.append("            <input message=\"tns:Message\"/>\n");
    buffer.append("        </operation>\n");
    buffer.append("    </portType>\n");
    buffer.append("    <portType name=\"JMSQueue\">\n");
    buffer.append("        <operation name=\"send\">\n");
    buffer.append("            <input message=\"tns:sendInput\"/>\n");
    buffer.append("        </operation>\n");




    buffer.append("    </portType>\n");
    buffer.append("    <partnerLinkType xmlns=\"http://docs.oasis-open.org/wsbpel/2.0/plnktype\"\n");
    buffer.append("                     name=\"JMSMessageListenerLinkType\">\n");
    buffer.append("        <role name=\"JMSMessageListenerRole\" portType=\"tns:JMSMessageListener\"/>\n");
    buffer.append("    </partnerLinkType>\n");
    buffer.append("    <partnerLinkType xmlns=\"http://docs.oasis-open.org/wsbpel/2.0/plnktype\"\n");
    buffer.append("                     name=\"JMSQueueLinkType\">\n");
    buffer.append("        <role name=\"JMSQueueRole\" portType=\"tns:JMSQueue\"/>\n");
    buffer.append("    </partnerLinkType>\n");
    buffer.append("</definitions>\n");

    return buffer.toString();
  }

  public static String buildJMSImportWSDL(String name, String tns, String target) {
    StringBuffer buffer = new StringBuffer();
    buffer.append("<wsdl:definitions name=\"" + name + "\"\r\n");
    buffer.append("                  targetNamespace=\"" + tns + "\"\r\n");
    buffer.append("                  xmlns:jca=\"http://xmlns.oracle.com/pcbpel/wsdl/jca/\"\r\n");
    buffer.append("                  xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\"\r\n");
    buffer.append("                  xmlns:tns=\"" + tns + "\"\r\n");
    buffer.append("                  xmlns:pc=\"http://xmlns.oracle.com/pcbpel/\"\r\n");
    buffer.append("                  xmlns:imp1=\"urn:jmsservice\"\r\n");
    buffer.append("                  xmlns:plt=\"http://schemas.xmlsoap.org/ws/2003/05/partner-link/\">\r\n");
    buffer.append("  <plt:partnerLinkType name=\"" + target + "_plt\">\r\n");
    buffer.append("    <plt:role name=\"" + target + "_role\">\r\n");
    if (target.equals("Consume")) {
      buffer.append("      <plt:portType name=\"imp1:JMSMessageListener\"/>\r\n");
    } else
      buffer.append("      <plt:portType name=\"imp1:JMSQueueRole\"/>\r\n");
    buffer.append("    </plt:role>\r\n");
    buffer.append("  </plt:partnerLinkType>\r\n");
    buffer.append("  <wsdl:import namespace=\"urn:jmsservice\" location=\"JMS.wsdl\"/>\r\n");
    buffer.append("</wsdl:definitions>\r\n");

    return buffer.toString();
  }
}
