package soa.output;

/*import oracle.migrationtool.parser.DescriptorParser;
import oracle.migrationtool.parser.DescriptorParser.DescriptorMap;
import oracle.migrationtool.parser.DescriptorParser.DescriptorMap.EndPointDescriptor;
import oracle.migrationtool.parser.MigrationManager;
import oracle.migrationtool.parser.WSDLParser;
import oracle.migrationtool.parser.model.BPELDocument;
import oracle.migrationtool.parser.model.BPELDocument.PartnerLink;*/
import soa.Utility;
import soa.model.BPELDocument;
import soa.model.MigrationManager;
import soa.model.WSDLDocument;
/*import oracle.migrationtool.parser.model.WSDLDocument.PortType;
import oracle.migrationtool.parser.model.binding.Binding;
import oracle.migrationtool.parser.model.binding.Binding.Operation;
import oracle.migrationtool.parser.model.binding.file.FileAddress;
import oracle.migrationtool.parser.model.binding.file.FileBinding;
import oracle.migrationtool.parser.model.binding.file.FileMessage;*/
import soa.model.binding.file.FileAddress;
import soa.model.binding.file.FileBinding;
import soa.model.binding.jca.FileJCABinding;
import soa.model.binding.jca.JCABinding;
//import oracle.migrationtool.parser.model.output.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.namespace.QName;
import java.io.File;
import java.util.List;


public class FileJCAGenerator
{

  public static JCABinding generateFileJCABinding(MigrationManager manager, String name, Wire wire, FileBinding fileBinding)
  {
    WSDLDocument wsdl = null;
    WSDLDocument.PortType pt = null;
    Target target = wire.getTarget();

    ArtifactFactory factory = ArtifactFactory.getInstance();
    FileJCABinding fileJCABinding = factory.getFileJCABinding(name);
    Document document = fileJCABinding.getDocument();
    Element root = document.getDocumentElement();

    Element connectionFactory = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "connection-factory");
    connectionFactory.setAttribute("location", "eis/FileAdapter");
    root.appendChild(connectionFactory);

    QName bindingName = fileBinding.getBinding().getName();
    FileAddress fileAddress = null;
    BPELDocument.PartnerLink plk;
  if ((target instanceof InternalTarget))
    {

      plk = ((InternalTarget)target).getPartnerLink();
      pt = manager.getPortType(plk, plk.getMyRole());
      wsdl = pt.getWSDLDocument();
      fileAddress = (FileAddress)Utility.getAddress(wsdl, bindingName);
      List<String> operations = pt.getOperations();
      for (String operation : operations) {
        Element endpointActivation = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "endpoint-activation");
        Utility.addAttributePortType(endpointActivation, pt);
        Utility.addAttributeOperation(endpointActivation, operation);
        root.appendChild(endpointActivation);

        Element activationSpec = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "activation-spec");
        activationSpec.setAttribute("className", "oracle.tip.adapter.file.inbound.FileActivationSpec");
        endpointActivation.appendChild(activationSpec);

        FileMessage fileMessage = getFileMessage(fileBinding, operation);
        String deleteFileOnRead = fileMessage.getDeleteFileOnRead();
        if (deleteFileOnRead != null) {
          activationSpec.appendChild(Utility.getProperty(document, "DeleteFile", deleteFileOnRead));
        }

        activationSpec.appendChild(Utility.getProperty(document, "MinimumAge", "0"));


        if (fileAddress == null)
          fileAddress = new FileAddress();
        String physisicalDirectory = "C:/temp/soa";
        String fileName = fileMessage.getFileName();

        String key = "{" + plk.getBPELDocument().getTargetNameSpace() + "}" + plk.getQName().getLocalPart();
        DescriptorParser.DescriptorMap.EndPointDescriptor endPointDescriptor = DescriptorParser.DescriptorMap.getDescriptor(key, "Inbound", "FileIO", plk.getBPELDocument().getName());
        if (endPointDescriptor != null) {
          String fileDirectory = endPointDescriptor.getProperty("Directory", Defaults.FILE_DIRECTORY);
          if (fileDirectory != null) {
            fileAddress.setFileDirectory(fileDirectory);
            fileAddress.setArchiveFileDirectory(fileDirectory + "/in");
          }
          fileName = endPointDescriptor.getProperty("InputFileMask", "in*.txt");
          fileMessage.setPollingInterval("" + endPointDescriptor.getIntProperty("PollMilliseconds", 5000) / 1000);
          connectionFactory.setAttribute("UIincludeWildcard", fileName);
          fileName = fileName.replace("*", ".*\\");
          fileMessage.setFileName(fileName);
          String compName = endPointDescriptor.getProperty("ComponentName", null);
          if ((compName != null) && ((wire.getSource() instanceof ServiceSource))) {
            ServiceSource source = (ServiceSource)wire.getSource();
            source.setCompositeServiceName(compName + "_" + source.getCompositeServiceName());
            fileJCABinding.setFileName(source.getCompositeServiceName());
          }
        }

        if (fileAddress != null)
          physisicalDirectory = fileAddress.getFileDirectory();
        if (physisicalDirectory == null) {
          physisicalDirectory = Defaults.FILE_DIRECTORY;
        }
        activationSpec.appendChild(Utility.getProperty(document, "PhysicalDirectory", physisicalDirectory));

        if (fileAddress.getArchiveFileDirectory() != null) {
          activationSpec.appendChild(Utility.getProperty(document, "PhysicalArchiveDirectory", fileAddress.getArchiveFileDirectory()));
        }
        String recursive = "false";
        if ((fileAddress != null) && (fileAddress.getRecursive() != null))
          recursive = fileAddress.getRecursive();
        if (recursive != null) {
          activationSpec.appendChild(Utility.getProperty(document, "Recursive", recursive));
        }


        String pollingInterval = getPollingIntervalInSecs(fileMessage);
        if (pollingInterval == null) {
          pollingInterval = Defaults.FILE_POLLING_FREQUENCY;
        }
        activationSpec.appendChild(Utility.getProperty(document, "PollingFrequency", pollingInterval));



        if (fileName == null) {
          fileName = Defaults.PROVIDE_FILE_NAME;
        }
        activationSpec.appendChild(Utility.getProperty(document, "IncludeFiles", fileMessage.getFileName()));
      }
    } else if ((target instanceof ReferenceTarget))
    {


      wsdl = Utility.getWSDLDocument(manager, (ReferenceTarget)target);
      fileAddress = (FileAddress)Utility.getAddress(wsdl, bindingName);
      pt = Utility.getPortType(manager, (ReferenceTarget)target);

      List<String> operations = pt.getOperations();
      for (String operation : operations)
      {
        Element endpointInteraction = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "endpoint-interaction");
        Utility.addAttributePortType(endpointInteraction, pt);
        Utility.addAttributeOperation(endpointInteraction, operation);
        root.appendChild(endpointInteraction);

        Element interactionSpec = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "interaction-spec");
        interactionSpec.setAttribute("className", "oracle.tip.adapter.file.outbound.FileInteractionSpec");
        if (fileAddress == null) {
          fileAddress = new FileAddress();
        }
        String fileNamingConvention = "ou_%SEQ%.txt";

        FileMessage filemessage = getFileMessage(fileBinding, operation);
        if (filemessage != null) {
          fileNamingConvention = getFileMessage(fileBinding, operation).getFileName();
        }

        String key = ((ReferenceTarget)target).getServiceName().toString();
        key = ((InternalSource)wire.getSource()).getPartnerLink().getQName().toString();
        DescriptorParser.DescriptorMap.EndPointDescriptor endPointDescriptor = DescriptorParser.DescriptorMap.getDescriptor(key, "Outbound", "FileIO");
        if (endPointDescriptor != null) {
          fileAddress.setFileDirectory(endPointDescriptor.getProperty("Directory", Defaults.FILE_DIRECTORY));
          fileNamingConvention = endPointDescriptor.getProperty("OutputFileName", "ou_%SEQ%.txt");
          fileNamingConvention = fileNamingConvention.replace("%d", "%SEQ%");
          String compName = endPointDescriptor.getProperty("ComponentName", null);

          if ((compName != null) && ((target instanceof ReferenceTarget))) {
            ((ReferenceTarget)target).setCompositeServiceName(((ReferenceTarget)target).getCompositeServiceName() + "_" + compName);
            fileJCABinding.setFileName(((ReferenceTarget)target).getCompositeServiceName());
          }
        }





        String physisicalDirectory = "C:/temp/soa";
        if (fileAddress != null)
          physisicalDirectory = fileAddress.getFileDirectory();
        if (physisicalDirectory == null) {
          physisicalDirectory = Defaults.FILE_DIRECTORY;
        }
        interactionSpec.appendChild(Utility.getProperty(document, "PhysicalDirectory", physisicalDirectory));

        if (fileNamingConvention != null) {
          interactionSpec.appendChild(Utility.getProperty(document, "FileNamingConvention", fileNamingConvention));
        }
        endpointInteraction.appendChild(interactionSpec);
      }
    }
    String wsdlLocation = wsdl.getFileName();
    root.setAttribute("wsdlLocation", wsdlLocation);

    if (MigrationManager.isCAPSProject())
    {
      String fileoperation = (target instanceof InternalTarget) ? "Read" : "write";
      String wsdlContent = FileWSDLJCAGeneratorForSpring.buildFileImportWSDL(name, wsdl.getTargetNameSpace() + ":" + fileoperation.toLowerCase(), fileoperation);

      String wsdlfilePath = manager.getSourceProject().getTempLocation() + File.separator + wsdl.getFileName();

      WSDLDocument impwsdl = WSDLParser.parseDupWsdlFile(manager, wsdlfilePath, name, wsdlContent);
      wsdlLocation = name + ".wsdl";
      impwsdl.setFileName(wsdlLocation);
      root.setAttribute("wsdlLocation", wsdlLocation);

      oracle.migrationtool.parser.Utility.writeOutput(manager.getSourceProject().getTempLocation() + File.separator + wsdlLocation, impwsdl.getStringValue());
      oracle.migrationtool.parser.Utility.writeOutput(manager.getSourceProject().getTempLocation() + File.separator + "FileClient.wsdl", FileWSDLJCAGeneratorForSpring.buildCAPSFileWSDL(null, null, null));
      if (wsdl.getFileName().equals("FileClient.wsdl"))
        wsdl.setStringValue(FileWSDLJCAGeneratorForSpring.buildCAPSFileWSDL(null, null, null));
    }
    manager.addJCABinding(fileJCABinding);
    return fileJCABinding;
  }


  private static String getPollingIntervalInSecs(FileMessage fileMessage)
  {
    String pollingInterval = fileMessage.getPollingInterval();

    if (pollingInterval == null) {
      return null;
    }
    int pollInterval = Integer.valueOf(pollingInterval).intValue();
    int returnVal = pollInterval / 1000;
    if (returnVal <= 0) {
      return Defaults.FILE_POLLING_FREQUENCY;
    }
    return String.valueOf(returnVal);
  }

  private static FileMessage getFileMessage(FileBinding fileBinding, String operation)
  {
    Binding.Operation ooperation = fileBinding.getBinding().getOperation(operation);
    if (ooperation == null)
      return getdummyFileMessage(fileBinding, operation);
    FileMessage fileMessage = (FileMessage)ooperation.getInput().getMessage();
    if (fileMessage == null)
      return getdummyFileMessage(fileBinding, operation);
    return fileMessage;
  }

  private static FileMessage getdummyFileMessage(FileBinding fileBinding, String operation) {
    FileMessage fileMessage = new FileMessage();

    fileMessage.setFileName("in.*\\.txt");
    if ("write".equals(operation))
      fileMessage.setFileName("ou_%SEQ%.txt");
    fileMessage.setPollingInterval("7");
    fileMessage.setDeleteFileOnRead("true");
    return fileMessage;

  }
}
