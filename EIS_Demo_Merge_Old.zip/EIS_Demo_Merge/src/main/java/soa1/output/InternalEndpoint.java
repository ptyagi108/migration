package soa.output;

import soa.model.BPELDocument;
import soa.model.BPELDocument.PartnerLink;


public class InternalEndpoint
  implements BaseEndpoint
{
  BPELDocument.PartnerLink partnerLink;
  
  public InternalEndpoint(BPELDocument.PartnerLink partnerLink)
  {
    this.partnerLink = partnerLink;
  }
  
  public BPELDocument.PartnerLink getPartnerLink() {
    return this.partnerLink;
  }
  
  public String getUniqueName() {
    return this.partnerLink.getBPELDocument().getName().concat("/").concat(this.partnerLink.getQName().getLocalPart());
  }
}
