package soa.output;

public abstract interface Source
  extends IEndpoint
{}
