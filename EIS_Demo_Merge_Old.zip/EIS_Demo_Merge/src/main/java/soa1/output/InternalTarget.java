package soa.output;

import soa.model.BPELDocument;
//import soa.model.BPELDocument.PartnerLink;


public class InternalTarget
  extends InternalEndpoint
  implements Target
{
  public InternalTarget(BPELDocument.PartnerLink partnerLink)
  {
    super(partnerLink);
  }

  public String getUri() {
    return super.getUniqueName();
  }
}
