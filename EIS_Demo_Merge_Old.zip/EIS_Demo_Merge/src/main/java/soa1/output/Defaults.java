package soa.output;









public class Defaults
{
  public static String FILE_POLLING_FREQUENCY = "1";
  public static String FILE_DIRECTORY = "SPECIFY_FILE_DIRECTORY";
  public static String PROVIDE_FILE_NAME = "PROVIDE_FILE_NAME";
}
