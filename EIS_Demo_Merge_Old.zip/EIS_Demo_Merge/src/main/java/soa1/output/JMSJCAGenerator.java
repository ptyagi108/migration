package soa.output;

import oracle.migrationtool.parser.DescriptorParser;
import oracle.migrationtool.parser.DescriptorParser.DescriptorMap;
import oracle.migrationtool.parser.DescriptorParser.DescriptorMap.EndPointDescriptor;
import oracle.migrationtool.parser.MigrationManager;
import oracle.migrationtool.parser.WSDLParser;
import oracle.migrationtool.parser.model.BPELDocument;
import oracle.migrationtool.parser.model.BPELDocument.PartnerLink;
import oracle.migrationtool.parser.model.WSDLDocument;
import oracle.migrationtool.parser.model.WSDLDocument.PortType;
import oracle.migrationtool.parser.model.binding.Binding;
import oracle.migrationtool.parser.model.binding.Binding.Operation;
import oracle.migrationtool.parser.model.binding.jca.JCABinding;
import oracle.migrationtool.parser.model.binding.jca.JMSJCABinding;
import oracle.migrationtool.parser.model.binding.jms.JMSBinding;
import oracle.migrationtool.parser.model.binding.jms.JMSMessage;
import oracle.migrationtool.parser.model.binding.jms.JMSOperation;
import oracle.migrationtool.parser.model.output.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.util.List;


public class JMSJCAGenerator
{
  public static JCABinding generateJMSJCABinding(MigrationManager manager, String name, Wire wire, JMSBinding jmsBinding)
  {
    WSDLDocument wsdl = null;
    WSDLDocument.PortType pt = null;
    Target target = wire.getTarget();

    ArtifactFactory factory = ArtifactFactory.getInstance();
    JMSJCABinding jmsJCABinding = factory.getJMSJCABinding(name);
    Document document = jmsJCABinding.getDocument();
    Element root = document.getDocumentElement();

    Element connectionFactory = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "connection-factory");
    connectionFactory.setAttribute("location", "eis/Jms/JmsAdapter");
    connectionFactory.setAttribute("UIJmsProvider", "THIRDPARTY");
    connectionFactory.setAttribute("adapterRef", "");
    root.appendChild(connectionFactory);
    BPELDocument.PartnerLink plk;
    if ((target instanceof InternalTarget))
    {

      plk = ((InternalTarget)target).getPartnerLink();
      pt = manager.getPortType(plk, plk.getMyRole());
      wsdl = pt.getWSDLDocument();

      List<String> operations = pt.getOperations();

      for (String operation : operations) {
        Element endpointActivation = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "endpoint-activation");
        Utility.addAttributePortType(endpointActivation, pt);
        Utility.addAttributeOperation(endpointActivation, operation);
        root.appendChild(endpointActivation);

        Element activationSpec = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "activation-spec");
        activationSpec.setAttribute("className", "oracle.tip.adapter.jms.inbound.JmsConsumeActivationSpec");
        endpointActivation.appendChild(activationSpec);

        JMSOperation jmsOperation = (JMSOperation)jmsBinding.getBinding().getOperation(operation).getConcreteOperation();

        if (MigrationManager.isCAPSProject()) {
          if (jmsOperation == null) {
            jmsOperation = new JMSOperation();
          }
          DescriptorParser.DescriptorMap.EndPointDescriptor endPointDescriptor = DescriptorParser.DescriptorMap.getDescriptor(plk.getQName().toString(), "Inbound", "JMS", plk.getBPELDocument().getName());
          if (endPointDescriptor != null) {
            jmsOperation.setDestinationType(endPointDescriptor.getProperty("DestinationType", null));
            jmsOperation.setDestination(endPointDescriptor.getProperty("Destination", null));
            jmsOperation.setMessageSelector(endPointDescriptor.getProperty("messageSelector", null));
            if ((jmsOperation.getDestination() != null) && ((wire.getSource() instanceof ServiceSource))) {
              ServiceSource source = (ServiceSource)wire.getSource();
              source.setCompositeServiceName(jmsOperation.getDestination() + "_" + source.getCompositeServiceName());
              jmsJCABinding.setFileName(source.getCompositeServiceName());
            }
          }
        }


        activationSpec.appendChild(Utility.getProperty(document, "PayloadType", "TextMessage"));
        if (jmsOperation.getMessageSelector() != null)
          activationSpec.appendChild(Utility.getProperty(document, "MessageSelector", jmsOperation.getMessageSelector()));
        activationSpec.appendChild(Utility.getProperty(document, "UseMessageListener", "false"));
        activationSpec.appendChild(Utility.getProperty(document, "DestinationName", jmsOperation.getDestination()));
      }
    } else if ((target instanceof ReferenceTarget))
    {

      wsdl = Utility.getWSDLDocument(manager, (ReferenceTarget)target);
      pt = Utility.getPortType(manager, (ReferenceTarget)target);
      List<String> operations = pt.getOperations();
      for (String operation : operations)
        if (!operation.startsWith("receive"))
        {
          Element endpointInteraction = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "endpoint-interaction");
          Utility.addAttributePortType(endpointInteraction, pt);
          Utility.addAttributeOperation(endpointInteraction, operation);
          root.appendChild(endpointInteraction);

          Element interactionSpec = document.createElementNS("http://platform.integration.oracle/blocks/adapter/fw/metadata", "interaction-spec");
          interactionSpec.setAttribute("className", "oracle.tip.adapter.jms.outbound.JmsProduceInteractionSpec");

          JMSOperation jmsOperation = (JMSOperation)jmsBinding.getBinding().getOperation(operation).getConcreteOperation();
          String payLoadType = "TextMessage";
          if (getJMSMessage(jmsBinding, operation) != null) {
            payLoadType = getJMSMessage(jmsBinding, operation).getMessageType();
          }
          if (MigrationManager.isCAPSProject()) {
            payLoadType = "TextMessage";
            if (jmsOperation == null) {
              jmsOperation = new JMSOperation();
            }

            String key = ((ReferenceTarget)target).getServiceName().toString();
            key = ((InternalEndpoint)wire.getSource()).getPartnerLink().getQName().toString();
            DescriptorParser.DescriptorMap.EndPointDescriptor endPointDescriptor = DescriptorParser.DescriptorMap.getDescriptor(key, "Outbound", "JMS");
            if (endPointDescriptor != null) {
              jmsOperation.setDestinationType(endPointDescriptor.getProperty("DestinationType", null));
              jmsOperation.setDestination(endPointDescriptor.getProperty("Destination", null));
              if ("true".equalsIgnoreCase(endPointDescriptor.getProperty("PERSISTENT", null)))
              {
                jmsOperation.setDeliveryMode("Persistent");
              }
            }
          }

          interactionSpec.appendChild(Utility.getProperty(document, "TimeToLive", "0"));
          interactionSpec.appendChild(Utility.getProperty(document, "PayloadType", payLoadType));
          String deliveryMode = jmsOperation.getDeliveryMode();
          if ((deliveryMode != null) && (deliveryMode.equals("PERSISTENT"))) {
            deliveryMode = "Persistent";
          }
          interactionSpec.appendChild(Utility.getProperty(document, "DeliveryMode", deliveryMode));
          interactionSpec.appendChild(Utility.getProperty(document, "DestinationName", jmsOperation.getDestination()));
          if ((jmsOperation.getDestination() != null) && ((target instanceof ReferenceTarget))) {
            ((ReferenceTarget)target).setCompositeServiceName(((ReferenceTarget)target).getCompositeServiceName() + "_" + jmsOperation.getDestination());
            jmsJCABinding.setFileName(((ReferenceTarget)target).getCompositeServiceName());
          }
          endpointInteraction.appendChild(interactionSpec);
        }
    }
    String wsdlLocation = wsdl.getFileName();
    root.setAttribute("wsdlLocation", wsdlLocation);


    if (MigrationManager.isCAPSProject())
    {
      String jmsoperation = (target instanceof InternalTarget) ? "Consume" : "Produce";
      String wsdlContent = JMSWSDLJCAGeneratorForSpring.buildJMSImportWSDL(name, wsdl.getTargetNameSpace() + ":" + jmsoperation.toLowerCase(), jmsoperation);

      String wsdlfilePath = manager.getSourceProject().getTempLocation() + File.separator + wsdl.getFileName();

      WSDLDocument impwsdl = WSDLParser.parseDupWsdlFile(manager, wsdlfilePath, name, wsdlContent);
      wsdlLocation = name + ".wsdl";
      impwsdl.setFileName(wsdlLocation);
      root.setAttribute("wsdlLocation", wsdlLocation);

      oracle.migrationtool.parser.Utility.writeOutput(manager.getSourceProject().getTempLocation() + File.separator + wsdlLocation, impwsdl.getStringValue());
      oracle.migrationtool.parser.Utility.writeOutput(manager.getSourceProject().getTempLocation() + File.separator + "FileClient.wsdl", JMSWSDLJCAGeneratorForSpring.buildCAPSJMSWSDL());
      if (wsdl.getFileName().equals("JMS.wsdl")) {
        wsdl.setStringValue(JMSWSDLJCAGeneratorForSpring.buildCAPSJMSWSDL());
      }
    }
    manager.addJCABinding(jmsJCABinding);
    return jmsJCABinding;
  }

  public static JMSMessage getJMSMessage(JMSBinding jmsBinding, String operation) {
    Binding.Operation ooperation = jmsBinding.getBinding().getOperation(operation);
    JMSMessage fileMessage = (JMSMessage)ooperation.getInput().getMessage();
    return fileMessage;
  }
}
