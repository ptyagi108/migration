package soa.output;

/*import oracle.migrationtool.parser.JCDParser;
import oracle.migrationtool.parser.MigrationManager;
import oracle.migrationtool.parser.model.*;
import oracle.migrationtool.parser.model.BPELDocument.PARTNERLINK_TYPE;
import oracle.migrationtool.parser.model.BPELDocument.PartnerLink;
import oracle.migrationtool.parser.model.WSDLDocument.Import;
import oracle.migrationtool.parser.model.WSDLDocument.Port;
import oracle.migrationtool.parser.model.WSDLDocument.PortType;
import oracle.migrationtool.parser.model.binding.Binding;
import oracle.migrationtool.parser.model.binding.ConcreteBinding;
import oracle.migrationtool.parser.model.binding.file.FileBinding;
import oracle.migrationtool.parser.model.binding.jca.JCABinding;
import oracle.migrationtool.parser.model.binding.jms.JMSBinding;
import oracle.migrationtool.parser.model.binding.soap.SOAPBinding;
import oracle.migrationtool.parser.model.jbi.JBIConnection;
import oracle.migrationtool.parser.model.jbi.JBIConnection.Consumer;
import oracle.migrationtool.parser.model.jbi.JBIConnection.JBIEndpoint;
import oracle.migrationtool.parser.model.jbi.JBIConnection.Provider;
import oracle.migrationtool.parser.model.jbi.JBIConnections;
import oracle.migrationtool.parser.model.output.*;*/

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import soa.model.*;

import javax.xml.namespace.QName;
import java.io.File;
import java.util.*;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;


public class OutputGenerator
{
  private static Logger logger = Logger.getLogger(OutputGenerator.class.getName());

  public static ComponentType generateComponentType(MigrationManager migrationManager, BPELDocument bpel) {
    ArtifactFactory factory = ArtifactFactory.getInstance();
    ComponentType componentType = factory.getComponentType();
    Document document = componentType.getDocument();
    Element root = document.getDocumentElement();



    for (BPELDocument.PartnerLink plk : bpel.getPartnerLinks().values())
    {
      WSDLDocument wsdl = migrationManager.getWSDLDocument(plk.getPartnerLinkType());

      if (plk.getIsInUse())
      {

        if (plk.getType().equals(BPELDocument.PARTNERLINK_TYPE.SERVICE)) {
          Element service = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "service");
          service.setAttribute("name", plk.getQName().getLocalPart());




          String wsdlloc = soa.Utility.getFilePathForComposite(wsdl.getFileName());
          service.setAttribute("ui:wsdlLocation", wsdlloc);
          root.appendChild(service);


          Element interface_wsdl = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "interface.wsdl");
          WSDLDocument.PortType ptMyRole = migrationManager.getPortType(plk.getPartnerLinkType(), plk.getMyRole());
          String tns = resolveWrapperWSDLNS(wsdl);
          interface_wsdl.setAttribute("interface", tns + "#wsdl.interface(" + ptMyRole.getName() + ")");

          if (plk.getPartnerRole() != null)
          {
            WSDLDocument.PortType ptPartnerRole = migrationManager.getPortType(plk.getPartnerLinkType(), plk.getPartnerRole());
            interface_wsdl.setAttribute("callbackInterface", tns + "#wsdl.interface(" + ptPartnerRole.getName() + ")");
          }

          service.appendChild(interface_wsdl);
        }
      }
    }
    for (BPELDocument.PartnerLink plk : bpel.getPartnerLinks().values()) {
      WSDLDocument wsdl = migrationManager.getWSDLDocument(plk.getPartnerLinkType());

      if ((plk.getIsInUse()) && (wsdl != null))
      {

        if (plk.getType().equals(BPELDocument.PARTNERLINK_TYPE.REFERENCE)) {
          Element reference = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "reference");
          reference.setAttribute("name", plk.getQName().getLocalPart());
          reference.setAttribute("ui:wsdlLocation", wsdl.getFileName());
          root.appendChild(reference);


          Element interface_wsdl = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "interface.wsdl");
          WSDLDocument.PortType pt = migrationManager.getPortType(plk.getPartnerLinkType(), plk.getPartnerRole());
          String tns = resolveWrapperWSDLNS(wsdl);
          interface_wsdl.setAttribute("interface", tns + "#wsdl.interface(" + pt.getName() + ")");
          if (plk.getMyRole() != null)
          {
            WSDLDocument.PortType ptMyRole = migrationManager.getPortType(plk.getPartnerLinkType(), plk.getMyRole());
            interface_wsdl.setAttribute("callbackInterface", tns + "#wsdl.interface(" + ptMyRole.getName() + ")");
          }
          reference.appendChild(interface_wsdl);
        }
      }
    }

    return componentType;
  }

  private static String resolveWrapperWSDLNS(WSDLDocument wsdl) {
    String tns = wsdl.getTargetNameSpace();
    try
    {
      if ((wsdl.getFileName().endsWith("Wrapper.wsdl")) && (wsdl.getImports().size() == 1) && (((WSDLDocument.Import)wsdl.getImports().get(0)).getNameSpace() != null) && (((WSDLDocument.Import)wsdl.getImports().get(0)).getLocation() != null))
      {
        logger.fine("Wrapper wsdl " + wsdl.getFileName() + " " + ((WSDLDocument.Import)wsdl.getImports().get(0)).getLocation() + " " + ((WSDLDocument.Import)wsdl.getImports().get(0)).getNameSpace() + "Will use namespace " + ((WSDLDocument.Import)wsdl.getImports().get(0)).getNameSpace() + " Instead of " + tns);

        tns = ((WSDLDocument.Import)wsdl.getImports().get(0)).getNameSpace();
      }
    } catch (Throwable ignore) {
      ignore.printStackTrace();
    }
    return tns;
  }


  public static SpringContextDocument generateSpringContextDocument(MigrationManager migrationManager, JCDDocument jcd)
  {
    ArtifactFactory factory = ArtifactFactory.getInstance();
    SpringContextDocument sprinpxml = factory.getSpringContext(jcd.getName());
    Document document = sprinpxml.getDocument();
    Element root = document.getDocumentElement();

    try
    {
      String target = null;
      String type = null;
      String className = null;
      String name = null;
      String packageName = jcd.getPackageName();
      className = packageName + "." + jcd.getJcdName();

      String tns;
      Service service = (Service)jcd.getJcdParserMap().get(JCDParser.SERVICE_KEY);


        name = service.getServiceName();
        target = service.getServiceTarget();
        type = service.getServiceType();
        tns = service.getServiceNameSpace();



      Element service1 = document.createElementNS("http://xmlns.oracle.com/weblogic/weblogic-sca", "service");
      service1.setAttribute("type", type);
      service1.setAttribute("name", name);
      service1.setAttribute("target", target);

      Element servicebean = document.createElementNS("http://www.springframework.org/schema/beans", "bean");
      servicebean.setAttribute("name", target);
      servicebean.setAttribute("class", className);
      servicebean.setAttribute("scope", "prototype");

      Bean bean = (Bean)jcd.getJcdParserMap().get(JCDParser.BEAN_KEY);
      if (bean != null) {
        ArrayList beanprops = bean.getBeanProperties();
        if (beanprops != null) {
          for (int k = 0; k < beanprops.size(); k++) {
            Property prop = (Property)beanprops.get(k);
            Element beanpropEle = generateBeanProperty(document, prop.getPropertyName(), prop.getRef().getReferenceName());
            servicebean.appendChild(beanpropEle);
          }
        }
      }

      ArrayList referencesList = (ArrayList)jcd.getJcdParserMap().get(JCDParser.REFERENCE_KEY);
      if (referencesList != null) {
        for (int i = 0; i < referencesList.size(); i++) {
          Reference reference = (Reference)referencesList.get(i);


          Element ref = document.createElementNS("http://xmlns.oracle.com/weblogic/weblogic-sca", "reference");
          ref.setAttribute("type", reference.getReferenceType());
          ref.setAttribute("name", reference.getReferenceName());
          root.appendChild(ref);
        }
      }

      root.appendChild(service1);
      root.appendChild(servicebean);

    } catch (Exception ex) {
      Logger.getLogger(MigrationManager.class.getName()).log(Level.SEVERE, null, ex);
    }
    return sprinpxml;
  }



  public static Element generateBeanProperty(Document document, String name, String ref)
  {
    Element beanProperty = document.createElementNS("http://www.springframework.org/schema/beans", "property");
    beanProperty.setAttribute("name", name);
    if (ref != null)
      beanProperty.setAttribute("ref", ref);
    return beanProperty;
  }


  public static ComponentType generateSpringComponentType(MigrationManager migrationManager, JCDDocument jcd)
  {
    ArtifactFactory factory = ArtifactFactory.getInstance();
    ComponentType componentType = factory.getComponentType();
    Document document = componentType.getDocument();
    Element root = document.getDocumentElement();

     Service service = (Service)jcd.getJcdParserMap().get(JCDParser.SERVICE_KEY);

      String serviceName = service.getServiceName();
      String serviceTarget = service.getServiceType();
      generateComponentTypeBPELCallingJCD(document, jcd, root, serviceName, serviceTarget);

    return componentType;
  }

  private static void generateSpringImports(MigrationManager migrationManager, Document document, Map<QName, JCDDocument> jcdMap)
  {
    for (Entry<QName, JCDDocument> jcdcomp : jcdMap.entrySet()) {
      try {
        JCDDocument jcdDoc = (JCDDocument)jcdcomp.getValue();
        HashMap jcdParserMap = jcdDoc.getJcdParserMap();
        oracle.migrationtool.parser.model.Service service = (oracle.migrationtool.parser.model.Service)jcdParserMap.get(JCDParser.SERVICE_KEY);
        ArrayList referencesList = (ArrayList)jcdParserMap.get(JCDParser.REFERENCE_KEY);
        HashMap importsMapForJCD = generateWSDLandJCAForSpring(jcdDoc, migrationManager, service, referencesList);
        addSpringImports(document, importsMapForJCD);
      } catch (Exception ex) {
        Logger.getLogger(MigrationManager.class.getName()).log(Level.SEVERE, null, ex);
        throw new RuntimeException(ex);
      }
    }
  }


  private static Element generateComponentTypeBPELCallingJCD(Document document, JCDDocument jcd, Element root, String name, String interfaceName)
  {
    Element service = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "service");
    service.setAttribute("name", name);
    root.appendChild(service);

    Element interface_wsdl = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "interface.java");
    interface_wsdl.setAttribute("interface", interfaceName);
    service.appendChild(interface_wsdl);
    root.appendChild(service);

   /* ArrayList referencesList = (ArrayList)jcd.getJcdParserMap().get(JCDParser.REFERENCE_KEY);
    if (referencesList != null) {
      for (int i = 0; i < referencesList.size(); i++) {
        Reference reference = (Reference)referencesList.get(i);
        Element ref = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "reference");
        ref.setAttribute("name", reference.getReferenceName());
        Element ref_interface_wsdl = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "interface.java");
        ref_interface_wsdl.setAttribute("interface", reference.getReferenceType());
        ref.appendChild(ref_interface_wsdl);
        root.appendChild(ref);
      }
    }
*/
    return root;
  }


  public static Composite generateComposite(MigrationManager migrationManager, Map<QName, BPELDocument> bpelMap, Map<QName, JCDDocument> jcdMap)
  {
    int counter = 1;

    CompositeManager compositeManager = new CompositeManager();
    String compositeName = migrationManager.getOutputProject().getProjectName();
    Map<WSDLKey, WSDLDocument> wsdlMap = migrationManager.getWSDLs();
    ArtifactFactory factory = ArtifactFactory.getInstance();
    Composite composite = factory.getComposite(compositeName);
    Document document = composite.getDocument();
    addImports(document, wsdlMap);
    generateSpringImports(migrationManager, document, jcdMap);
    constructWires(migrationManager, compositeManager, bpelMap, jcdMap);
    Collection<Wire> wires = compositeManager.getWires();
    for (Wire wire : wires) {
      Source source = wire.getSource();
      if ((source instanceof ServiceSource)) {
        String sourceURI = source.getUri();

        if (checkURI(compositeManager, migrationManager, sourceURI, null))
        {
          String serviceName = ((ServiceSource)source).getCompositeServiceName();
          if (compositeManager.containsService(serviceName)) {
            serviceName = serviceName + counter++;
            ((ServiceSource)source).setCompositeServiceName(serviceName);
          }
          addServiceElement(migrationManager, document, wire);
          compositeManager.addService(serviceName);
          compositeManager.addSourceURI(sourceURI);
        }
      }
    }

    generateSpringServiceNode(migrationManager, document, jcdMap);

    for (BPELDocument bpel : bpelMap.values()) {
      addComponentElement(document, bpel);
    }
    for (JCDDocument jcd : jcdMap.values()) {
      addComponentElement(document, jcd);
    }
    for (Wire wire : wires) {
      Target target = wire.getTarget();
      if ((target instanceof ReferenceTarget)) {
        String targetURI = target.getUri();
        String compositeServiceName = ((ReferenceTarget)target).getCompositeServiceName();

        if (checkURI(compositeManager, migrationManager, null, targetURI))
        {
          if ((MigrationManager.isCAPSProject()) && (compositeManager.containsReferenceUri(targetURI))) {
            String compName = ((ReferenceTarget)wire.getTarget()).getCompositeServiceName();
            ((ReferenceTarget)wire.getTarget()).setCompositeServiceName(compName + (counter + 1));
          }

          String serviceName = ((ReferenceTarget)target).getCompositeServiceName();
          if ((compositeManager.containsSourceUri(targetURI)) || (compositeManager.containsService(serviceName)))
          {
            serviceName = serviceName + counter++;
            ((ReferenceTarget)target).setCompositeServiceName(serviceName);
          }
          addReferenceElement(migrationManager, document, wire);
          compositeManager.addReference(targetURI);
          compositeManager.addReferenceURI(targetURI);
          if (!compositeServiceName.equals(((ReferenceTarget)target).getCompositeServiceName())) {
            compositeManager.addModifiedReferenceUri(compositeServiceName, ((ReferenceTarget)target).getCompositeServiceName());
          }
        } else if (compositeManager.getModifiedReferenceUri(compositeServiceName) != null) {
          ((ReferenceTarget)target).setCompositeServiceName(compositeManager.getModifiedReferenceUri(compositeServiceName));
        }
      }
    }

    generateSpringReferencesNode(migrationManager, document, jcdMap);

    for (Wire wire : wires) {
      addWire(document, wire);
    }

    generateSpringWires(migrationManager, document, jcdMap);

    return composite;
  }

  private static boolean checkURI(CompositeManager compositeManager, MigrationManager migrationManager, String sourceURI, String targetURI)
  {
    boolean hasURI = true;

    if (MigrationManager.isCAPSProject()) {
      return hasURI;
    }


    if (sourceURI != null) {
      hasURI = !compositeManager.containsSourceUri(sourceURI);
    }


    if (targetURI != null) {
      hasURI = !compositeManager.containsReferenceUri(targetURI);
    }


    return hasURI;
  }


  private static void generateSpringServiceNode(MigrationManager migrationManager, Document document, Map<QName, JCDDocument> jcdMap)
  {
    Element root = document.getDocumentElement();
    for (Entry<QName, JCDDocument> jcdcomp : jcdMap.entrySet()) {
      try {
        JCDDocument jcdDoc = (JCDDocument)jcdcomp.getValue();
        HashMap jcdParserMap = jcdDoc.getJcdParserMap();
        Service service = (Service)jcdParserMap.get(JCDParser.SERVICE_KEY);
        if (service != null) {
          Element serviceEle = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "service");
          serviceEle.setAttribute("name", service.getServiceName());
          serviceEle.setAttribute("ui:wsdlLocation", service.getServiceName() + ".wsdl");
          root.appendChild(serviceEle);

          Element interface_wsdl = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "interface.wsdl");
          interface_wsdl.setAttribute("interface", service.getServiceNameSpace() + "#wsdl.interface(" + service.getServiceTarget() + ")");
          serviceEle.appendChild(interface_wsdl);

          Element binding = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "binding.jca");
          String serviceType = service.getServiceType();
          String jcasuffix = serviceType.indexOf(JCDParser.FILE_IN_KEY) != -1 ? "_file.jca" : "_jms.jca";
          binding.setAttribute("config", service.getServiceName() + jcasuffix);
          serviceEle.appendChild(binding);
          root.appendChild(serviceEle);
        }
        else if (jcdDoc.isJCDWS()) {
          Element serviceEleJCD = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "service");
          String serviceName = "jcdWS" + jcdDoc.getJcdName();
          serviceEleJCD.setAttribute("name", serviceName);
          String tns = jcdDoc.getTargetNameSpace();
          serviceEleJCD.setAttribute("ui:wsdlLocation", jcdDoc.getWSDLDocument(tns).getFileName());
          root.appendChild(serviceEleJCD);


          Element interface_wsdl = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "interface.wsdl");
          interface_wsdl.setAttribute("interface", jcdDoc.getTargetNameSpace() + "#wsdl.interface(ExecutePortType)");
          serviceEleJCD.appendChild(interface_wsdl);


          Element elemBinding = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "binding.ws");
          elemBinding.setAttribute("port", jcdDoc.getTargetNameSpace() + "#wsdl.endpoint(" + serviceName + "/ExecutePortType)");
          serviceEleJCD.appendChild(elemBinding);
          root.appendChild(serviceEleJCD);
        }
      }
      catch (Exception ex)
      {
        Logger.getLogger(MigrationManager.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
  }

 private static void generateSpringReferencesNode(MigrationManager migrationManager, Document document, Map<QName, JCDDocument> jcdMap)
  {
    Element root = document.getDocumentElement();

    for (Entry<QName, JCDDocument> jcdcomp : jcdMap.entrySet()) {
      try {
        JCDDocument jcdDoc = (JCDDocument)jcdcomp.getValue();
        HashMap jcdParserMap = jcdDoc.getJcdParserMap();
        ArrayList references = (ArrayList)jcdParserMap.get(JCDParser.REFERENCE_KEY);
        if (references != null)
        {
          for (int i = 0; i < references.size(); i++) {
            Reference reference = (Reference)references.get(i);
            if (reference != null) {
              String refType = reference.getReferenceType();
              Element referenceEle = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "reference");
              referenceEle.setAttribute("name", reference.getReferenceName());
              referenceEle.setAttribute("ui:wsdlLocation", reference.getReferenceName() + ".wsdl");


              Element interface_wsdl = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "interface.wsdl");
              interface_wsdl.setAttribute("interface", reference.getReferenceNameSpace() + "#wsdl.interface(" + refType.substring(refType.lastIndexOf(".") + 1) + ")");
              referenceEle.appendChild(interface_wsdl);

              Element binding = document.createElementNS("http://xmlns.oracle.com/sca/1.0", "binding.jca");
              String jcasuffix = refType.indexOf(JCDParser.FILE_OUT_KEY) != -1 ? "_file.jca" : "_jms.jca";
              binding.setAttribute("config", reference.getReferenceName() + jcasuffix);
              referenceEle.appendChild(binding);
              root.appendChild(referenceEle);
            }
          }
        }
      } catch (Exception ex) {
        Logger.getLogger(MigrationManager.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
  }

  private static void generateSpringWires(MigrationManager migrationManager, Document document, Map<QName, JCDDocument> jcdMap)
  {
    Element root = document.getDocumentElement();

    for (Entry<QName, JCDDocument> jcdcomp : jcdMap.entrySet()) {
      try {
        JCDDocument jcdDoc = (JCDDocument)jcdcomp.getValue();
        HashMap jcdParserMap = jcdDoc.getJcdParserMap();
        Service service = (Service)jcdParserMap.get(JCDParser.SERVICE_KEY);
        if (service != null) {
          String sourceUri = service.getServiceName();
          String targetUri = jcdDoc.getName() + "/" + sourceUri;
          addSpringWire(document, sourceUri, targetUri);
        }
        else if (jcdDoc.isJCDWS()) {
          String sourceUri = "jcdWS" + jcdDoc.getJcdName();
          String targetUri = jcdDoc.getName() + "/" + jcdDoc.getJcdName();

          addSpringWire(document, sourceUri, targetUri);
        }
        ArrayList references = (ArrayList)jcdParserMap.get(JCDParser.REFERENCE_KEY);
        if (references != null)
        {
          for (int i = 0; i < references.size(); i++) {
            Reference reference = (Reference)references.get(i);
            if (reference != null) {
              String sourceUri = jcdDoc.getName() + "/" + reference.getReferenceName();
              String targetUri = reference.getReferenceName();
              addSpringWire(document, sourceUri, targetUri);
            }
          }
        }
      } catch (Exception ex) {
        Logger.getLogger(MigrationManager.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
  }


  private static void addSpringWire(Document composite, String sourceUri, String targetUri)
  {
    Element root = composite.getDocumentElement();

    Element wire = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "wire");

    Element source_uri = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "source.uri");
    wire.appendChild(source_uri);
    source_uri.setTextContent(sourceUri);

    Element target_uri = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "target.uri");
    wire.appendChild(target_uri);
    target_uri.setTextContent(targetUri);
    root.appendChild(wire);
  }


  private static HashMap generateWSDLandJCAForSpring(JCDDocument jcdDoc, MigrationManager migrationManager, Service service, ArrayList references)
    throws Exception
  {
    HashMap wsdlsMap = new HashMap();
    if (service != null) {
      String jcaServContent = null;
      String wsdlServContent = null;
      String type = service.getServiceType();
      String jcaSuffix = null;

      if (jcdDoc.isJCDWS()) {
        return wsdlsMap;
      }

      if ((type.indexOf(JCDParser.JMS_IN_KEY) != -1) && (type.indexOf(JCDParser.SOA_JMS_IN_CLASS) != -1)) {
        jcaServContent = JMSWSDLJCAGeneratorForSpring.getJMSInConsume_Message_pttJCA(service, jcdDoc);
        wsdlServContent = JMSWSDLJCAGeneratorForSpring.buildJMSWSDL(service.getServiceName(), service.getServiceNameSpace(), "Consume_Message");
        jcaSuffix = "_jms.jca";
      } else if ((type.indexOf(JCDParser.FILE_IN_KEY) != -1) && (type.indexOf(JCDParser.SOA_FILE_IN_CLASS) != -1)) {
        jcaServContent = FileWSDLJCAGeneratorForSpring.getFileInRead_pttJCA(service, jcdDoc.getJcdName());
        wsdlServContent = FileWSDLJCAGeneratorForSpring.buildFileWSDL(service.getServiceName(), service.getServiceNameSpace(), "Read");
        jcaSuffix = "_file.jca";
      }
      else {
        return wsdlsMap;
      }
      String wsdlName = migrationManager.getOutputProject().getOutputProjectFullPath() + File.separator + service.getServiceName() + ".wsdl";
      oracle.migrationtool.parser.Utility.writeOutput(migrationManager.getOutputProject().getOutputProjectFullPath() + File.separator + service.getServiceName() + jcaSuffix, jcaServContent);
      oracle.migrationtool.parser.Utility.writeOutput(wsdlName, wsdlServContent);
      migrationManager.getOutputProject().addJCABinding(service.getServiceName() + jcaSuffix, jcaServContent);
      migrationManager.getOutputProject().addWSDL(service.getServiceName() + ".wsdl", wsdlServContent);

      migrationManager.generateWSStubAndJAXB(type.substring(0, type.lastIndexOf(".")), wsdlName, true);
      wsdlsMap.put(service.getServiceNameSpace(), service.getServiceName() + ".wsdl");
    }


    if ((references != null) && (references.size() > 0)) {
      int size = references.size();
      for (int i = 0; i < size; i++) {
        Reference reference = (Reference)references.get(i);
        String jcaRefContent = null;
        String wsdlRefContent = null;
        String type = reference.getReferenceType();
        String jcaSuffix = null;

        if ((type.indexOf(JCDParser.JMS_OUT_KEY) != -1) && (type.indexOf(JCDParser.SOA_JMS_OUT_CLASS) != -1)) {
          jcaRefContent = JMSWSDLJCAGeneratorForSpring.getJMSOutProduce_Message_pttJCA(reference, jcdDoc.getJcdName());
          wsdlRefContent = JMSWSDLJCAGeneratorForSpring.buildJMSWSDL(reference.getReferenceName(), reference.getReferenceNameSpace(), "Produce_Message");
          jcaSuffix = "_jms.jca";
        } else if ((type.indexOf(JCDParser.FILE_OUT_KEY) != -1) && (type.indexOf(JCDParser.SOA_FILE_OUT_CLASS) != -1)) {
          jcaRefContent = FileWSDLJCAGeneratorForSpring.getFileWrite_pttJCA(reference, jcdDoc.getJcdName());
          wsdlRefContent = FileWSDLJCAGeneratorForSpring.buildFileWSDL(reference.getReferenceName(), reference.getReferenceNameSpace(), "Write");
          jcaSuffix = "_file.jca";
        }


        String wsdlName = migrationManager.getOutputProject().getOutputProjectFullPath() + File.separator + reference.getReferenceName() + ".wsdl";
        oracle.migrationtool.parser.Utility.writeOutput(migrationManager.getOutputProject().getOutputProjectFullPath() + File.separator + reference.getReferenceName() + jcaSuffix, jcaRefContent);
        oracle.migrationtool.parser.Utility.writeOutput(wsdlName, wsdlRefContent);


        migrationManager.getOutputProject().addJCABinding(reference.getReferenceName() + jcaSuffix, jcaRefContent);
        migrationManager.getOutputProject().addWSDL(reference.getReferenceName() + ".wsdl", wsdlRefContent);

        migrationManager.generateWSStubAndJAXB(type.substring(0, type.lastIndexOf(".")), wsdlName, true);
        wsdlsMap.put(reference.getReferenceNameSpace(), reference.getReferenceName() + ".wsdl");
      }
    }



    return wsdlsMap;
  }


  private static void constructWires(MigrationManager manager, CompositeManager compositeManager, Map<QName, BPELDocument> bpelMap, Map<QName, JCDDocument> jcdMap)
  {
    JBIConnections connections = manager.getJBIXml().getConnections();
    Source source = null;
    Target target = null;
    String endpointName = null;
    Iterator i$;
    BPELDocument.PartnerLink plk;
    for (BPELDocument bpel : bpelMap.values())

      for (i$ = bpel.getPartnerLinks().values().iterator(); i$.hasNext();) { plk = (BPELDocument.PartnerLink)i$.next();
        QName serviceName = plk.getQName();

        if (plk.getIsInUse())
        {

          if (plk.getType().equals(BPELDocument.PARTNERLINK_TYPE.SERVICE)) {
            target = new InternalTarget(plk);
            endpointName = oracle.migrationtool.parser.Utility.getEndpointNameForMyRole(plk);
            List<JBIConnection.Consumer> consumers = connections.getConsumerEndpoints(serviceName, endpointName);

            for (JBIConnection.Consumer consumer : consumers)
            {



              BPELDocument.PartnerLink partnerlink = getInternalEndpoint(bpelMap, consumer);

              if (MigrationManager.isCAPSProject()) {
                partnerlink = getInternalEndpoint(bpelMap, consumer, BPELDocument.PARTNERLINK_TYPE.REFERENCE);
              }

              if (partnerlink != null) {
                source = new InternalSource(partnerlink);
              } else {
                source = new ServiceSource(consumer.getServiceName(), consumer.getEndPointName());
              }
              addWire(compositeManager, source, target);
            }
          } else if (plk.getType().equals(BPELDocument.PARTNERLINK_TYPE.REFERENCE)) {
            source = new InternalSource(plk);
            endpointName = oracle.migrationtool.parser.Utility.getEndpointNameForPartnerRole(plk);
            List<JBIConnection.Provider> providers = connections.getProviderEndpoints(serviceName, endpointName);
            for (JBIConnection.Provider provider : providers)
            {



              BPELDocument.PartnerLink partnerlink = getInternalEndpoint(bpelMap, provider);
              if (MigrationManager.isCAPSProject()) {
                partnerlink = getInternalEndpoint(bpelMap, provider, BPELDocument.PARTNERLINK_TYPE.SERVICE);
              }
              if (partnerlink != null) {
                target = new InternalTarget(partnerlink);

              }
              else
              {
                boolean match = false;
                for (QName key : jcdMap.keySet()) {
                  JCDDocument jcdDoc = (JCDDocument)jcdMap.get(key);
                  if (jcdDoc.getServiceName().equals(provider.getServiceName()))
                  {
                  //  String jcdName = jcdDoc.getJcdName(); JCDDocument
                //      tmp463_461 = jcdDoc;
                //    tmp463_461.getClass();
                //    BPELDocument.PartnerLink jcdPlink = new BPELDocument.PartnerLink(jcdDoc, jcdName, jcdDoc.getQName(), plk.getPartnerRole(), null);
                //    jcdPlink.setIsInUse(true);
                 //   target = new InternalTarget(jcdPlink);
                //    match = true;
                    break;
                  }
                }
                if (!match) {
                  target = new ReferenceTarget(provider.getServiceName(), provider.getEndPointName());
                }
              }
              addWire(compositeManager, source, target);
            }
          } }
      }

  }

  private static void addWire(CompositeManager compositeManager, Source source, Target target) { String wireId = source.getUri() + target.getUri();
    Wire wire = null;
    if (compositeManager.getWire(wireId) == null) {
      wire = new Wire(source, target);
      compositeManager.addWire(wireId, wire);
    }
  }

  private static BPELDocument.PartnerLink getInternalEndpoint(Map<QName, BPELDocument> bpelMap, JBIConnection.JBIEndpoint consumer) {
    QName serviceName = consumer.getServiceName();
    for (BPELDocument bpel : bpelMap.values()) {
      for (BPELDocument.PartnerLink plk : bpel.getPartnerLinks().values()) {
        if (plk.getQName().equals(serviceName)) {
          return plk;
        }
      }
    }
    return null;
  }

  private static BPELDocument.PartnerLink getInternalEndpoint(Map<QName, BPELDocument> bpelMap, JBIConnection.JBIEndpoint consumer, BPELDocument.PARTNERLINK_TYPE type) {
    QName serviceName = consumer.getServiceName();
    for (BPELDocument bpel : bpelMap.values()) {
      for (BPELDocument.PartnerLink plk : bpel.getPartnerLinks().values()) {
        if ((type.equals(plk.getType())) && (plk.getPartnerLinkType().getNamespaceURI().equals(serviceName.getNamespaceURI())) &&
          (plk.getQName().getLocalPart().equals(serviceName.getLocalPart())))
          return plk;
      }
    }
    return null;
  }

  private static void addImports(Document composite, Map<WSDLKey, WSDLDocument> wsdlMap) {
    Element root = composite.getDocumentElement();
    for (WSDLDocument wsdl : wsdlMap.values())
    {
      Element importt = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "import");
      importt.setAttribute("namespace", wsdl.getTargetNameSpace());
      String loc = oracle.migrationtool.parser.Utility.getFilePathForComposite(wsdl.getFileName());
      importt.setAttribute("location", loc);
      importt.setAttribute("importType", "wsdl");
      root.appendChild(importt);
    }
  }


  public static void addSpringImports(Document composite, HashMap map)
  {
    Element root = composite.getDocumentElement();
    Iterator iter = map.entrySet().iterator();
    while (iter.hasNext())
    {


      Entry me = (Entry)iter.next();
      String namespace = (String)me.getKey();
      String wsdlfile = (String)me.getValue();


      Element importt = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "import");
      importt.setAttribute("namespace", namespace);
      importt.setAttribute("location", wsdlfile);
      importt.setAttribute("importType", "wsdl");
      root.appendChild(importt);
    }
  }

  private static void addServiceElement(MigrationManager manager, Document composite, Wire wire) {
    ServiceSource serviceSource = (ServiceSource)wire.getSource();

    Element root = composite.getDocumentElement();

    Element service = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "service");

    String serviceName = serviceSource.getCompositeServiceName();
    setNameAttribute(service, serviceName);

    QName serviceQName = serviceSource.getServiceName();

    WSDLDocument.Service wsdlService = manager.getWSDLService(serviceSource);

    if (wsdlService == null) {}

    WSDLDocument wsdl = wsdlService.getWSDLDocument();
    setWSDLFileName(service, wsdl.getFileName());

    service.appendChild(getInterfaceWsdlElement(manager, composite, wire));
    service.appendChild(getBindingElement(manager, composite, serviceName, wire, false, service));
    serviceName = serviceSource.getCompositeServiceName();
    setNameAttribute(service, serviceName);

    Element callback = getCallbackElement(manager, composite, serviceName, wire);
    if (callback != null) {
      service.appendChild(callback);
    }
    root.appendChild(service);
  }



  private static void addReferenceElement(MigrationManager manager, Document composite, Wire wire)
  {
    ReferenceTarget referenceTarget = (ReferenceTarget)wire.getTarget();
    Element root = composite.getDocumentElement();
    Element reference = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "reference");
    String referenceName = referenceTarget.getCompositeServiceName();
    setNameAttribute(reference, referenceName);

    QName serviceName = referenceTarget.getServiceName();

    WSDLDocument.Service wsdlService = manager.getWSDLService(referenceTarget);
    if (wsdlService == null)
    {
      logger.warning("The jbi.xml file in the JBI .zip file makes use of the following namespace: " + referenceTarget.getServiceName() + ". \nBut the namespace definition cannot be found in the wsdl file(s) in the JBI .zip file.  Please correct this error in the wsdl file(s).");
      logger.warning("For now, this reference will not be migrated.");
      return;
    }
    WSDLDocument wsdl = wsdlService.getWSDLDocument();
    setWSDLFileName(reference, wsdl.getFileName());
    reference.appendChild(getInterfaceWsdlElement(manager, composite, wire));
    reference.appendChild(getBindingElement(manager, composite, referenceName, wire, false, reference));
    referenceName = referenceTarget.getCompositeServiceName();
    setNameAttribute(reference, referenceName);
    Element callback = getCallbackElement(manager, composite, referenceName, wire);
    if (callback != null) {
      reference.appendChild(callback);
    }
    root.appendChild(reference);
  }

  private static void setNameAttribute(Element element, String name) {
    element.setAttribute("name", name);
  }


  private static void setWSDLFileName(Element element, String wsdlName)
  {
    element.setAttribute("ui:wsdlLocation", wsdlName);
  }



  private static Element getInterfaceWsdlElement(MigrationManager manager, Document composite, Wire wire)
  {
    Element interface_wsdl = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "interface.wsdl");
    Target target = wire.getTarget();
    BPELDocument.PartnerLink plk = null;
    WSDLDocument.PortType pt = null;
    if ((target instanceof InternalTarget))
    {

      plk = ((InternalTarget)target).getPartnerLink();
      pt = manager.getPortType(plk, plk.getMyRole());
      interface_wsdl.setAttribute("interface", pt.getWSDLDocument().getTargetNameSpace() + "#wsdl.interface(" + pt.getName() + ")");
      if (plk.getPartnerRole() != null) {
        pt = manager.getPortType(plk, plk.getPartnerRole());
        getAttributeCallbackInterface(interface_wsdl, pt);
      }
    } else if ((target instanceof ReferenceTarget)) {
      String tns = Utility.getWSDLDocument(manager, (ReferenceTarget)target).getTargetNameSpace();
      String portType = Utility.getPortType(manager, (ReferenceTarget)target).getName();
      interface_wsdl.setAttribute("interface", tns + "#wsdl.interface(" + portType + ")");
      Source source = wire.getSource();
      if ((source instanceof InternalSource)) {
        plk = ((InternalSource)source).getPartnerLink();
        if (plk.getMyRole() != null) {
          pt = manager.getPortType(plk, plk.getMyRole());
          getAttributeCallbackInterface(interface_wsdl, pt);
        }
      }
    }

    return interface_wsdl;
  }

  private static void getAttributeCallbackInterface(Element interface_wsdl, WSDLDocument.PortType pt) {
    interface_wsdl.setAttribute("callbackInterface", pt.getWSDLDocument().getTargetNameSpace() + "#wsdl.interface(" + pt.getName() + ")");
  }

  private static Element getBindingElement(MigrationManager manager, Document composite, String name, Wire wire, boolean isCallback) {
    return getBindingElement(manager, composite, name, wire, isCallback, null);
  }



  private static Element getBindingElement(MigrationManager manager, Document composite, String name, Wire wire, boolean isCallback, Element service)
  {
    Element elemBinding = null;
    WSDLDocument wsdlDocument = null;
    BPELDocument.PartnerLink plk = null;
    WSDLDocument.PortType pt = null;
    String ep = null;
    Target target = wire.getTarget();
    if ((target instanceof InternalTarget)) {
      plk = ((InternalTarget)target).getPartnerLink();
      pt = null;
      if (isCallback) {
        pt = manager.getPortType(plk, plk.getPartnerRole());
      } else {
        pt = manager.getPortType(plk, plk.getMyRole());
      }
      ep = Utility.getEndpointName(name, pt);
    } else if ((target instanceof ReferenceTarget)) {
      Source source = wire.getSource();
      if ((source instanceof InternalSource)) {
        plk = ((InternalSource)source).getPartnerLink();
        if (isCallback) {
          pt = manager.getPortType(plk, plk.getMyRole());
          ep = Utility.getEndpointName(name, pt);
        } else {
          pt = manager.getPortType(plk, plk.getPartnerRole());
          if (pt.getWSDLDocument().isWSDLDriven()) {
            ep = pt.getWSDLDocument().getExternalEndpointName(name, pt);
            pt.getWSDLDocument().setReference(true);
          }
          else {
            ep = Utility.getEndpointName(name, pt);
          }
        }
      }
    }
    Binding binding = getBinding(manager, wire);
    ConcreteBinding concreteBinding = binding.getConcreteBinding();
    if ((concreteBinding instanceof SOAPBinding)) {
      wsdlDocument = pt.getWSDLDocument();
      elemBinding = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "binding.ws");
      elemBinding.setAttribute("port", wsdlDocument.getTargetNameSpace() + "#wsdl.endpoint(" + ep + ")");
      if (wsdlDocument.isWSDLDriven()) {
        elemBinding.setAttribute("location", wsdlDocument.getFileName());
        elemBinding.setAttribute("soapVersion", "1.1");

      }

    }
    else if ((concreteBinding instanceof JMSBinding))
    {
      JCABinding jcabinding = JCABindingGenerator.generateJMSJCABinding(manager, name, wire, (JMSBinding)binding.getConcreteBinding());
      elemBinding = getBindingJCAElement(composite, jcabinding.getFileName(), concreteBinding);
      if ((service != null) && (MigrationManager.isCAPSProject())) {
        setWSDLFileName(service, name + ".wsdl");
      }
    } else if ((concreteBinding instanceof FileBinding))
    {
      JCABinding jcabinding = JCABindingGenerator.generateFileJCABinding(manager, name, wire, (FileBinding)binding.getConcreteBinding());
      elemBinding = getBindingJCAElement(composite, jcabinding.getFileName(), concreteBinding);

      if ((service != null) && (MigrationManager.isCAPSProject())) {
        setWSDLFileName(service, name + ".wsdl");
      }
    }
    return elemBinding;
  }

  private static Element getBindingJCAElement(Document composite, String name, ConcreteBinding concreteBinding) {
    Element elemBinding = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "binding.jca");
    if ((concreteBinding instanceof JMSBinding)) {
      elemBinding.setAttribute("config", name);
    } else if ((concreteBinding instanceof FileBinding)) {
      elemBinding.setAttribute("config", name);
    }

    return elemBinding;
  }


  private static Binding getBinding(MigrationManager manager, Wire wire)
  {
    Source source = wire.getSource();
    Target target = wire.getTarget();
    Binding binding = null;
    WSDLDocument.Service service = null;
    QName bindingQName = null;
    String endpointName; if ((target instanceof InternalTarget)) {
      if ((source instanceof ServiceSource))
      {
        service = manager.getWSDLService((ServiceSource)source);
         endpointName = ((ServiceSource)source).getEndpointName();
        WSDLDocument.Port port = service.getPort(endpointName);
        bindingQName = port.getBinding();
      } else if ((source instanceof InternalSource)) {
        BPELDocument.PartnerLink plk = ((InternalTarget)target).getPartnerLink();
        QName serviceName = plk.getQName();
        endpointName = oracle.migrationtool.parser.Utility.getEndpointNameForMyRole(plk);
      }
    }
    else if ((target instanceof ReferenceTarget)) {
      WSDLDocument.Port port = Utility.getWSDLPort(manager, (ReferenceTarget)target);
      bindingQName = port.getBinding();
    }
    binding = manager.getBinding(bindingQName);
    return binding;
  }

  private static Element getCallbackElement(MigrationManager manager, Document composite, String name, Wire wire) {
    Target target = wire.getTarget();
    BPELDocument.PartnerLink plk = null;
    if ((target instanceof InternalTarget)) {
      plk = ((InternalTarget)target).getPartnerLink();
      if (plk.getPartnerRole() != null) {
        return getCallback(manager, composite, name, wire);
      }
    } else if ((target instanceof ReferenceTarget)) {
      Source source = wire.getSource();
      if ((source instanceof InternalSource)) {
        plk = ((InternalSource)source).getPartnerLink();
        if (plk.getMyRole() != null) {
          return getCallback(manager, composite, name, wire);
        }
      }
    }
    return null;
  }

  private static Element getCallback(MigrationManager manager, Document composite, String name, Wire wire) {
    Element callback = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "callback");
    callback.appendChild(getBindingElement(manager, composite, name, wire, true));
    return callback;
  }

  private static void addComponentElement(Document composite, BPELDocument bpelDocument) {
    Element root = composite.getDocumentElement();

    Element component = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "component");
    component.setAttribute("name", bpelDocument.getName());
    root.appendChild(component);


    Element implementation_bpel = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "implementation.bpel");
    implementation_bpel.setAttribute("src", bpelDocument.getFileName());
    component.appendChild(implementation_bpel);
    component.appendChild(composite.createComment("<property name=\"bpel.config.var.init.maintainSchemaSequence\">true</property> uncomment this to avoid initialization of unset fields, and create them in proper sequence when the field is set"));
    component.appendChild(composite.createComment("<property name=\"bpel.config.initializeVariables\">false</property> uncomment this to avoid initialization of unset fields, but mak sure to set insertMissingToData in all copy activities, to avoid selection failure"));
  }

  private static void addComponentElement(Document composite, JCDDocument jcdDocument)
  {
    Element root = composite.getDocumentElement();

    Element component = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "component");
    component.setAttribute("name", jcdDocument.getName());
    root.appendChild(component);


    Element implementation_spring = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "implementation.spring");
    implementation_spring.setAttribute("src", jcdDocument.getName() + ".xml");
    component.appendChild(implementation_spring);
  }

  private static void addWire(Document composite, Wire wiree) {
    Element root = composite.getDocumentElement();

    Element wire = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "wire");
    root.appendChild(wire);

    Element source_uri = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "source.uri");
    wire.appendChild(source_uri);
    Source source = wiree.getSource();
    String sourceURI = null;
    if ((source instanceof ServiceSource))
    {

      sourceURI = ((ServiceSource)source).getCompositeServiceName();
    } else {
      sourceURI = source.getUri();
    }
    source_uri.setTextContent(sourceURI);


    Element target_uri = composite.createElementNS("http://xmlns.oracle.com/sca/1.0", "target.uri");
    wire.appendChild(target_uri);
    Target target = wiree.getTarget();
    String targetURI = null;
    if ((target instanceof ReferenceTarget)) {
      targetURI = ((ReferenceTarget)target).getCompositeServiceName();
    } else {
      targetURI = target.getUri();
    }
    target_uri.setTextContent(targetURI);
  }

}
