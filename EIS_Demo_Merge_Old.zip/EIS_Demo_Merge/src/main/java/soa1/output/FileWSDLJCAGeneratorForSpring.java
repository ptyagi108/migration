package soa.output;

//import oracle.migrationtool.parser.model.Reference;
import soa.model.Reference;
import soa.model.Service;


public class FileWSDLJCAGeneratorForSpring
{
  public static String buildFileWSDL(String name, String tns, String target)
  {
    StringBuffer buffer = new StringBuffer();
    
    buffer.append("<wsdl:definitions\n");
    buffer.append("  name=\"" + name + "\"\n");
    buffer.append("targetNamespace=\"" + tns + "\"\n");
    buffer.append("xmlns:jca=\"http://xmlns.oracle.com/pcbpel/wsdl/jca/\"\n");
    buffer.append("xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\"\n");
    buffer.append("xmlns:tns=\"" + tns + "\"\n");
    buffer.append("xmlns:opaque=\"http://xmlns.oracle.com/pcbpel/adapter/opaque/\"\n");
    buffer.append("xmlns:pc=\"http://xmlns.oracle.com/pcbpel/\"\n");
    buffer.append("xmlns:plt=\"http://schemas.xmlsoap.org/ws/2003/05/partner-link/\"\n");
    buffer.append(">\n");
    buffer.append("<plt:partnerLinkType name=\"" + target + "_plt\" >\n");
    buffer.append("<plt:role name=\"" + target + "_role\" >\n");
    buffer.append("  <plt:portType name=\"tns:" + target + "_ptt\" />\n");
    buffer.append("</plt:role>\n");
    buffer.append("</plt:partnerLinkType>\n");
    buffer.append("<wsdl:types>\n");
    buffer.append("<schema targetNamespace=\"http://xmlns.oracle.com/pcbpel/adapter/opaque/\"\n");
    buffer.append("        xmlns=\"http://www.w3.org/2001/XMLSchema\" >\n");
    buffer.append("  <element name=\"opaqueElement\" type=\"base64Binary\" />\n");
    buffer.append("</schema>\n");
    buffer.append("</wsdl:types>\n");
    buffer.append("<wsdl:message name=\"" + target + "_msg\">\n");
    buffer.append("    <wsdl:part name=\"opaque\" element=\"opaque:opaqueElement\"/>\n");
    buffer.append("</wsdl:message>\n");
    buffer.append("<wsdl:portType name=\"" + target + "_ptt\">\n");
    buffer.append("    <wsdl:operation name=\"" + target + "\">\n");
    buffer.append("        <wsdl:input message=\"tns:" + target + "_msg\"/>\n");
    buffer.append("    </wsdl:operation>\n");
    buffer.append("</wsdl:portType>\n");
    buffer.append("</wsdl:definitions>\n");
    

    return buffer.toString();
  }
  










  public static String getFileInRead_pttJCA(Service service, String JcdName)
  {
    //String fileName = service.getFileName();
    String fileName = "";
    
    StringBuffer buffer = new StringBuffer();
    
    buffer.append("<adapter-config name=\"vvccv\" adapter=\"File Adapter\" wsdlLocation=\"vvccv.wsdl\"\n");
    buffer.append("xmlns=\"http://platform.integration.oracle/blocks/adapter/fw/metadata\">\n");
    buffer.append("<connection-factory location=\"eis/FileAdapter\" UIincludeWildcard=\"" + fileName + "\"/>\n");
    
    fileName = fileName.replace("*", ".*\\");
    
    buffer.append("<endpoint-activation portType=\"Read_ptt\" operation=\"Read\">\n");
    buffer.append("<activation-spec className=\"oracle.tip.adapter.file.inbound.FileActivationSpec\">\n");
    buffer.append("<property name=\"DeleteFile\" value=\"true\"/>\n");
    buffer.append("<property name=\"MinimumAge\" value=\"0\"/>\n");
    buffer.append("<property name=\"PhysicalDirectory\" value=\"" + service.getDestination() + "\"/>\n");
    buffer.append("<property name=\"Recursive\" value=\"true\"/>\n");
    buffer.append("<property name=\"PollingFrequency\" value=\"" + service.getFilePollseconds() + "\"/>\n");
    buffer.append("<property name=\"IncludeFiles\" value=\"" + fileName + "\"/>\n");
    buffer.append("<property name=\"UseHeaders\" value=\"false\"/>\n");
    buffer.append("</activation-spec>\n");
    buffer.append("</endpoint-activation>\n");
    buffer.append("</adapter-config>\n");
    return buffer.toString();
  }
  










  public static String getFileWrite_pttJCA(Reference reference, String JcdName)
  {
    StringBuffer buffer = new StringBuffer();
    buffer.append("<adapter-config name=\"FileOut\" adapter=\"File Adapter\"\n");
    buffer.append("   wsdlLocation=\"FileOut.wsdl\"\n");
    buffer.append("   xmlns=\"http://platform.integration.oracle/blocks/adapter/fw/metadata\">\n");
    buffer.append("\t\t<connection-factory location=\"eis/FileAdapter\"/>\n");
    buffer.append("<endpoint-interaction portType=\"Write_ptt\" operation=\"Write\">\n");
    buffer.append("<interaction-spec className=\"oracle.tip.adapter.file.outbound.FileInteractionSpec\">\n");
    buffer.append(" <property name=\"PhysicalDirectory\" value=\"" + reference.getDestination() + "\"/>\n");
    buffer.append(" <property name=\"Append\" value=\"false\"/>\n");
    buffer.append(" <property name=\"FileNamingConvention\" value=\"" + reference.getFileName() + "\"/>\n");
    buffer.append(" <property name=\"NumberMessages\" value=\"1\"/>\n");
    buffer.append("</interaction-spec>\n");
    buffer.append("</endpoint-interaction>\n");
    buffer.append("</adapter-config>\n");
    return buffer.toString();
  }
  
  public static String buildFileImportWSDL(String name, String tns, String target)
  {
    StringBuffer buffer = new StringBuffer();
    
    buffer.append("<wsdl:definitions\n");
    buffer.append("  name=\"" + name + "\"\n");
    buffer.append("targetNamespace=\"" + tns + "\"\n");
    buffer.append("     xmlns:jca=\"http://xmlns.oracle.com/pcbpel/wsdl/jca/\"\n");
    buffer.append("     xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\"\n");
    buffer.append("\t\txmlns:tns=\"" + tns + "\"\n");
    buffer.append("     xmlns:pc=\"http://xmlns.oracle.com/pcbpel/\"\n");
    buffer.append("     xmlns:imp1=\"urn:fileservice\"\n");
    buffer.append("     xmlns:plt=\"http://schemas.xmlsoap.org/ws/2003/05/partner-link/\"\n");
    buffer.append("    >\n");
    buffer.append("<plt:partnerLinkType name=\"" + target + "_plt\" >\n");
    buffer.append("<plt:role name=\"" + target + "_role\" >\n");
    if (target.equals("write")) {
      buffer.append("  <plt:portType name=\"imp1:FileSender\" />\n");
    } else
      buffer.append("  <plt:portType name=\"imp1:FileListener\" />\n");
    buffer.append("</plt:role>\n");
    buffer.append("</plt:partnerLinkType>\n");
    buffer.append("    <wsdl:import namespace=\"urn:fileservice\" location=\"FileClient.wsdl\"/>\n");
    buffer.append("</wsdl:definitions>\n");
    return buffer.toString();
  }
  
  public static String buildCAPSFileWSDL(String name, String tns, String target) {
    StringBuffer buffer = new StringBuffer();
    
    buffer.append("<wsdl:definitions xmlns=\"http://schemas.xmlsoap.org/wsdl/\"\r\n");
    buffer.append("                  xmlns:varprop=\"http://docs.oasis-open.org/wsbpel/2.0/varprop\"\r\n");
    buffer.append("                  xmlns:ewaytype=\"http://xml.netbeans.org/schema/eWayTypes\"\r\n");
    buffer.append("\t\t\t\t\t xmlns:opaque=\"http://xmlns.oracle.com/pcbpel/adapter/opaque/\"\n");
    buffer.append("                  xmlns:eways=\"urn:seebeyond:wsdl:extension:binding:eways\"\r\n");
    buffer.append("                  xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\"\r\n");
    buffer.append("                  xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\r\n");
    buffer.append("                  xmlns:plink=\"http://docs.oasis-open.org/wsbpel/2.0/plnktype\"\r\n");
    buffer.append("                  xmlns:tns=\"urn:fileservice\" targetNamespace=\"urn:fileservice\">\r\n");
    buffer.append("    <types>\r\n");
    buffer.append("        <schema targetNamespace=\"http://xml.netbeans.org/schema/eWayTypes\"\r\n");
    buffer.append("                xmlns=\"http://www.w3.org/2001/XMLSchema\">\r\n");
    buffer.append("            <element name=\"FileTextMessage\" type=\"string\"/>\r\n");
    buffer.append("        </schema>\r\n");
    buffer.append("        <schema targetNamespace=\"http://xmlns.oracle.com/pcbpel/adapter/opaque/\"\r\n");
    buffer.append("                xmlns=\"http://www.w3.org/2001/XMLSchema\">\r\n");
    buffer.append("            <element name=\"FileTextMessage\" type=\"base64Binary\"/>\r\n");
    buffer.append("        </schema>\r\n");
    buffer.append("    </types>\r\n");
    buffer.append("    <message name=\"FileTextMessage\">\r\n");
    buffer.append("        <part name=\"text\" element=\"ewaytype:FileTextMessage\"/>\r\n");
    
    buffer.append("\t\t\t<!-- This is opaque message type, comment out text part defined above and uncomment following text part\r\n");
    buffer.append("\t\t\tto use opaque message type \r\n");
    buffer.append("        <part name=\"text\" element=\"opaque:FileTextMessage\"/> \r\n \t\t\t--> \r\n");
    
    buffer.append("    </message>\r\n");
    
    buffer.append("    <!-- Following two are kept to for BP to resolve type-->\n");
    buffer.append("    <message name=\"FileWriteOutputMessage\">\r\n");
    buffer.append("        <part name=\"text\" element=\"ewaytype:FileTextMessage\"/>\r\n");
    buffer.append("    </message>\r\n");
    
    buffer.append("    <message name=\"FileFaultMessage\">\r\n");
    buffer.append("        <part name=\"text\" element=\"ewaytype:FileTextMessage\"/>\r\n");
    buffer.append("    </message>\r\n");
    
    buffer.append("    <partnerLinkType xmlns=\"http://docs.oasis-open.org/wsbpel/2.0/plnktype\"\r\n");
    buffer.append("                     name=\"FileListenerLinkType\">\r\n");
    buffer.append("        <role name=\"FileListenerRole\" portType=\"tns:FileListener\"/>\r\n");
    buffer.append("    </partnerLinkType>\r\n");
    buffer.append("    <wsdl:portType name=\"FileSender\">\r\n");
    buffer.append("        <wsdl:operation name=\"write\">\r\n");
    buffer.append("            <wsdl:input name=\"FileTextMessage\" message=\"tns:FileTextMessage\"/>\r\n");
    buffer.append("        </wsdl:operation>\r\n");
    buffer.append("    </wsdl:portType>\r\n");
    buffer.append("    <wsdl:portType name=\"FileListener\">\r\n");
    buffer.append("        <wsdl:operation name=\"receive\">\r\n");
    buffer.append("            <wsdl:input name=\"FileTextMessage\" message=\"tns:FileTextMessage\"/>\r\n");
    buffer.append("        </wsdl:operation>\r\n");
    buffer.append("    </wsdl:portType>\r\n");
    
    buffer.append("    <partnerLinkType xmlns=\"http://docs.oasis-open.org/wsbpel/2.0/plnktype\"\r\n");
    buffer.append("                     name=\"FileSenderLinkType\">\r\n");
    buffer.append("        <role name=\"FileSenderRole\" portType=\"tns:FileSender\"/>\r\n");
    buffer.append("    </partnerLinkType>\r\n");
    buffer.append("</wsdl:definitions>\r\n");
    
    return buffer.toString();
  }
}
