package soa.output;

import soa.model.MigrationManager;
import soa.model.binding.file.FileBinding;
import soa.model.binding.jca.JCABinding;
import soa.model.binding.jms.JMSBinding;
import soa.output.Wire;


public class JCABindingGenerator
{
 /* public static JCABinding generateJMSJCABinding(MigrationManager manager, String name, Wire wire, JMSBinding jmsBinding)
  {
    return JMSJCAGenerator.generateJMSJCABinding(manager, name, wire, jmsBinding);
  }*/
  
  public static JCABinding generateFileJCABinding(MigrationManager manager, String name, Wire wire, FileBinding fileBinding) {
    return FileJCAGenerator.generateFileJCABinding(manager, name, wire, fileBinding);
  }
}
