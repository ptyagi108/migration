package soa.model;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import soa.model.soap.Message;
import soa.model.soap.Binding;
import soa.model.soap.Address;

/**
 * Created by Manoj_Mehta on 3/28/2017.
 */
public class WSDLDocument {

    public static final String WSDL_NS = "http://schemas.xmlsoap.org/wsdl/";

    private final String name;

    private final String targetNameSpace;
    private List<PortType> portTypes = new ArrayList();
    private List<PartnerLinkType> partnerLinkTypes = new ArrayList();
    private List<Import> imports = new ArrayList();
    private Map<String, Binding> bindings = new HashMap();
    private Map<String, Service> services = new HashMap();
    private String fileName;
    private String stringValue;
    private String otdPackage;
    private Message otdMessage;
    private List<Message> messageList = new ArrayList();
    private SourceProject sourceProject;
    private boolean isWSDLDriven;
    private boolean isReference;
    private boolean isFromWar;
    private Service wsdlService;

    public WSDLDocument(SourceProject sourceProject, String targetNameSpace, String name) {
        this.name = name;
        this.targetNameSpace = targetNameSpace;
        this.sourceProject = sourceProject;
    }

    public class PortType {
        private final String name;
        private List<String> operation = new ArrayList();

        private final WSDLDocument wsdl;

        public PortType(String name, WSDLDocument wsdlDoc) {
            this.name = name;
            this.wsdl = wsdlDoc;
        }

        public String getName() {
            return this.name;
        }

        public List<String> getOperations() {
            return this.operation;
        }

        public void addOperation(String op) {
            this.operation.add(op);
        }

        public WSDLDocument getWSDLDocument() {
            return this.wsdl;
        }
    }

    public class Role {
        String name;


        QName portType;


        public Role(String name, QName pt) {
            this.name = name;
            this.portType = pt;
        }

        public Object getName() {
            return this.name;
        }

        public QName getPortType() {
            return this.portType;
        }
    }

    public class PartnerLinkType {
        String name;
        List<WSDLDocument.Role> role = new ArrayList();

        public PartnerLinkType(String name) {
            this.name = name;
        }

        public void addRole(WSDLDocument.Role role) {
            this.role.add(role);
        }

        public String getName() {
            return this.name;
        }

        public List<WSDLDocument.Role> getRoles() {
            return this.role;
        }
    }

    public class Service {
        private String name;
        private Map<String, WSDLDocument.Port> ports = new HashMap();

        public Service(String name) {
            this.name = name;
            if (!name.startsWith("svc")) {
                WSDLDocument.this.isWSDLDriven = true;
                WSDLDocument.this.wsdlService = this;
            }
        }


    }

    public class Import
    {
        protected String location;

        protected String namespace;

        protected String absLocation;


        public String getAbsoluteLocation()
        {
            return this.absLocation;
        }

        public Import(String ns, String location, String locationPath)
        {
            this.location = location;
            this.namespace = ns;
            this.absLocation = locationPath;
        }
        public String getNameSpace()
        {
            return this.namespace;
        }
        public String getLocation()
        {
            return this.location;
        }
    }

    public class Port
    {
        private String name;
        private QName binding;
        private Address address;

        public Port(String name, QName binding, Address add) {
            this.name = name;
            this.binding = binding;
            this.address = add;
        }

        public Address getAddress() {
            return this.address;
        }

        public QName getBinding() {
            return this.binding;
        }

        public String getName() {
            return this.name;
        }
    }

    public static String getWsdlNs() {
        return WSDL_NS;
    }

    public String getName() {
        return name;
    }

    public String getTargetNameSpace() {
        return targetNameSpace;
    }

    public List<PortType> getPortTypes() {
        return portTypes;
    }

    public void setPortTypes(List<PortType> portTypes) {
        this.portTypes = portTypes;
    }

    public List<PartnerLinkType> getPartnerLinkTypes() {
        return partnerLinkTypes;
    }

    public void setPartnerLinkTypes(List<PartnerLinkType> partnerLinkTypes) {
        this.partnerLinkTypes = partnerLinkTypes;
    }

    public List<Import> getImports() {
        return imports;
    }

    public void setImports(List<Import> imports) {
        this.imports = imports;
    }

    public Map<String, Binding> getBindings() {
        return bindings;
    }

    public void setBindings(Map<String, Binding> bindings) {
        this.bindings = bindings;
    }

    public Map<String, Service> getServices() {
        return services;
    }

    public void setServices(Map<String, Service> services) {
        this.services = services;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

    public String getOtdPackage() {
        return otdPackage;
    }

    public void setOtdPackage(String otdPackage) {
        this.otdPackage = otdPackage;
    }

    public Message getOtdMessage() {
        return otdMessage;
    }

    public void setOtdMessage(Message otdMessage) {
        this.otdMessage = otdMessage;
    }

    public List<Message> getMessageList() {
        return messageList;
    }

    public void setMessageList(List<Message> messageList) {
        this.messageList = messageList;
    }

    public SourceProject getSourceProject() {
        return sourceProject;
    }

    public void setSourceProject(SourceProject sourceProject) {
        this.sourceProject = sourceProject;
    }

    public boolean isWSDLDriven() {
        return isWSDLDriven;
    }

    public void setWSDLDriven(boolean WSDLDriven) {
        isWSDLDriven = WSDLDriven;
    }

    public boolean isReference() {
        return isReference;
    }

    public void setReference(boolean reference) {
        isReference = reference;
    }

    public boolean isFromWar() {
        return isFromWar;
    }

    public void setFromWar(boolean fromWar) {
        isFromWar = fromWar;
    }

    public Service getWsdlService() {
        return wsdlService;
    }

    public void setWsdlService(Service wsdlService) {
        this.wsdlService = wsdlService;
    }

    public QName getPortTypeQName(QName plType, String rolee)
    {
        for (PartnerLinkType plt : this.partnerLinkTypes) {
            if (plt.getName().equals(plType.getLocalPart())) {
                for (Role role : plt.getRoles()) {
                    if (role.getName().equals(rolee)) {
                        QName qPortType = role.getPortType();

                        return qPortType;
                    }
                }
            }
        }
        return null;
    }

    public PortType getPortType(QName qnPortType)
    {
        if ((qnPortType != null) && (qnPortType.getNamespaceURI().equals(this.targetNameSpace))) {
            for (PortType pt : this.portTypes) {
                if (pt.getName().equals(qnPortType.getLocalPart())) {
                    return pt;
                }
            }
        }
        return null;
    }

}
