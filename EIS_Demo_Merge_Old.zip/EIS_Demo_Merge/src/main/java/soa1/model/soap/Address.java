package soa.model.soap;

public abstract class Address {}
