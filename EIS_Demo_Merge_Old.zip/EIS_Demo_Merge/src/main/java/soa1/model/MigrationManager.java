package soa.model;

public class MigrationManager
{
/*
  SourceProject sourceProject;
  private OutputProject outputProject;
  Composite composite = null;

  private static final String BPEL1_0_NS_VARIANT = "http://schemas.xmlsoap.org/ws/2002/07/business-process/";
  private static final String BPEL1_0_NS = "http://schemas.xmlsoap.org/ws/2002/07/business-process";
  private static final String BPEL2_0_NS = "http://docs.oasis-open.org/wsbpel/2.0/process/executable";
  private static final String BPEL2_0_VAR_NS = "http://docs.oasis-open.org/wsbpel/2.0/varprop";
  //JBIXML jbiXML = null;
  private static boolean isCAPSProject = false;
  private static Logger logger = Logger.getLogger(MigrationManager.class.getName());


  private String soaHome = null;


  Map<WSDLKey, WSDLDocument> wsdlMap = new HashMap();
  Map<QName, BPELDocument> bpelMap = new HashMap();
  private Map<QName, ComponentType> componentTypes = null;
  //private Map<QName, SpringContextDocument> springcontexts = null;
  // private Map<String, JCABinding> jcaBindings = null;
  // private Map<QName, JCDDocument> jcdMap = null;
  private static final String INVALID_WSDL_MODEL = "Error creating model from wsdl";
  private static final String INVALID_PACKAGE_NAME = "used for this schema is not a valid package name";

  public void clear()
  {
    getOutputProject().clear();
    //  getSourceProject().clear();
    this.wsdlMap.clear();
    this.bpelMap.clear();
    this.componentTypes.clear();
    // this.springcontexts.clear();
    // this.jcdMap.clear();
    // this.jcdMap = null;
    this.composite = null;

  }


  public MigrationManager(String serviceAssembly, String outputProjName, String outputFolder, String soaHome, boolean useJAXB, String encoding, boolean isSRE)
  {
    this.soaHome = soaHome;
    this.wsdlMap = new HashMap();
    this.componentTypes = new HashMap();
    //   this.springcontexts = new HashMap();
    //  this.jcaBindings = new HashMap();
    //  this.jcdMap = new HashMap();

    try
    {
      File outputDir = new File(outputFolder, outputProjName);

      if (!outputDir.mkdirs())
      {
        logger.warning("Unable to create directory " + outputDir.getAbsolutePath());
      }

      this.outputProject = new OutputProject(outputProjName, outputFolder);
      this.sourceProject = new SourceProject(serviceAssembly, this);
    }
    catch (Exception ex)
    {
      logger.log(Level.SEVERE, "", ex);
    }
  }


  public void parseDocuments() throws Exception
  {

    //transformWSDLs(this.sourceProject);

    // parseWSDLs(this.sourceProject);

    // transformBPELs(this.sourceProject);

    // parseBPELs(this.sourceProject);

    // parseJBIXML(this.sourceProject);

    // parseConnectivity(this.sourceProject);

  }





  public Map<QName, BPELDocument> getBPELMap()
  {
    return this.bpelMap;
  }

  public WSDLDocument getWSDLDocument(String tns, String location) {
    WSDLKey key = new WSDLKey(tns, location);
    return (WSDLDocument)this.wsdlMap.get(key);
  }

  public WSDLDocument getWSDLDocument(String tns, String location, boolean fromWar) {
    WSDLKey key = new WSDLKey(tns, location);
    if (fromWar) {
      for (WSDLDocument wsdl : this.wsdlMap.values()) {
        if (tns.equals(wsdl.getTargetNameSpace())) {
          return wsdl;
        }
      }
    }
    return (WSDLDocument)this.wsdlMap.get(key);
  }

  public WSDLDocument getWSDLDocument(String tns, String name, String location, boolean fromWar) {
    WSDLDocument wsdl = getWSDLDocument(tns, location, fromWar);
    if (wsdl != null) {
      return wsdl;
    }
    wsdl = new WSDLDocument(this.sourceProject, tns, name);
    WSDLKey key = new WSDLKey(tns, location);
    this.wsdlMap.put(key, wsdl);
    return wsdl;
  }


  public WSDLDocument getWSDLDocument(String tns, String name, String location)
  {
    WSDLDocument wsdl = getWSDLDocument(tns, location);
    if (wsdl != null) {
      return wsdl;
    }
    wsdl = new WSDLDocument(this.sourceProject, tns, name);
    WSDLKey key = new WSDLKey(tns, location);
    this.wsdlMap.put(key, wsdl);
    return wsdl;
  }

  public void generateArtifacts()
  {
    //reset();
    ComponentType componentType = null;

    for (Map.Entry<QName, BPELDocument> bpel : this.bpelMap.entrySet()) {
      componentType = OutputGenerator.generateComponentType(this, (BPELDocument)bpel.getValue());
      componentType.setName((QName)bpel.getKey());
      getComponentTypes().put(bpel.getKey(), componentType);
    }
    {
      */
/*for (Map.Entry<QName, JCDDocument> jcdcomp : this.jcdMap.entrySet()) {
        try {
          JCDParser jcdparser = new JCDParser();
          JCDDocument jcdDoc = (JCDDocument)jcdcomp.getValue();

          componentType = OutputGenerator.generateSpringComponentType(this, jcdDoc);
          String jcdName = ((JCDDocument)jcdcomp.getValue()).getName();
          String tns = ((JCDDocument)jcdcomp.getValue()).getTargetNameSpace();
          QName qname = new QName(tns, jcdName);
          componentType.setName(qname);
          getComponentTypes().put(qname, componentType);



          SpringContextDocument springxmlDoc = OutputGenerator.generateSpringContextDocument(this, jcdDoc);
          springxmlDoc.setName(qname);
          getSpringContextDocument().put(qname, springxmlDoc);
        }
        catch (NoClassDefFoundError ncf) {
          logger.severe("Could not find some of the required Third-Party libraries.\n  Migration Tool requires user to download the following Third-Party jars and copy them to oracle.migrationtool.jcaps.libraries/lib folder. \n \t1.appframework-1.0.3.jar -->  http://download.java.net/maven/2/org/jdesktop/appframework/1.0.3/appframework-1.0.3.jar \n \t2.swing-worker-1.1.jar   -->  http://download.java.net/maven/2/org/jdesktop/swing-worker/1.1/swing-worker-1.1.jar \n \t3.javaparser-1.0.8.jar   -->  http://java.net/downloads/jpjavaparser/javaparser-1.0.8.jar");




          System.exit(1);
        }
        catch (Exception ex) {
          ex.printStackTrace();
          logger.log(Level.SEVERE, null, ex);
          throw new RuntimeException(ex);
        }  *//*

    }
  }

  //   this.composite = OutputGenerator.generateComposite(this, this.bpelMap, this.jcdMap);
//  }

*/
/*  boolean isUniqueRef(ArrayList<Reference> referencesList, String suggestedName)
  {
    for (Reference reference : referencesList) {
      if (reference.getReferenceName().equals(suggestedName)) {
        return false;
      }
    }
    return true;
  }*//*






  public void getOutputProjectArtifacts()
  {
    for (BPELDocument bpel : this.bpelMap.values()) {
      this.outputProject.addBPEL(bpel.getFileName(), bpel.getStringValue());
    }
    for (WSDLDocument wsdl : this.wsdlMap.values()) {
      Reader reader = new StringReader(wsdl.getStringValue());
      //String wsdlAsString = filterBinding(reader, wsdl.isReference());
      String wsdlAsString =wsdl.getStringValue();
      this.outputProject.addWSDL(wsdl.getFileName(), wsdlAsString);
    }
    for (ComponentType compType : this.componentTypes.values()) {
      this.outputProject.addComponentType(compType.getFileName(), Utility.serializeXML(compType.getDocument()));
    }
*/
/*
    for (SpringContextDocument springxml : this.springcontexts.values()) {
      this.outputProject.addSpringXml(springxml.getSpringName(), Utility.serializeXML(springxml.getDocument()));
    }

    for (Map.Entry<String, JCABinding> jcaBinding : this.jcaBindings.entrySet()) {
      this.outputProject.addJCABinding((String)jcaBinding.getKey(), Utility.serializeXML(((JCABinding)jcaBinding.getValue()).getDocument()));
    }*//*




    this.outputProject.setCompositeFileName(Composite.getFileName());
    this.outputProject.setCompositeValue(Utility.serializeXML(this.composite.getDocument()));
    this.outputProject.setOtherArtifacts(this.sourceProject.getOtherArtifacts());
  }

  public WSDLDocument.PortType getPortType(QName partnerLinkQName, String role) {
    WSDLDocument.PortType pt = null;
    QName portTypeQName = null;
    String plkNamespace = partnerLinkQName.getNamespaceURI();
    for (WSDLDocument wsdl : this.wsdlMap.values()) {
      if (wsdl.getTargetNameSpace().equals(plkNamespace)) {
        portTypeQName = wsdl.getPortTypeQName(partnerLinkQName, role);
        if (portTypeQName != null) {
          return getPortType(wsdl, portTypeQName);
        }
      }
    }
    return pt;
  }

  private WSDLDocument.PortType getPortType(WSDLDocument wsdl, QName portTypeQName)
  {
    WSDLDocument.PortType pt = null;
    pt = wsdl.getPortType(portTypeQName);
    if (pt != null) {
      return pt;
    }

    List<WSDLDocument.Import> imports = wsdl.getImports();
    for (WSDLDocument.Import importt : imports) {
      if (importt.getNameSpace().equals(portTypeQName.getNamespaceURI())) {
        WSDLDocument wsdlDoc = getWSDLDocument(importt.getNameSpace(), importt.getAbsoluteLocation());
        return getPortType(wsdlDoc, portTypeQName);
      }
    }
    return pt;
  }

  public WSDLDocument.PortType getPortType(BPELDocument.PartnerLink ibPlk, String role) {
    return getPortType(ibPlk.getPartnerLinkType(), role);
  }

  */
/*public static String filterBinding(Reader xml, boolean isReference) {
    DOMParser parser = new DOMParser();
    parser.setPreserveWhitespace(true);

    Writer strResult = null;
    BufferedReader bf = new BufferedReader(new InputStreamReader(WSDLParser.class.getResourceAsStream("xsl/bindingfilter.xsl")));

    try
    {
      parser.parse(bf);
      XMLDocument xsldoc = parser.getDocument();
      parser.parse(xml);
      XMLDocument xmldoc = parser.getDocument();


      XSLProcessor processor = new XSLProcessor();

      XSLStylesheet xslstyle = processor.newXSLStylesheet(xsldoc);


      processor.showWarnings(true);
      processor.setErrorStream(System.err);

      processor.setParam("", "Reference", "'" + isReference + "'");
      XMLDocumentFragment result = processor.processXSL(xslstyle, xmldoc);
      strResult = new StringWriter();
      PrintWriter printWriter = new PrintWriter(strResult);
      result.print(printWriter);
    } catch (SAXException ex) {
      logger.log(Level.SEVERE, null, ex);
    } catch (IOException ex) {
      logger.log(Level.SEVERE, null, ex);
    } catch (XSLException ex) {
      logger.log(Level.SEVERE, null, ex);
    }
    return strResult.toString();
  }*//*


  public SourceProject getSourceProject()
  {
    return this.sourceProject;
  }

  public OutputProject getOutputProject() {
    return this.outputProject;
  }

  public void generateOutputFiles() {
    this.outputProject.generateOutputFiles();
  }



  public Map<QName, ComponentType> getComponentTypes()
  {
    return this.componentTypes;
  }

 */
/* public Map<QName, SpringContextDocument> getSpringContextDocument() {
    return this.springcontexts;
  }*//*


  private void reset() {
    this.composite = null;
    getComponentTypes().clear();
    // getSpringContextDocument().clear();
  }

  private void parseWSDLs(SourceProject sourceProject) {
    String tempFolder = sourceProject.getTempLocation();
    String filePath = null;
    for (String file : sourceProject.getWsdlDocuments().keySet()) {
      filePath = tempFolder + File.separator + file;
      WSDLDocument wsdl = WSDLParser.parseWsdlFile(this, filePath);
      wsdl.setFileName(file);
      wsdl.setStringValue(Utility.readFile(filePath));

      if (isCAPSProject()) {
        if (wsdl.getFileName().equalsIgnoreCase("FileClient.wsdl"))
          wsdl.setStringValue(FileWSDLJCAGeneratorForSpring.buildCAPSFileWSDL(null, null, null));
        if (wsdl.getFileName().equalsIgnoreCase("JMS.wsdl"))
          wsdl.setStringValue(JMSWSDLJCAGeneratorForSpring.buildCAPSJMSWSDL());
      }
    }
    for (String file : sourceProject.getWarWsdlDocuments().keySet()) {
      filePath = tempFolder + File.separator + file;
      WSDLDocument wsdl = WSDLParser.parseWsdlFile(this, filePath, true);
      if (wsdl.getFileName() == null) {
        wsdl.setFileName(file);
        wsdl.setFromWar(true);
        wsdl.setStringValue(Utility.readFile(filePath));
      }
    }
  }

  private void parseBPELs(SourceProject sourceProject) throws Exception {
    String bpelFile = null;
    BPELDocument bpel = null;
    String filePath = null;
    String tempFolder = sourceProject.getTempLocation();
    for (String e : sourceProject.getBpelDocuments().keySet()) {
      filePath = tempFolder + File.separator + e;
      logger.fine(" Parsing BPEL " + filePath);
      bpel = BPELParser.parseBPELFile(filePath);
      bpel.setFileName(e);
      if (!e.equals(bpel.getName() + ".bpel")) {
        logger.fine(" BPEL fileName is different from BPEL Process, Using BPEL process as the BPEL Name : " + bpel.getName() + ".bpel");
        bpel.setFileName(bpel.getName() + ".bpel");
      }
      bpelFile = Utility.readFile(filePath);
      bpelFile = replaceFunctoidMarkers(bpelFile);
      bpelFile = Utility.format(bpelFile);

      bpelFile = bpelFile.replaceAll("<assign.*//*
>", "");

      //bpelFile = convertSDTTypes(bpelFile);

      bpelFile = fixWSDLPath(bpelFile);

      bpel.setStringValue(bpelFile);
      this.bpelMap.put(bpel.getQName(), bpel);
    }
  }

  private String replaceFunctoidMarkers(String bpel)
  {
    try {
      bpel = bpel.replace("ENDASSIGNMARKER", "</assign>");
      int startInd = -1;
      while ((startInd = bpel.indexOf("STARTASSIGNMARKER")) > -1) {
        String name = bpel.substring(startInd + "STARTASSIGNMARKER".length(), bpel.indexOf("-END", startInd + "STARTASSIGNMARKER".length()));
        bpel = bpel.replaceFirst("STARTASSIGNMARKER" + name + "-END", "\n<assign name=\"" + name + "\" >");
      }
    } catch (Throwable ignore) {
      ignore.printStackTrace();
    }
    return bpel;
  }

  public static String substringAfterLast(String str, String separator) {
    if ((str == null) || (str.isEmpty())) {
      return str;
    }
    if ((separator == null) || (separator.isEmpty())) {
      return "";
    }
    int pos = str.lastIndexOf(separator);
    if ((pos == -1) || (pos == str.length() - separator.length())) {
      return "";
    }
    return str.substring(pos + separator.length());
  }

  public static String substringBefore(String str, String separator, int fromIndex) {
    if ((str == null) || (str.isEmpty()) || (separator == null) || (separator.isEmpty())) {
      return str;
    }
    int pos = str.indexOf(separator, fromIndex);
    if (pos == -1) {
      return str;
    }
    return str.substring(0, pos);
  }


  private void parseConnectivity(SourceProject sourceProject) { this.jbiXML = ConnectivityParser.getConnections(sourceProject.getTempLocation(), this); }

  private void parseJBIXML(SourceProject sourceProject) {
    if (sourceProject.getJBIXml() == null) {
      throw new RuntimeException("Project does not contain JBI xml file. Please make sure this is a valid JBI zip file.");
    }
    this.jbiXML = JBIXMLParser.getConnections(sourceProject.getJBIXml().getFilePath());
  }

  public JBIXML getJBIXml() {
    return this.jbiXML;
  }

  public Map<WSDLKey, WSDLDocument> getWSDLs() {
    return this.wsdlMap;
  }

  public void addJCABinding(JCABinding binding) {
    this.jcaBindings.put(binding.getFileName(), binding);
  }

  public WSDLDocument getWSDLDocument(QName partnerLinkType) {
    for (WSDLDocument wsdlDocument : this.wsdlMap.values()) {
      WSDLDocument.PartnerLinkType plt = null;
      plt = wsdlDocument.getPartnerLinkType(partnerLinkType);
      if (plt != null) {
        return wsdlDocument;
      }
    }
    return null;
  }

  public WSDLDocument.Service getWSDLService(QName qnServiceName) {
    for (WSDLDocument wsdlDocument : this.wsdlMap.values()) {
      if (wsdlDocument.getTargetNameSpace().equals(qnServiceName.getNamespaceURI())) {
        WSDLDocument.Service service = wsdlDocument.getService(qnServiceName.getLocalPart());
        if (service != null) {
          return service;
        }
      }
    }
    return null;
  }


  public WSDLDocument.Service getWSDLService(ExternalEndpoint source)
  {
    WSDLDocument.Service service = getWSDLService(source.getServiceName());
    if (service == null)
      service = getWSDLServicefromRole(source.getServiceName().getNamespaceURI(), source.getEndpointName());
    return service;
  }


  public WSDLDocument.Service getWSDLServicefromRole(String namespaceURI, String serviceRole)
  {
    for (WSDLDocument wsdlDocument : this.wsdlMap.values()) {
      if (wsdlDocument.getTargetNameSpace().equals(namespaceURI)) {
        String serviceName = "svc" + serviceRole.substring(0, serviceRole.indexOf("Role"));
        WSDLDocument.Service service = wsdlDocument.getService(serviceName);
        if (service != null) {
          return service;
        }
      }
    }

    for (WSDLDocument wsdlDocument : this.wsdlMap.values()) {
      if (wsdlDocument.getTargetNameSpace().equals(namespaceURI)) {
        return wsdlDocument.getFirstService();
      }
    }
    return null;
  }

  public Binding getBinding(QName bindingQName) {
    for (WSDLDocument wsdlDocument : this.wsdlMap.values()) {
      if (wsdlDocument.getTargetNameSpace().equals(bindingQName.getNamespaceURI())) {
        Binding binding = wsdlDocument.getBinding(bindingQName.getLocalPart());
        if (binding != null) {
          return binding;
        }
      }
    }
    for (WSDLDocument wsdlDocument : this.wsdlMap.values()) {
      if (wsdlDocument.getTargetNameSpace().equals(bindingQName.getNamespaceURI())) {
        Binding binding = wsdlDocument.getBindingNoMatch(bindingQName.getLocalPart());
        if (binding != null) {
          return binding;
        }
      }
    }
    return null;
  }

  private void transformWSDLs(SourceProject sourceProject)
  {
    String tempFolder = sourceProject.getTempLocation();
    String filePath = null;

    for (String file : sourceProject.getWsdlDocuments().keySet()) {
      if (!file.equals("Simple Data Types.wsdl"))
      {

        filePath = tempFolder + File.separator + file;
        String wsdlFile = Utility.readFile(filePath);
        //   wsdlFile = transformWSDL(new StringReader(wsdlFile), file);
        Utility.writeOutput(filePath, wsdlFile);
      }
    }
    for (String file : sourceProject.getWarWsdlDocuments().keySet()) {
      if (!file.equals("Simple Data Types.wsdl"))
      {

        filePath = tempFolder + File.separator + file;
        String wsdlFile = Utility.readFile(filePath);
        if (!sourceProject.getWsdlDocuments().containsKey(file)) {
          // wsdlFile = transformWSDL(new StringReader(wsdlFile), file);
          Utility.writeOutput(filePath, wsdlFile);
        }
      }
    }
  }

  private void transformBPELs(SourceProject sourceProject) {
    String bpelFile = null;
    BPELDocument bpel = null;
    String filePath = null;
    String tempFolder = sourceProject.getTempLocation();
    for (String e : sourceProject.getBpelDocuments().keySet()) {
      filePath = tempFolder + File.separator + e;
      bpelFile = Utility.readFile(filePath);

      // bpelFile = transformBPEL(filePath);
      Utility.writeOutput(filePath, bpelFile);
    }
  }

  */
/*public String transformWSDL(Reader xml, String fileName) {
    DOMParser parser = new DOMParser();
    parser.setPreserveWhitespace(true);

    Writer strResult = null;
    BufferedReader bf = new BufferedReader(new InputStreamReader(WSDLParser.class.getResourceAsStream("xsl/TransformWSDL.xsl")));
    String resultString = null;
    try
    {
      parser.parse(bf);
      XMLDocument xsldoc = parser.getDocument();
      parser.parse(xml);
      XMLDocument xmldoc = parser.getDocument();


      XSLProcessor processor = new XSLProcessor();

      processor.setParam("", "plinkdefined", "'false'");


      XSLStylesheet xslstyle = processor.newXSLStylesheet(xsldoc);


      processor.showWarnings(true);
      processor.setErrorStream(System.err);

      XMLDocumentFragment result = processor.processXSL(xslstyle, xmldoc);
      strResult = new StringWriter();
      PrintWriter printWriter = new PrintWriter(strResult);
      result.print(printWriter);

      resultString = strResult.toString();



      resultString = resultString.replace("http://schemas.xmlsoap.org/ws/2002/07/business-process/", "http://docs.oasis-open.org/wsbpel/2.0/varprop");


    }
    catch (SAXException ex)
    {

      logger.log(Level.SEVERE, null, ex);
    } catch (IOException ex) {
      logger.log(Level.SEVERE, null, ex);
    } catch (XSLException ex) {
      logger.log(Level.SEVERE, null, ex);
    }
    return resultString;
  }
*//*

  public static Map<String, String> jcdFaultChanges = new HashMap();

  */
/*public String transformBPEL(String filePath) { TypeParser.scopeCounter = 1;
    OTDXSDDocument.newprefixes = "";
    jcdFaultChanges = new HashMap();

    String bpelx = " xmlns:bpelx=\"http://schemas.oracle.com/bpel/extension\" ";
    String bpelString = Utility.readFile(filePath);
    bpelString = bpelString.replaceFirst("<process ", "<process " + bpelx);

    Reader xml = new StringReader(bpelString);
    DOMParser parser = new DOMParser();
    parser.setPreserveWhitespace(true);

    Writer strResult = null;
    BufferedReader bf = new BufferedReader(new InputStreamReader(WSDLParser.class.getResourceAsStream("xsl/TransformBPEL.xsl")));
    String bpelQualNamespaces = null;
    try
    {
      Map<String, String> bpelNamespaceMap = new HashMap();
      Map<String, String> resultMap = TypeParser.getBPELElemFormDefault(filePath, this, bpelNamespaceMap);
      String elementsFormDefault = (String)resultMap.get("elementsFormDefault");
      String messageTypeParts = (String)resultMap.get("messageTypeParts");
      bpelQualNamespaces = (String)resultMap.get("bpelQualNamespaces");
      String otdClassTypes = "";

      for (String namespace : bpelNamespaceMap.keySet()) {
        if (namespace.startsWith("urn:stc:egate:otd:")) {
          String prefix = (String)bpelNamespaceMap.get(namespace);
          String classname = (String)OTDParser.getOtdpackageMap().get(namespace);
          if ((classname != null) && (!classname.isEmpty()) && (!classname.startsWith("stcgen.fcxotd."))) {
            otdClassTypes = otdClassTypes + prefix + ":" + classname + "|";
          } else if ((classname != null) && (classname.startsWith("stcgen.fcxotd."))) {
            logger.fine(" FCX OTD will not be passed to OTD Marshal/unMarshal java Codelet : " + classname);
          }
        }
      }


      logger.fine(" elementsFormDefault  ---- " + elementsFormDefault);
      logger.fine(" messageTypeParts  ---- " + messageTypeParts);
      logger.fine(" otdClassTypes  ---- " + otdClassTypes);

      parser.parse(bf);
      XMLDocument xsldoc = parser.getDocument();
      parser.parse(xml);
      XMLDocument xmldoc = parser.getDocument();


      XSLProcessor processor = new XSLProcessor();
      elementsFormDefault = "";
      processor.setParam("", "elementsFormDefault", "'" + elementsFormDefault + "'");
      processor.setParam("", "otdClassTypes", "'" + otdClassTypes + "'");
      processor.setParam("", "messageTypeParts", "'" + messageTypeParts + "'");

      if ((Boolean.getBoolean("NOOTDCONVERTION")) || (Boolean.getBoolean("NOOTDOPERATIONCONVERTION"))) {
        processor.setParam("", "otdMigration", "'false'");
      }


      XSLStylesheet xslstyle = processor.newXSLStylesheet(xsldoc);


      processor.showWarnings(true);
      processor.setErrorStream(System.err);

      XMLDocumentFragment result = processor.processXSL(xslstyle, xmldoc);
      strResult = new StringWriter();
      PrintWriter printWriter = new PrintWriter(strResult);
      result.print(printWriter);
    } catch (SAXException ex) {
      Logger.getLogger(MigrationManager.class.getName()).log(Level.SEVERE, null, ex);
    } catch (IOException ex) {
      Logger.getLogger(MigrationManager.class.getName()).log(Level.SEVERE, null, ex);
    } catch (XSLException ex) {
      Logger.getLogger(MigrationManager.class.getName()).log(Level.SEVERE, null, ex);
    }

    String result = strResult.toString();
    result = result.replace("http://schemas.xmlsoap.org/ws/2002/07/business-process/", "http://docs.oasis-open.org/wsbpel/2.0/process/executable");
    result = result.replace("http://schemas.xmlsoap.org/ws/2002/07/business-process", "http://docs.oasis-open.org/wsbpel/2.0/process/executable");


    for (String key : jcdFaultChanges.keySet()) {
      result = result.replace(key, (CharSequence)jcdFaultChanges.get(key));
    }
    jcdFaultChanges.clear();

    String oraext = " xmlns:oraext=\"http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc";
    String ora = " xmlns:ora=\"http://schemas.oracle.com/xpath/extension";
    String xp20 = "xmlns:xp20=\"http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20";

    if (result.indexOf("oraext:") > -1) {
      result = result.replaceFirst("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "http://docs.oasis-open.org/wsbpel/2.0/process/executable\" " + oraext);
    }
    if (result.indexOf("ora:") > -1) {
      result = result.replaceFirst("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "http://docs.oasis-open.org/wsbpel/2.0/process/executable\" " + ora);
    }
    if (result.indexOf("xp20:") > -1) {
      result = result.replaceFirst("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "http://docs.oasis-open.org/wsbpel/2.0/process/executable\" " + xp20);
    }
    if ((bpelQualNamespaces != null) && (bpelQualNamespaces.length() > 1)) {
      result = result.replaceFirst("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "http://docs.oasis-open.org/wsbpel/2.0/process/executable\" " + bpelQualNamespaces);
    }
    if ((OTDXSDDocument.newprefixes != null) && (OTDXSDDocument.newprefixes.length() > 1)) {
      logger.fine(" Addding OTD prefixes " + OTDXSDDocument.newprefixes);
      result = result.replaceFirst("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "http://docs.oasis-open.org/wsbpel/2.0/process/executable\" " + OTDXSDDocument.newprefixes);
    }

    result = result.replace("<copy/>", "");
    result = result.replace("<copy bpelx:insertMissingToData=\"yes\"/>", "");
    result = result.replace("&lt;![CDATA[", "\t\t<![CDATA[");
    result = result.replace("]]&gt;", "\t\t]]>");

    result = result.replace("<forEach name=\"sbynforEach", "</assign>\n<forEach name=\"sbynforEach");
    result = result.replace("</forEach>", "</forEach>\n<assign>");
    if (!Boolean.getBoolean("ignoreaposcheck")) {
      try {
        int quoteInd = 0;
        while ((quoteInd = result.indexOf("''", quoteInd + 1)) > 2) {
          logger.finest("Replacing double ' with \", as -Dignoreaposcheck=true not set");
          if (Character.isLetterOrDigit(result.substring(quoteInd + 2, quoteInd + 20).trim().charAt(0))) {
            int newInd = result.indexOf("'", quoteInd + 2);
            String oldvalue = result.substring(quoteInd, newInd + 5);
            result = result.substring(0, quoteInd) + "'&quot;" + result.substring(quoteInd + 2, newInd) + "'" + result.substring(newInd + 1);
            System.out.println(" Replaced : " + oldvalue + " : by : " + result.substring(quoteInd, newInd + 5) + " , set -Dignoreaposcheck=true to avoid this ");
            logger.finest(" Replaced : " + oldvalue + " : by : " + result.substring(quoteInd, newInd + 5) + " , set -Dignoreaposcheck=true to avoid this ");
          }
        }
      } catch (Exception exp) {
        exp.printStackTrace();
      }
    }

    result = fixWSDLPath(result);

    return result;
  }*//*


  public static boolean isCAPSProject()
  {
    return isCAPSProject;
  }

  public static void setCAPSProject(boolean isCAPSProject) {
    isCAPSProject = isCAPSProject;
  }

  private String fixWSDLPath(String bpelFile) {
    if (!Boolean.getBoolean("ignorefixWSDLPath")) {
      try {
        bpelFile = bpelFile.replace("location=\"../XSD/", "location=\"XSD/");
        bpelFile = bpelFile.replace("location=\"../WSDL/", "location=\"WSDL/");
      } catch (Exception exp) {
        exp.printStackTrace();
      }
    }
    return bpelFile;
  }

  public String generateWSStubAndJAXB(String packageName, String wsdllocation, boolean jaxbInPkg)
          throws Exception
  {
    File libFile = getPatchDir();
    String libpath = libFile.getAbsolutePath();
    String errorStr = null;

    File customJaxbFile = new File(libpath + File.separator + "binding.xjb");
    if (!customJaxbFile.exists()) {
      logger.log(Level.SEVERE, "JAXB custom file was not found at " + customJaxbFile.getAbsolutePath());
      throw new Exception("JAXB custom file was not found at " + customJaxbFile.getAbsolutePath());
    }
    String jaxbPath = customJaxbFile.getAbsolutePath();
    String orasoahome = this.soaHome;


    logger.fine("#### ORACLE SOA HOME is: " + orasoahome + " , jaxb patch dir: " + libpath + " , -- Invoking wsa for " + wsdllocation);
    try
    {
      ProcessCommand cmd = new ProcessCommand();

      if (orasoahome == null) {
        logger.warning("Please provide the parent directory of oracle_common on the command line.");
        throw new Exception("Please provide the parent directory of oracle_common on the command line.");
      }




      if (isWindows()) {
        cmd.add("cmd.exe");
        cmd.add("/c");
      }






      cmd.add("java");
      cmd.add("-Djava.endorsed.dirs=" + libpath);
      cmd.add("-jar");
      cmd.add("wsa.jar");
      cmd.add("jaxwsGenProxy");
      cmd.add("wsdl");
      cmd.add(wsdllocation);
      cmd.add("packageName");
      cmd.add(packageName);
      cmd.add("bindingInfo");
      cmd.add(jaxbPath);
      cmd.add("unwrapParameters");
      cmd.add("false");





      if (jaxbInPkg) {
        cmd.add("valueTypePackagePrefix");
        cmd.add(packageName);
      }


      cmd.add("output");
      cmd.add(this.sourceProject.getOutputSrcPath());
      Map envMap = new HashMap();

      IProcessResults theProcResults = ProcessRunner.runProcess("Generate JAX-WS Stub and JAXB objects", new File(orasoahome + File.separator + "oracle_common" + File.separator + "modules" + File.separator + "oracle.webservices_11.1.1"), cmd, envMap, false);



      String errors = theProcResults.getStdErr().toString();
      String stdouts = theProcResults.getStdOut().toString();

      if (!errors.isEmpty()) {
        logger.warning(" ### Output from the std.err stream :: ");
        logger.warning(errors);
        logger.warning(" ### Output from the std.out stream ::");
        logger.warning(stdouts);
        errorStr = "std.err " + errors + "\n std.out " + stdouts;
      } else {
        logger.fine(" ### Output from the std.out stream ::");
        logger.fine(stdouts);
        errorStr = stdouts;
      }
    }
    catch (Exception ex)
    {
      logger.log(Level.SEVERE, null, ex);
      throw ex;
    }
    return errorStr;
  }

  public static boolean isWindows()
  {
    return System.getProperty("os.name").toLowerCase().contains("windows");
  }

  private static File getPatchDir()
          throws Exception
  {
    File libFile = new File(Migration.getJCAPSLibName() + File.separator + "patches");
    if (!libFile.exists()) {
      String actlibPath = Migration.getRuntimeRoot() + File.separator + Migration.getJCAPSLibName() + File.separator + "patches";
      File actlibFilePath = new File(actlibPath);
      if (actlibFilePath.exists()) {
        libFile = actlibFilePath;
      } else {
        libFile = new File("resources/lib/patches");
        if (!libFile.exists())
          libFile = new File("../resources/lib/patches");
        if (!libFile.exists()) {
          logger.warning("Could not locate the resouces/lib/patches");
          throw new Exception("Could not locate the resouces/lib/patches");
        }
      }
    }
    return libFile;
  }


*/

}


/*import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLDocumentFragment;
import oracle.xml.parser.v2.XSLException;
import oracle.xml.parser.v2.XSLProcessor;
import oracle.xml.parser.v2.XSLStylesheet;*/
