package soa.model;

public class Reference {
  private String type;
  private String name;
  private String name_space;
  private String destination = "test";
  private String fileName = "test";
  
  public void setReferenceType(String type) {
    this.type = type;
  }
  
  public String getReferenceType() { return this.type; }
  
  public void setReferenceName(String name) {
    this.name = name;
  }
  
  public String getReferenceName() { return this.name; }
  
  public void setReferenceNameSpace(String name_space)
  {
    this.name_space = name_space;
  }
  
  public String getReferenceNameSpace() { return this.name_space; }
  
  public void setDestination(String destination) {
    this.destination = destination;
  }
  
  public String getDestination() { return this.destination; }
  
  public void setFileName(String fileName) {
    this.fileName = fileName;
  }
  
  public String getFileName() { return this.fileName; }
}
