package soa.model.binding.soap;

import oracle.migrationtool.parser.model.binding.Binding;
import oracle.migrationtool.parser.model.binding.ConcreteBinding;


public class SOAPBinding
  extends ConcreteBinding
{
  public SOAPBinding(Binding binding)
  {
    super(binding);
  }
}
