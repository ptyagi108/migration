package soa.model.binding;

public abstract class Address {}
