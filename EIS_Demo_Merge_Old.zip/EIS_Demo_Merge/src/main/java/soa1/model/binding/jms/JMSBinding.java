package soa.model.binding.jms;

import oracle.migrationtool.parser.model.binding.Binding;
import oracle.migrationtool.parser.model.binding.ConcreteBinding;


public class JMSBinding
  extends ConcreteBinding
{
  public JMSBinding(Binding binding)
  {
    super(binding);
  }
}
