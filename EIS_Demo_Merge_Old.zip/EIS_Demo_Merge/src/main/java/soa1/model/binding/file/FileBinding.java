package soa.model.binding.file;

import soa.model.binding.Binding;
import soa.model.binding.ConcreteBinding;

public class FileBinding
  extends ConcreteBinding
{
  public FileBinding(Binding binding)
  {
    super(binding);
  }
}
