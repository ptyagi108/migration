package soa.model.binding.soap;

import soa.model.binding.Address;


public class SOAPAddress
  extends Address
{
  private String location;
  
  public SOAPAddress(String location)
  {
    this.location = location;
  }
  
  public String getLocation() {
    return this.location;
  }
}
