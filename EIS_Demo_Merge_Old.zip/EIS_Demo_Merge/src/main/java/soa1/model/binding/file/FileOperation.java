package soa.model.binding.file;

//import oracle.migrationtool.parser.model.binding.ConcreteOperation;


import soa.model.binding.ConcreteOperation;

public class FileOperation
  extends ConcreteOperation
{
  String verb;
  
  public void setVerb(String verb)
  {
    this.verb = verb;
  }
  
  public String getVerb() {
    return this.verb;
  }
}
