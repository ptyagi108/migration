package soa.model.binding.file;

import oracle.migrationtool.parser.model.binding.Address;


public class FileAddress
  extends Address
{
  protected String fileDirectory;
  protected String recursive;
  protected String archiveFileDirectory;
  
  public String getRecursive()
  {
    return this.recursive;
  }
  




  public void setRecursive(String recursive)
  {
    this.recursive = recursive;
  }
  




  public String getFileDirectory()
  {
    return this.fileDirectory;
  }
  




  public void setFileDirectory(String fileDirectory)
  {
    this.fileDirectory = fileDirectory;
  }
  
  public String getArchiveFileDirectory() {
    return this.archiveFileDirectory;
  }
  
  public void setArchiveFileDirectory(String archiveFileDirectory) {
    this.archiveFileDirectory = archiveFileDirectory;
  }
}
