package soa.model.binding.jms;

import oracle.migrationtool.parser.model.binding.Address;


public class JMSAddress
  extends Address
{
  protected String connectionURL;
  protected String username;
  protected String password;
  
  public String getPassword()
  {
    return this.password;
  }
  




  public void setPassword(String password)
  {
    this.password = password;
  }
  




  public String getUsername()
  {
    return this.username;
  }
  




  public void setUsername(String username)
  {
    this.username = username;
  }
  





  public String getConnectionURL()
  {
    return this.connectionURL;
  }
  




  public void setConnectionURL(String connectionURL)
  {
    this.connectionURL = connectionURL;
  }
}
