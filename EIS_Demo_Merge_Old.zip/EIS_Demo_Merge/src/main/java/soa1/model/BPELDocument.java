package soa.model;

import javax.xml.namespace.QName;
import java.util.Map;

public class BPELDocument
{
  protected String name;
  protected String location;
  protected String fileName;
  protected String targetNameSpace;
  QName qName;
  String stringValue;
  public BPELDocument() {}

  public static enum PARTNERLINK_TYPE
  {
    SERVICE,  REFERENCE;
    private PARTNERLINK_TYPE() {}
  }

  Map<String, PartnerLink> partnerLinks = new java.util.HashMap();


  Map<String, String> prefixNSMap;
  Map<String, WSDLDocument> wsdlsMap;
  public BPELDocument(String name, String targetNameSpace, String location)
  {
    this.name = name;
    this.targetNameSpace = targetNameSpace;
    this.location = location;
    this.qName = new QName(targetNameSpace, name);
  }

  public void addPrefixNS(String prefix, String namespace) {
    if (!this.prefixNSMap.containsKey(prefix)) {
      this.prefixNSMap.put(prefix, namespace);
    }
  }

  public void addWsdl(String namespace, WSDLDocument wsdl) {
    if (!this.wsdlsMap.containsKey(namespace)) {
      this.wsdlsMap.put(namespace, wsdl);
    }
  }

  public WSDLDocument getWSDLDocument(String namespace) {
    return (WSDLDocument)this.wsdlsMap.get(namespace);
  }

  public String getName() {
    return this.name;
  }

  public String getLocation() {
    return this.location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getTargetNameSpace() {
    return this.targetNameSpace;
  }

  public void addPartnerLink(PartnerLink plk) {
    this.partnerLinks.put(plk.getQName().getLocalPart(), plk);
  }

  public PartnerLink getPartnerLink(String partnerLink) {
    return (PartnerLink)this.partnerLinks.get(partnerLink);
  }

  public Map<String, PartnerLink> getPartnerLinks() {
    return this.partnerLinks;
  }

  public QName getQName() {
    return this.qName;
  }



  public String getStringValue()
  {
    return this.stringValue;
  }



 /* public void setStringValue(String stringValue)
  {
    if (oracle.migrationtool.parser.MigrationManager.isCAPSProject()) {
      for (PartnerLink plt : this.partnerLinks.values()) {
        if (plt.getPartnerRole() != null) {
          String partnerLinkName = plt.getQName().getLocalPart();
          int indexStart = stringValue.indexOf("<partnerLink name=\"" + partnerLinkName + "\"");
          String partnerLinkString = stringValue.substring(indexStart);
          int replaceIndex = partnerLinkString.indexOf("myRole=\"" + plt.getPartnerRole() + "\"");
          String replaceString = partnerLinkString.substring(0, replaceIndex);
          stringValue = stringValue.replace(replaceString + "myRole=\"" + plt.getPartnerRole() + "\"/>", replaceString + "partnerRole=\"" + plt.getPartnerRole() + "\"/>");
        }
      }
    }


    this.stringValue = stringValue;
  } */



  public String getFileName()
  {
    return this.fileName;
  }



  public void setFileName(String fileName)
  {
    this.fileName = fileName;
  }



  public  class PartnerLink
  {
    final QName partnerLinkType;

    String myRole;

    String partnerRole;

    final QName qName;

    boolean isInUse = false;

    private BPELDocument.PARTNERLINK_TYPE type;

    public PartnerLink(String name, QName partnerLinkType, String myRole, String partnerRole)
    {
      this.partnerLinkType = partnerLinkType;
      this.myRole = myRole;
      this.partnerRole = partnerRole;
      this.qName = new QName(BPELDocument.this.targetNameSpace, name);
    }

    public QName getPartnerLinkType() {
      return this.partnerLinkType;
    }

    public String getMyRole() {
      return this.myRole;
    }

    public String getPartnerRole() {
      return this.partnerRole;
    }

    public void setMyRole(String myRole) {
      this.myRole = myRole;
    }

    public void setPartnerRole(String partnerRole) {
      this.partnerRole = partnerRole;
    }

    public QName getQName() {
      return this.qName;
    }

    public String getTargetNameSpace() {
      return BPELDocument.this.targetNameSpace;
    }

    public BPELDocument.PARTNERLINK_TYPE getType() {
      return this.type;
    }

    public void setType(BPELDocument.PARTNERLINK_TYPE type) {
      this.type = type;
    }

    public BPELDocument getBPELDocument() {
      return BPELDocument.this;
    }

    public void setIsInUse(boolean inUseFlag) {
      this.isInUse = inUseFlag;
    }

    public boolean getIsInUse() {
      return this.isInUse;
    }
  }

  public class MessagingActivities
  {
    String name;
    String partnerLink;
    String operation;
    QName portType;

    public MessagingActivities(String name, String partnerLink, String operation, QName portType)
    {
      this.name = name;
      this.partnerLink = partnerLink;
      this.operation = operation;
      this.portType = portType;
    }
  }
}
