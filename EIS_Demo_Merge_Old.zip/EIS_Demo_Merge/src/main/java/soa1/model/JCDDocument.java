package soa.model;

/*import oracle.migrationtool.parser.DescriptorParser;
import oracle.migrationtool.parser.DescriptorParser.DescriptorMap;
import oracle.migrationtool.parser.DescriptorParser.DescriptorMap.EndPointDescriptor;*/

import javax.xml.namespace.QName;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


public class JCDDocument
  extends BPELDocument
{
  protected String packageName;
  String stringValue;
  Map<QName, BPELDocument> bpelMap;
  private String jcdName;
  private String CollaborationName;
  private boolean isBPCallingJCD = false;
  private HashMap<String, Object> jcdParserMap;
  private boolean isJCDWS = false;

  private QName serviceName;
  private String runtimeHandlerPath;

  public JCDDocument(String name, String fileName, String targetNameSpace, String location, String packageName)
  {
    this.name = name;
    this.jcdName = fileName.substring(0, fileName.indexOf(".java"));
    this.fileName = fileName;
    this.targetNameSpace = targetNameSpace;
    this.location = location;
    this.qName = new QName(targetNameSpace, name);
    setServiceName(new QName(targetNameSpace, this.jcdName));
    this.packageName = packageName;
    this.wsdlsMap = new HashMap();
    this.bpelMap = new HashMap();
    this.CollaborationName = name;

    /*Map<String, DescriptorParser.DescriptorMap.EndPointDescriptor> descriptors = DescriptorParser.DescriptorMap.descriptors;
    Set<String> keys = descriptors.keySet();






    for (String key : keys) {
      DescriptorParser.DescriptorMap.EndPointDescriptor end_point = (DescriptorParser.DescriptorMap.EndPointDescriptor)descriptors.get(key);
      String jcdKey = this.name;
      String collab_name = end_point.getProperty(jcdKey, null);
      if (collab_name != null) {
        Map context_map = end_point.getDescriptor();
        if (context_map.get("stc/context/CollabrationName") != null)
          setCollaborationName(context_map.get("stc/context/CollabrationName") + "");
        this.qName = new QName(targetNameSpace, this.CollaborationName);
        break;
      }
    }*/
  }


  public boolean isJCDWS()
  {
    return this.isJCDWS;
  }



  public void setJCDWS(boolean isJCDWS)
  {
    this.isJCDWS = isJCDWS;
  }



  public HashMap<String, Object> getJcdParserMap()
  {
    return this.jcdParserMap;
  }



  public void setJcdParserMap(HashMap<String, Object> jcdParserMap)
  {
    this.jcdParserMap = jcdParserMap;
  }



  public boolean isBPCallingJCD()
  {
    return this.isBPCallingJCD;
  }

  public void setBPCallingJCD(boolean isBPCallingJCD) {
    this.isBPCallingJCD = isBPCallingJCD;
  }

  public Map<QName, BPELDocument> getBpelMap() {
    return this.bpelMap;
  }

  public void setBpelMap(Map<QName, BPELDocument> bpelMap) {
    this.bpelMap = bpelMap;
  }

  public String getJcdName() {
    return this.jcdName;
  }

  public void setJcdName(String jcdName) {
    this.jcdName = jcdName;
  }

  public void setCollaborationName(String collaborationName) {
    this.CollaborationName = collaborationName;
  }

  public String getCollaborationName() {
    return this.CollaborationName;
  }

  public String getRuntimeHandlerPath()
  {
    return this.runtimeHandlerPath;
  }

  public void setRuntimeHandlerPath(String path) {
    this.runtimeHandlerPath = path;
  }

  public void addWsdl(String namespace, WSDLDocument wsdl) {
    if (!this.wsdlsMap.containsKey(namespace)) {
      this.wsdlsMap.put(namespace, wsdl);
    }
  }

  public WSDLDocument getWSDLDocument(String namespace) {
    return (WSDLDocument)this.wsdlsMap.get(namespace);
  }

  public void addBpel(QName namespace, BPELDocument bpel)
  {
    if (!this.bpelMap.containsKey(namespace)) {
      this.bpelMap.put(namespace, bpel);
    }
  }

  public BPELDocument getBPELDocument(QName namespace) {
    return (BPELDocument)this.bpelMap.get(namespace);
  }

  public String getName() {
    return this.name;
  }

  public String getTargetNameSpace() {
    return this.targetNameSpace;
  }

  public void setTargetNameSpace(String tns) {
    this.targetNameSpace = tns;
  }

  public QName getQName() {
    return this.qName;
  }

  public void setQName(QName qname) {
    this.qName = qname;
  }



  public String getStringValue()
  {
    return this.stringValue;
  }



  public void setStringValue(String stringValue)
  {
    this.stringValue = stringValue;
  }



  public String getFileName()
  {
    return this.fileName;
  }



  public void setFileName(String fileName)
  {
    this.fileName = fileName;
  }

  public String getPackageName()
  {
    return this.packageName;
  }

  public void setPackageName(String packageName) {
    this.packageName = packageName;
  }

  public QName getServiceName()
  {
    return this.serviceName;
  }

  public void setServiceName(QName serviceName)
  {
    this.serviceName = serviceName;
  }
}
