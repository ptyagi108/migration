package soa.model.project;

import com.sun.org.apache.bcel.internal.classfile.Utility;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
//import java.util.logging.Level;
//import java.util.logging.Logger;

public class OutputProject

{
    String projectName;
    String projectFolder;
    String compositeFileName;
    String compositeValue;
    Map<String, String> wsdlDocuments = new HashMap();
    Map<String, String> bpelDocuments = new HashMap();
    Map<String, String> componentTypes = new HashMap();
    Map<String, String> jcaBindings = new HashMap();
    Map<String, String> otherArtifacts = new HashMap();
    Map<String, String> springxmlArtifacts = new HashMap();
    public String outputProjectFullPath = null;




    public OutputProject(String projName, String folder)
    {
        this.projectName = projName;
        this.projectFolder = folder;
    }

    public String getOutputProjectFullPath()
    {
        return this.projectFolder + File.separator + this.projectName;
    }

    public void setOutputProjectFullPath(String outputProjectFullPath) {
        this.outputProjectFullPath = outputProjectFullPath;
    }

    public String getProjectName() {
        return this.projectName;
    }

    public String getProjectFolder() {
        return this.projectFolder;
    }

    public String getCompositeFileName() {
        return this.compositeFileName;
    }

    public void setCompositeFileName(String composite) {
        this.compositeFileName = composite;
    }

    public String getCompositeValue() {
        return this.compositeValue;
    }

    public void setCompositeValue(String compositeValue) {
        this.compositeValue = compositeValue;
    }

    public void setOtherArtifacts(Map<String, String> otherArtifacts) {
        this.otherArtifacts.putAll(otherArtifacts);
    }

    public Map<String, String> getOtherArtifacts() {
        return this.otherArtifacts;
    }

    public void addJCABinding(String name, String jcaBindingXML) {
        this.jcaBindings.put(name, jcaBindingXML);
    }

    public void addBPEL(String name, String contents) {
        this.bpelDocuments.put(name, contents);
    }

    public void addWSDL(String name, String contents) {
        this.wsdlDocuments.put(name, contents);
    }

    public void addComponentType(String name, String contents) {
        this.componentTypes.put(name, contents);
    }

    public void addSpringXml(String name, String contents) {
        this.springxmlArtifacts.put(name, contents);
    }

    public Map<String, String> getBpelDocuments() {
        return this.bpelDocuments;
    }

    public Map<String, String> getComponentTypes() {
        return this.componentTypes;
    }

    public Map<String, String> getSpringXml() {
        return this.springxmlArtifacts;
    }

    public Map<String, String> getWsdlDocuments() {
        return this.wsdlDocuments;
    }

    public Map<String, String> getJCABindings() {
        return this.jcaBindings;
    }



    public void generateOutputFiles() {
        File outputDir = new File(this.projectFolder, this.projectName);
        for (Map.Entry<String, String> e : this.wsdlDocuments.entrySet()) {
            writeOutput(outputDir, (String)e.getKey(), (String)e.getValue());
        }
        for (Map.Entry<String, String> e : this.bpelDocuments.entrySet()) {
            writeOutput(outputDir, (String)e.getKey(), (String)e.getValue());
        }
        for (Map.Entry<String, String> e : this.componentTypes.entrySet()) {
            writeOutput(outputDir, (String)e.getKey(), (String)e.getValue());
        }
        for (Map.Entry<String, String> e : this.springxmlArtifacts.entrySet())
        {
            writeOutput(outputDir, (String)e.getKey() + ".xml", (String)e.getValue());
        }

        for (Map.Entry<String, String> e : this.jcaBindings.entrySet()) {
            writeOutput(outputDir, (String)e.getKey(), (String)e.getValue());
        }
        for (Map.Entry<String, String> e : this.otherArtifacts.entrySet()) {
            writeOutput(outputDir, (String)e.getKey(), (String)e.getValue());
        }
        writeOutput(outputDir, this.compositeFileName, this.compositeValue);

        generateProjectFile();
    }

    private void writeOutput(File outputDir, String fileName, String value) {
        FileWriter writer = null;
        try {
            File output = new File(outputDir, fileName);

            File fParent = new File(output.getParent());
            fParent.mkdirs();






            if (output.exists()) {
                return;
            }

            if (!output.createNewFile()) {
                throw new RuntimeException("Unable to create file, please check your folder persmissions");
            }
            writer = new FileWriter(output);
            BufferedWriter out = new BufferedWriter(writer);
         //   out.write(Utility.format(value));
            out.flush(); return;
        } catch (IOException ex) {
            Logger.getLogger(OutputProject.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(OutputProject.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void clear()
    {
        this.wsdlDocuments.clear();
        this.bpelDocuments.clear();
        this.componentTypes.clear();
        this.jcaBindings.clear();
        this.otherArtifacts.clear();
        this.springxmlArtifacts.clear();


        this.compositeValue = null;
        this.outputProjectFullPath = null;
        this.projectFolder = null;
        this.projectName = null;
    }


    private void generateProjectFile()
    {
        File sca_dir = new File(getOutputProjectFullPath() + File.separator + "SCA-INF/lib");

        File[] list = sca_dir.listFiles();

        String project_file_name = getOutputProjectFullPath() + File.separator + getProjectName() + ".jpr";
        File jpr = new File(project_file_name);
        try {
            jpr.createNewFile();
            FileOutputStream out = new FileOutputStream(project_file_name);
            out.write(this.JPR_SECTION_1.getBytes("UTF-8"));
            out.write(new String("<value n=\"defaultPackage\" v=\"" + getProjectName().toLowerCase() + "\"/>\n").getBytes("UTF-8"));
            out.write(this.JPR_SECTION_2.getBytes("UTF-8"));
            out.write(new String("<hash n=\"" + getProjectName() + "\">\n").getBytes("UTF-8"));
            out.write(this.JPR_SECTION_3.getBytes("UTF-8"));
            out.write(new String("<url n=\"jarURL\" path=\"deploy/sca_" + getProjectName() + "${composite.revision_id}.jar\"/>\n").getBytes("UTF-8"));
            out.write(this.JPR_SECTION_4.getBytes("UTF-8"));
            out.write(new String("<value n=\"profileName\" v=\"" + getProjectName() + "\"/>\n").getBytes("UTF-8"));
            out.write(this.JPR_SECTION_5.getBytes("UTF-8"));
            out.write(new String("<string v=\"" + getProjectName() + "\"/>\n" + "</list>\n" + "</hash>\n" + "<hash n=\"oracle.jdeveloper.model.J2eeSettings\">\n" + "<value n=\"j2eeWebAppName\" v=\"Application1-" + getProjectName() + "-webapp\"/>\n" + "<value n=\"j2eeWebContextRoot\" v=\"Application1-" + getProjectName() + "-context-root\"/>\n" + "</hash>\n").getBytes("UTF-8"));






            out.write(this.JPR_SECTION_6.getBytes("UTF-8"));

            if (list != null) {
                for (File file : list) {
                    if ((file.isFile()) && (file.getName().endsWith(".jar")))
                    {
                        out.write(new String("<hash>\n<value n=\"id\" v=\"" + file.getName() + "\"/>\n" + "<value n=\"isJDK\" v=\"false\"/>\n" + "</hash>\n").getBytes("UTF-8"));
                    }
                }
            }




            out.write(this.JPR_SECTION_7_BEGIN.getBytes("UTF-8"));

            if (list != null) {
                for (File file : list) {
                    if ((file.isFile()) && (file.getName().endsWith(".jar")))
                    {
                        out.write(new String("<hash>\n<list n=\"classPath\">\n<url path=\"SCA-INF/lib/" + file.getName() + "\" jar-entry=\"\"/>\n" + "</list>\n" + "<value n=\"deployedByDefault\" v=\"true\"/>\n" + "<value n=\"description\" v=\"" + file.getName() + "\"/>\n" + "<value n=\"id\" v=\"" + file.getName() + "\"/>\n" + "<value n=\"locked\" v=\"true\"/>\n" + "</hash>\n").getBytes("UTF-8"));
                    }
                }
            }









            out.write(this.JPR_SECTION_7_END.getBytes("UTF-8"));

            out.write(this.JPR_SECTION_8_BEGIN.getBytes("UTF-8"));

            if (list != null) {
                for (File file : list) {
                    if ((file.isFile()) && (file.getName().endsWith(".jar")))
                    {
                        out.write(new String("<hash>\n<value n=\"id\" v=\"" + file.getName() + "\"/>\n" + "<value n=\"isJDK\" v=\"false\"/>\n" + "</hash>\n").getBytes("UTF-8"));
                    }
                }
            }





            out.write(this.JPR_SECTION_8_END.getBytes("UTF-8"));

            out.write(this.JPR_SECTION_9.getBytes("UTF-8"));
            out.close();
        } catch (Exception e) {
            System.out.println("Failed to create/write file: " + e.getMessage());
        }
    }

    private String JPR_SECTION_1 = "<?xml version = '1.0' encoding = 'UTF-8'?>\n<jpr:project xmlns:jpr=\"http://xmlns.oracle.com/ide/project\">\n<hash n=\"component-versions\">\n<value n=\"oracle.adfdt.controller.adfc.source.migration.AdfControllerSchemaMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdt.controller.common.migrator.ProjectMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdt.controller.jsf2.diagram.migrate.JsfNodeMigratorHelper\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdt.controller.struts.addin.db.ADFStrutsProjectMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdt.controller.struts.addin.StrutsProjectMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdtinternal.dvt.datapresdt.migration.DVTDataMapMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdtinternal.model.ide.migration.ProjectMigrator\" v=\"11.1.1.1.0.11.1.1\"/>\n<value n=\"oracle.adfdtinternal.model.ide.security.wizard.FormPageMigrator\" v=\"11.1.1.0.0\"/>\n<value n=\"oracle.adfdtinternal.model.ide.security.wizard.JpsFilterMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdtinternal.model.ide.xmled.migration.ADFNodeMigrator\" v=\"11.1.1.1.0.5\"/>\n<value n=\"oracle.adfdtinternal.model.ide.xmled.migration.PageDefinitionParameterValueMigrator\" v=\"11.1.1.1.0.5\"/>\n<value n=\"oracle.adfdtinternal.model.ide.xmled.migration.WebXmlMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdtinternal.view.common.migration.wizards.MigrationHelper\" v=\"11.1.1.1.0.3\"/>\n<value n=\"oracle.adfdtinternal.view.rich.binding.migration.JarResourceMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.adfdtinternal.view.rich.migration.ComponentIdNodeMigratorHelper\" v=\"11.1.1.1.0.01\"/>\n<value n=\"oracle.adfdtinternal.view.rich.migration.LibraryVersionMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.bm.commonIde.ProjectUpgrader\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.bm.migration.project.MigratorRegistryProjectUpgradeAdapter\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.ide.model.Project\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.ide.model.ResourcePathsMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jbo.dt.jclient.migrator.JCProjectMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jbo.dt.jdevx.deployment.JbdProjectMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jbo.dt.jdevx.ui.appnav.APProjectMigrator\" v=\"11.1.1.0.1.5\"/>\n<value n=\"oracle.jbo.dt.migrate.ResourceBundlePathMigrator\" v=\"11.1.1.1.0.5\"/>\n<value n=\"oracle.jbo.dt.migration.ServiceInterfaceMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdeveloper.ejb.EjbMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdeveloper.library.ProjectLibraryMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdeveloper.model.OutputDirectoryMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdevimpl.deploy.DeploymentProfilesMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdevimpl.deploy.jps.JpsDataMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdevimpl.jsp.JspMigrator\" v=\"11.1.1\"/>\n<value n=\"oracle.jdevimpl.offlinedb.migration.OfflineDBProjectMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdevimpl.offlinedb.migration.OfflineTransferMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdevimpl.resourcebundle.XliffAddin$XliffMigratorHelper\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdevimpl.webapp.jsp.libraries.JspLibraryMigrator\" v=\"11.1.1.1.4\"/>\n<value n=\"oracle.jdevimpl.webapp.WebAppContentSetNodeMigratorHelper\" v=\"11.1.1\"/>\n<value n=\"oracle.jdevimpl.webapp.WebAppNodeMigratorHelper\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdevimpl.webservices.WebServicesMigratorHelper\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.jdevimpl.xml.wl.WeblogicMigratorHelper\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.modeler.bmmigrate.management.Migration\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.tip.tools.ide.bpel.v1.designer.addin.migrator.BPELProjectMigrator\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.tip.tools.ide.fabric.addin.SCAProjectMigrator\" v=\"11.1.1.1.0.06\"/>\n<value n=\"oracle.tip.tools.ide.workflow.addin.TaskFormMigratorAddin\" v=\"11.1.1.1.0\"/>\n<value n=\"oracle.tip.tools.ide.workflow.addin.WorkflowProjectMigrator\" v=\"11.1.1.1.0.09;11.1.1.1.0.10\"/>\n<value n=\"oracle.toplink.workbench.addin.migration.PersistenceProjectMigrator\" v=\"11.1.1.1.1\"/>\n<value n=\"oracle.toplink.workbench.addin.migration.TopLinkProjectMigrator\" v=\"11.1.1.1.0\"/>\n</hash>\n<list n=\"contentSets\">\n<string v=\"oracle.jdeveloper.model.PathsConfiguration/javaContentSet\"/>\n<string v=\"oracle.ide.model.ResourcePaths/resourcesContentSet\"/>\n<string v=\"oracle.jdeveloper.offlinedb.model.OfflineDBProjectSettings/offlineDBContentSet\"/>\n<string v=\"oracle.jdeveloper.model.J2eeSettings/webContentSet\"/>\n<string v=\"oracle.mds.internal.dt.ide.MDSLibraryCustCSProvider/mdsContentSet\"/>\n<string v=\"oracle.bm.commonIde.data.project.ModelerProjectSettings/modelersContentSet\"/>\n<string v=\"oracle.adfdtinternal.model.ide.settings.ADFMSettings/adfmContentSet\"/>\n<string v=\"oracle.toplink.workbench.addin/toplinkContentSet\"/>\n<string v=\"oracle.tip.tools.ide.fabric.addin.SCAContentSetProvider/sca-content\"/>\n</list>\n";





























































    private String JPR_SECTION_2 = "<hash n=\"oracle.ide.model.ResourcePaths\">\n<hash n=\"resourcesContentSet\">\n<list n=\"url-path\"/>\n</hash>\n</hash>\n<hash n=\"oracle.ide.model.TechnologyScopeConfiguration\">\n<list n=\"technologyScope\">\n<string v=\"SOA\"/>\n</list>\n</hash>\n<hash n=\"oracle.jdeveloper.compiler.OjcConfiguration\">\n<list n=\"copyRes\">\n<string v=\".gif\"/>\n<string v=\".jpg\"/>\n<string v=\".jpeg\"/>\n<string v=\".png\"/>\n<string v=\".properties\"/>\n<string v=\".xml\"/>\n<string v=\".ejx\"/>\n<string v=\".xcfg\"/>\n<string v=\".cpx\"/>\n<string v=\".dcx\"/>\n<string v=\".sva\"/>\n<string v=\".wsdl\"/>\n<string v=\".ini\"/>\n<string v=\".tld\"/>\n<string v=\".tag\"/>\n<string v=\".xlf\"/>\n<string v=\".xsl\"/>\n<string v=\".xsd\"/>\n<string v=\".exm\"/>\n<string v=\".xml\"/>\n</list>\n<value n=\"internalEncoding\" v=\"Cp1252\"/>\n<list n=\"Javac.commandline.optionlist\">\n<string v=\"-g\"/>\n<string v=\"-Xlint:all\"/>\n<string v=\"-Xlint:-cast\"/>\n<string v=\"-Xlint:-empty\"/>\n<string v=\"-Xlint:-fallthrough\"/>\n<string v=\"-Xlint:-path\"/>\n<string v=\"-Xlint:-serial\"/>\n<string v=\"-Xlint:-unchecked\"/>\n</list>\n<value n=\"webIANAEncoding\" v=\"windows-1252\"/>\n</hash>\n<hash n=\"oracle.jdeveloper.deploy.dt.DeploymentProfiles\">\n<hash n=\"profileDefinitions\">\n";

















































    private String JPR_SECTION_3 = "<hash n=\"archiveOptions\">\n<value n=\"hasManifest\" v=\"false\"/>\n</hash>\n<hash n=\"fileGroups\">\n<list n=\"groups\">\n<hash>\n<list n=\"contributors\">\n<hash>\n<url n=\"location\" path=\".\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n</list>\n<value n=\"displayName\" v=\"SOA Files\"/>\n<hash n=\"filters\">\n<list n=\"rules\">\n<hash>\n<value n=\"pattern\" v=\"SCA-INF/bpel\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\".migrated/jaxb_classes\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\".rulesdesigner/jaxb_classes\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"merged\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"mdssys\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\".designer\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"SCA-INF/file-layer-registry.xml\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"SCA-INF/classes/scac.log\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"SCA-INF/classes/scac_out.xml\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"*.jpr\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"deploy/\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"WEB-INF/temp/**\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"WEB-INF/classes/jsp_servlet/**\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\".wlsjsps/\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\".wlLibs/\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**/.svn/\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**/CVS/\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**/.ade_path\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**/.data/**\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**.cdi\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**.contrib\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**.keep\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**.rvi\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\".jsps/\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\".tags/\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\".dtags/\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**/*.jht\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**/*.jjt\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**/*.jxt\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n<hash>\n<value n=\"pattern\" v=\"**\"/>\n</hash>\n</list>\n</hash>\n<value n=\"internalName\" v=\"sar-files\"/>\n<value n=\"type\" v=\"1\"/>\n</hash>\n</list>\n</hash>\n";














































































































































    private String JPR_SECTION_4 = "<hash n=\"libraryDependencies\">\n<value n=\"IncludeLibrariesFromOtherContainers\" v=\"true\"/>\n</hash>\n<value n=\"profileClass\" v=\"oracle.tip.tools.ide.fabric.deploy.sar.SarProfile\"/>\n";





    private String JPR_SECTION_5 = "</hash>\n</hash>\n<list n=\"profileList\">\n";




    private String JPR_SECTION_6 = "<hash n=\"oracle.jdeveloper.model.PathsConfiguration\">\n<hash n=\"javaContentSet\">\n<list n=\"constituent-sets\">\n<hash>\n<list n=\"pattern-filters\">\n<string v=\"+**\"/>\n</list>\n<list n=\"url-path\">\n<url path=\"src/\"/>\n</list>\n</hash>\n<hash>\n<list n=\"pattern-filters\">\n<string v=\"+**\"/>\n</list>\n<list n=\"url-path\">\n<url path=\"SCA-INF/src/\"/>\n</list>\n</hash>\n</list>\n<list n=\"url-path\"/>\n</hash>\n</hash>\n<hash n=\"oracle.jdeveloper.runner.RunConfigurations\">\n<hash n=\"runConfigurationDefinitions\">\n<hash n=\"Default\">\n<value n=\"custom\" v=\"false\"/>\n<value n=\"name\" v=\"Default\"/>\n</hash>\n</hash>\n<list n=\"runConfigurationList\">\n<string v=\"Default\"/>\n</list>\n</hash>\n<hash n=\"oracle.jdevimpl.config.JProjectLibraries\">\n<list n=\"exportedReferences\">\n<hash>\n<value n=\"id\" v=\"SOA Designtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n<hash>\n<value n=\"id\" v=\"SOA Runtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n<hash>\n<value n=\"id\" v=\"BPEL Runtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n<hash>\n<value n=\"id\" v=\"Mediator Runtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n<hash>\n<value n=\"id\" v=\"MDS Runtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n";

























































    private String JPR_SECTION_7_BEGIN = "</list>\n<hash n=\"internalDefinitions\">\n<list n=\"libraryDefinitions\">\n";




    private String JPR_SECTION_7_END = "</list>\n</hash>\n";



    private String JPR_SECTION_8_BEGIN = "<list n=\"libraryReferences\">\n<hash>\n<value n=\"id\" v=\"SOA Designtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n<hash>\n<value n=\"id\" v=\"SOA Runtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n<hash>\n<value n=\"id\" v=\"BPEL Runtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n<hash>\n<value n=\"id\" v=\"Mediator Runtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n<hash>\n<value n=\"id\" v=\"MDS Runtime\"/>\n<value n=\"isJDK\" v=\"false\"/>\n</hash>\n";
























    private String JPR_SECTION_8_END = "</list>\n</hash>\n";




    private String JPR_SECTION_9 = "<hash n=\"oracle.jdevimpl.config.JProjectPaths\">\n<url n=\"outputDirectory\" path=\"SCA-INF/classes/\"/>\n</hash>\n<hash n=\"oracle.tip.tools.ide.fabric.addin.SCAContentSetProvider\">\n<hash n=\"sca-content\">\n<list n=\"url-path\">\n<url path=\".\"/>\n</list>\n</hash>\n</hash>\n</jpr:project>\n";
}
