package soa.model.project;

/**
 * Created by Manoj_Mehta on 3/28/2017.
 */
public interface Project {
    public abstract String getProjectName();
    public abstract String getProjectFolder();
}
