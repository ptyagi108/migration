package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.Model.RdvPublishActivity;
import com.dell.dims.ModelConfig.RdvActivityConfig;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.Map;

//import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class RdvPublishActivityParser implements IActivityParser
{
    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        RdvPublishActivity publishActivity = new RdvPublishActivity();

        String nodeStr=NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("sharedChannel", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.sharedChannel")))
                    .extract("xmlEncoding", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.xmlEncoding")))
                    .asMap();
        }

        publishActivity.setName(activityMap.get("name"));
        publishActivity.setType(new ActivityType(activityMap.get("type")));
        publishActivity.setSharedChannel(activityMap.get("sharedChannel"));
        publishActivity.setXmlEncode(Boolean.parseBoolean(activityMap.get("xmlEncoding")));
        publishActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,publishActivity);
        publishActivity.setInputBindings(activity.getInputBindings());
        publishActivity.setParameters(activity.getParameters());

        return publishActivity;
    }
}


