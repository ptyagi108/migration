package com.dell.dims.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dell.dims.dto.DimsDTO;
import com.dell.dims.service.DimsServiceImpl;


@Controller
public class DimsController {

	@RequestMapping("/submitNew")
	public String migrationPage(HttpServletRequest request,
			HttpServletResponse response) {
		DimsDTO dimsDTO = new DimsDTO();
		String source_path = request.getParameter("source_text");
		dimsDTO.setInputPath(source_path);
		String target_path = request.getParameter("target_text");
		dimsDTO.setOutputPath(target_path);
		String templates_path = request.getParameter("templates_text");
		dimsDTO.setTemplatesPath(templates_path);
		DimsServiceImpl dimsServiceImpl = new DimsServiceImpl();
		System.out.println("source path is:::::::" + source_path);
		System.out.println("target path is:::::::" + target_path);
		dimsServiceImpl.process(dimsDTO);

		System.out.println("source path is::::" + source_path);
		System.out.println("target path is::::" + target_path);
		return "eis/success.html";
	}

}
