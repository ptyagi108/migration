package com.dell.dims.Builder;


import com.dell.dims.Model.Activity;

public class StartActivityBuilder extends AbstractActivityBuilder
{

    @Override
    public String build(Activity activity) {

        System.out.println("SOA Start ACtivity com.dell.dims.Builder");

        //get inputbinding for start XSD
        return null;
    }
}


