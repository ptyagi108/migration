package com.dell.dims.ModelInputBindings.InputBeans;

import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 3/9/2017.
 */
public class ListFiles
{
    private String fileLocation;
    private FilesProperties fileProperties;
    private Map<String,String> listVariables;
    private String condition;

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getFileLocation() {
        return fileLocation;
    }

    public void setFileLocation(String fileLocation) {
        this.fileLocation = fileLocation;
    }

    public FilesProperties getFileProperties() {
        return fileProperties;
    }

    public void setFileProperties(FilesProperties fileProperties) {
        this.fileProperties = fileProperties;
    }

    public Map<String, String> getListVariables() {
        return listVariables;
    }

    public void setListVariables(Map<String, String> listVariables) {
        this.listVariables = listVariables;
    }

    public String getVariablesList(FilesProperties fileProps)
    {

       StringBuilder strVal=new StringBuilder();

        strVal.append("TrackingID = " + fileProps.getTrackingID());
        strVal.append("\n");
        strVal.append("requestFilename = " + fileProps.getRequestFilename());
        strVal.append("\n");
        strVal.append("requestFilelocation = " + fileProps.getRequestFilelocation());
        strVal.append("\n");
        strVal.append("fullName = " + fileProps.getFullName());
        strVal.append("\n");
        strVal.append("TrxType = " + fileProps.getTrxType());
        strVal.append("\n");
        strVal.append("Channel = " + fileProps.getChannel());
        strVal.append("\n");
        strVal.append("LastUpdBy = " + fileProps.getLastUpdBy());
        strVal.append("\n");
        strVal.append("Status = " + fileProps.getStatus());
        strVal.append("\n");

        return strVal.toString();

    }
}
