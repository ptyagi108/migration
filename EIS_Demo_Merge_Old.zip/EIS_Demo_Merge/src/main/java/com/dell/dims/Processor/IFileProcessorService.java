package com.dell.dims.Processor;


public interface IFileProcessorService
{
    void process(String fileName) throws Exception ;

}


