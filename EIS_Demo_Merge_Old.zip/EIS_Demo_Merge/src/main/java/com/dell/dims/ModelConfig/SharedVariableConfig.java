package com.dell.dims.ModelConfig;

/**
 * Created by Kriti_Kanodia on 1/2/2017.
 */
public class SharedVariableConfig {

    private String variableConfig;
    private boolean showResult;


    public String getVariableConfig() {
        return variableConfig;
    }

    public void setVariableConfig(String variableConfig) {
        this.variableConfig = variableConfig;
    }

    public boolean isShowResult() {
        return showResult;
    }

    public void setShowResult(boolean showResult) {
        this.showResult = showResult;
    }


}
