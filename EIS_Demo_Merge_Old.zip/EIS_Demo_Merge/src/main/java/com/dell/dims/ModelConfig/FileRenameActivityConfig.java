package com.dell.dims.ModelConfig;

import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.endpoint.uri.DefaultEndpoint;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Created by Manoj_Mehta on 12/22/2016.
 */
//@Component
//@Qualifier("renameActivity")
//public class FileRenameActivityConfig extends DefaultEndpoint{
public class FileRenameActivityConfig{
    private boolean createMissingDirectories;
    private boolean overwrite;

    public boolean isCreateMissingDirectories() {
        return createMissingDirectories;
    }

    public void setCreateMissingDirectories(boolean createMissingDirectories) {
        this.createMissingDirectories = createMissingDirectories;
    }

    public boolean isOverwrite() {
        return overwrite;
    }

    public void setOverwrite(boolean overwrite) {
        this.overwrite = overwrite;
    }

    public Object getConfigAttributes(FileRenameActivity activity) throws Exception {
        this.setCreateMissingDirectories(activity.isCreateMissingDirectories());
        this.setOverwrite(activity.isOverwrite());
        return this;
    }
}

