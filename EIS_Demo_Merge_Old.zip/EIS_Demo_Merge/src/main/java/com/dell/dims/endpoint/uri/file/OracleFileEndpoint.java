package com.dell.dims.endpoint.uri.file;

import com.dell.dims.endpoint.uri.DefaultEndpoint;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


/**
 * Created by Pramod_Kumar_Tyagi on 7/12/2016.
 */

@Component
@Qualifier("oracle")
public class OracleFileEndpoint extends DefaultEndpoint {

    //   private String  scheme ="file";
    //   @Value("${TibcoProcessDefinition.starter.config.fileName}")
    //   private String path;

    // common options:


    private String encoding;
    // consumer options

    private String pollInterval;

    private String createEvent;

    private String modifyEvent;

    private String deleteEvent;

    private String mode;

    private String sortby;

    private String sortorder;

    private String DeleteFile;
    private String MinimumAge;
    private String PhysicalDirectory;
    private String Recursive;
    private String PollingFrequency;
    private String PhysicalArchiveDirectory;
    private String IncludeFiles;
    private String UseHeaders;

    // producer options


    private String compressFile;

    //group config

    private String groupType;
    private boolean serializable;
    private String indexSlot;

    public boolean isCreateMissingDirectories() {
        return createMissingDirectories;
    }

    public void setCreateMissingDirectories(boolean createMissingDirectories) {
        this.createMissingDirectories = createMissingDirectories;
    }

    public boolean isOverwrite() {
        return overwrite;
    }

    public void setOverwrite(boolean overwrite) {
        this.overwrite = overwrite;
    }

    public String getVariableName() {
        return variableName;
    }

    public void setVariableName(String variableName) {
        this.variableName = variableName;
    }

    private String errorCondition;
    private boolean suspendAfterErrorRetry;
    // activity config
    private boolean createMissingDirectories;
    private boolean overwrite;
    private String variableName;


    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    public boolean isSerializable() {
        return serializable;
    }

    public void setSerializable(boolean serializable) {
        this.serializable = serializable;
    }

    public String getIndexSlot() {
        return indexSlot;
    }

    public void setIndexSlot(String indexSlot) {
        this.indexSlot = indexSlot;
    }

    public String getErrorCondition() {
        return errorCondition;
    }

    public void setErrorCondition(String errorCondition) {
        this.errorCondition = errorCondition;
    }

    public boolean isSuspendAfterErrorRetry() {
        return suspendAfterErrorRetry;
    }

    public void setSuspendAfterErrorRetry(boolean suspendAfterErrorRetry) {
        this.suspendAfterErrorRetry = suspendAfterErrorRetry;
    }

    public String getCompressFile() {
        return compressFile;
    }

    public void setCompressFile(String compressFile) {
        this.compressFile = compressFile;
    }

    public String getPollInterval() {
        return pollInterval;
    }

    public void setPollInterval(String pollInterval) {
        this.pollInterval = pollInterval;
    }

    public String getCreateEvent() {
        return createEvent;
    }

    public void setCreateEvent(String createEvent) {
        this.createEvent = createEvent;
    }

    public String getModifyEvent() {
        return modifyEvent;
    }

    public void setModifyEvent(String modifyEvent) {
        this.modifyEvent = modifyEvent;
    }

    public String getDeleteEvent() {
        return deleteEvent;
    }

    public void setDeleteEvent(String deleteEvent) {
        this.deleteEvent = deleteEvent;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }


    public String getSortby() {
        return sortby;
    }

    public void setSortby(String sortby) {
        this.sortby = sortby;
    }

    public String getSortorder() {
        return sortorder;
    }

    public void setSortorder(String sortorder) {
        this.sortorder = sortorder;
    }


    public String getEncoding() {
        return encoding;
    }


    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    /**
     * A factory method to lazily create the endpointUri if none is specified
     */

    /*@Override
    public String createEndpointUri() {
        BeanMap params= new BeanMap();
        params.setBean(this);
      return  getEndpointConfiguration().toUriString(EndpointConfiguration.UriFormat.Canonical,params);

    }*/
    public String getDeleteFile() {
        return DeleteFile;
    }

    public void setDeleteFile(String deleteFile) {
        DeleteFile = deleteFile;
    }

    public String getMinimumAge() {
        return MinimumAge;
    }

    public void setMinimumAge(String minimumAge) {
        MinimumAge = minimumAge;
    }

    public String getPhysicalDirectory() {
        return PhysicalDirectory;
    }

    public void setPhysicalDirectory(String physicalDirectory) {
        PhysicalDirectory = physicalDirectory;
    }

    public String getRecursive() {
        return Recursive;
    }

    public void setRecursive(String recursive) {
        Recursive = recursive;
    }

    public String getPollingFrequency() {
        return PollingFrequency;
    }

    public void setPollingFrequency(String pollingFrequency) {
        PollingFrequency = pollingFrequency;
    }

    public String getPhysicalArchiveDirectory() {
        return PhysicalArchiveDirectory;
    }

    public void setPhysicalArchiveDirectory(String physicalArchiveDirectory) {
        PhysicalArchiveDirectory = physicalArchiveDirectory;
    }

    public String getIncludeFiles() {
        return IncludeFiles;
    }

    public void setIncludeFiles(String includeFiles) {
        IncludeFiles = includeFiles;
    }

    public String getUseHeaders() {
        return UseHeaders;
    }

    public void setUseHeaders(String useHeaders) {
        UseHeaders = useHeaders;
    }
}
