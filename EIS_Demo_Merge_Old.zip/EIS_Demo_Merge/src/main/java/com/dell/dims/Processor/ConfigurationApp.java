//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;

import java.util.HashMap;
import java.util.Map;

public class ConfigurationApp
{
    static Map<String, String> properties = new HashMap<String, String>();
    public static String getProperty(String propertyName) throws Exception {
        String propertyValue = "";
       // RefSupport<String> refVar___0 = new RefSupport<String>();
        propertyValue =properties.get(propertyName);

        return propertyValue;
    }

    public static void saveProperty(String propertyName, String propertyValue) throws Exception {
        if (properties.containsKey(propertyName))
        {
            properties.put(propertyName, propertyValue);
        }
        else
        {
            properties.put(propertyName, propertyValue);
        }
    }

}


