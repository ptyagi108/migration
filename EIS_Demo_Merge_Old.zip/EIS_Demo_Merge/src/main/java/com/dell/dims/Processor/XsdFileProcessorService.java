//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;

//import com.dell.dims.EaiConvertor.com.dell.dims.Builder.XsdBuilder;
//import com.dell.dims.EaiConvertor.CodeGenerator.ISourceCodeGeneratorService;
import com.dell.dims.Parser.XsdParser;

public class XsdFileProcessorService   implements IFileProcessorService
{
   // private static final Log Log = LogManager.GetLogger(XsdFileProcessorService.class);
   //private final ISourceCodeGeneratorService sourceCodeGeneratorService;
    private XsdParser xsdParser;
   /* public XsdFileProcessorService(ISourceCodeGeneratorService sourceCodeGeneratorService) throws Exception {
        this.sourceCodeGeneratorService = sourceCodeGeneratorService;
        this.xsdParser = new XsdParser();
    }*/

    public void process(String fileName) throws Exception {


        System.out.println("Not yet handled************");

        // CodeNamespace xsdNameSpacetoGenerate = new CodeNamespace();
    /*    try
        {
            xsdNameSpacetoGenerate = new XsdBuilder().build(fileName);
        }
        catch (Exception e)
        {
            Log.Error("unable to generate class from XSD file:" + fileName, e);
        }

        targetUnit = new CodeCompileUnit();
        targetUnit.Namespaces.Add(xsdNameSpacetoGenerate);
        this.sourceCodeGeneratorService.Generate(targetUnit);
        */
    }

}


