package com.dell.dims.ModelInputBindings.Input.TransactionFile;

import java.security.KeyStore;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 3/2/2017.
 */
public class MapperTransactionFile extends Attribute
{
   private String transactionFileName;
    private Attribute fileDescription;

   Map<String,List<Attribute>> fileAttributes;
   Map<String,List<Attribute>> destinationAttributes;

    public Attribute getFileDescription() {
        return fileDescription;
    }

    public void setFileDescription(Attribute fileDescription) {
        this.fileDescription = fileDescription;
    }

    public Map<String, List<Attribute>> getFileAttributes() {
        return fileAttributes;
    }

    public void setFileAttributes(Map<String, List<Attribute>> fileAttributes) {
        this.fileAttributes = fileAttributes;
    }

    public Map<String, List<Attribute>> getDestinationAttributes() {
        return destinationAttributes;
    }

    public void setDestinationAttributes(Map<String, List<Attribute>> destinationAttributes) {
        this.destinationAttributes = destinationAttributes;
    }

    public String getTransactionFileName() {
        return transactionFileName;
    }

    public void setTransactionFileName(String transactionFileName) {
        this.transactionFileName = transactionFileName;
    }
}
