package com.dell.dims.dto;

public class DimsDTO {
	
	private String inputPath;
	private String outputPath;
	private String templatesPath;
		
	public String getInputPath() {
		return inputPath;
	}
	public void setInputPath(String inputPath) {
		this.inputPath = inputPath;
	}
	public String getOutputPath() {
		return outputPath;
	}
	public void setOutputPath(String outputPath) {
		this.outputPath = outputPath;
	}
	public String getTemplatesPath() {
		return templatesPath;
	}
	public void setTemplatesPath(String templatesPath) {
		this.templatesPath = templatesPath;
	}

}
