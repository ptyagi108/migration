package com.dell.dims.Model;

/**
 * Created by Manoj_Mehta on 4/7/2017.
 */
public class ListFilesActivity extends Activity
{
    private String mode;
    public ListFilesActivity(String name, ActivityType type) {
        super(name, type);
    }

    public ListFilesActivity() throws Exception {
        super();
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }
}
