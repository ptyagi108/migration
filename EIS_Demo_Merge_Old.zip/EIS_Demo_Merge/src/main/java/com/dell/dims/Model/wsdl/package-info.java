@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.xmlsoap.org/wsdl/",
                                     elementFormDefault =
                                     javax.xml.bind.annotation.XmlNsForm.QUALIFIED) package com.dell.dims.Model.wsdl;

