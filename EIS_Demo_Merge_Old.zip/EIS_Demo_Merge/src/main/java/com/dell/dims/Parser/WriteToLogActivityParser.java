//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.WriteToLogActivity;
import com.dell.dims.ModelConfig.WriteToLogActivityConfig;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class WriteToLogActivityParser implements IActivityParser
{
    public Activity parse(String inputElement) throws Exception {

        WriteToLogActivity activity = new WriteToLogActivity();
        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();

        activity.setName(activityMap.get("name"));
        activity.setType(new ActivityType(activityMap.get("type")));
      /*  activity.setName(inputElement.Attribute("name").Value);
        activity.setType((ActivityType)inputElement.Element(XmlnsConstant.tibcoProcessNameSpace + "type").Value);*/
        /* [UNSUPPORTED] 'var' as type is unsupported "var" */

        WriteToLogActivityConfig config = Extractors.on(inputElement)
                .extract("config", extractBean(new WriteToLogActivityConfig()))
                .asBean(WriteToLogActivityConfig.class);

        activity.setRole(config.getRole());


        NodeList childNodes= NodesExtractorUtil.getChildNode(inputElement);
        for (int j = 0; j < childNodes.getLength(); j++) {
            Node node = childNodes.item(j);

            if (node instanceof Element) {
                // a child element to process
                Element element = (Element) node;
                String nodeName = element.getNodeName();

                if (nodeName.equalsIgnoreCase("inputBindings")) {
                    String nodeSubString = NodesExtractorUtil.nodeToString(node);
               //     activity.setInputBindings((List<Node>) NodesExtractorUtil.getChildNode(nodeSubString));
                //    activity.setParameters((new XslParser()).parse(activity.getInputBindings()));
                }
            }
        }

        /* configElement = inputElement.Element("config");
        activity.setRole(XElementParserUtils.GetStringValue(configElement.Element("role")));

        if (inputElement.Element(XmlnsConstant.tibcoProcessNameSpace + "inputBindings") != null && inputElement.Element(XmlnsConstant.tibcoProcessNameSpace + "inputBindings").Element(XmlnsConstant.writeToLogActivityNameSpace + "ActivityInput") != null)
        {
            activity.setInputBindings(inputElement.Element(XmlnsConstant.tibcoProcessNameSpace + "inputBindings").Element(XmlnsConstant.writeToLogActivityNameSpace + "ActivityInput").Nodes());
            activity.setParameters((new XslParser()).parse(activity.getInputBindings()));
        }*/

        return activity;
    }

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        return null;
    }
}


