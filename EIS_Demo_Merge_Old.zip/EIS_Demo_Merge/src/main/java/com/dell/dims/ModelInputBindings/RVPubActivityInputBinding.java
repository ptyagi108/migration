package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 3/1/2017.
 */
public class RVPubActivityInputBinding extends InputBinding {

    @Override
    public InputBinding captureInputBindingAttributes(Activity activity) {
        InputBinding inputBindings=new InputBinding();
        Map<String,Object> mapAttributesList= new HashMap<String,Object>();
        String endPointName="";
        StringBuffer endPointValue;
        String attribute="";
        StringBuilder attributeVal=null;

        // check if current process is subprocess
        if(activity.getResourceType().toUpperCase().contains(".subprocess".toUpperCase()))
        {
            System.out.println("\n*****Subprocess EXIST for*****"+activity.getName() + " Process");
            inputBindings.setSubprocess(true);
        }

        List<ClassParameter> paramList = activity.getParameters();
        if (paramList.size() > 0) {
            for (ClassParameter classParam : paramList) {
                //check for rootPath
                attribute = "subject";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0) {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //check for body
                attribute = "body";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0) {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

            }
        }

        inputBindings.setSchemeName("FILE");
        inputBindings.setActivityName(activity.getName());
        inputBindings.setActivityType(activity.getType().toString());
        inputBindings.setAttributesList(mapAttributesList);
        inputBindings.setEndPointOptions(null);

        return inputBindings;
    }
}
