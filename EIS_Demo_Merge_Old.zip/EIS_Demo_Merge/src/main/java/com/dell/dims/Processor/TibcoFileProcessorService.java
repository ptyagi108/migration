//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;

/*import com.dell.dims.com.dell.dims.Builder.TibcoProcessClassesBuilder;
import com.dell.dims.com.dell.dims.Builder.LoggerInterfaceBuilder;
import com.dell.dims.ISourceCodeGeneratorService;
import com.dell.dims.Parser.TibcoBWProcessLinqParser;*/

public class TibcoFileProcessorService   implements IFileProcessorService
{
   /* private final ISourceCodeGeneratorService sourceCodeGeneratorService;
    public TibcoFileProcessorService(ISourceCodeGeneratorService sourceCodeGeneratorService) throws Exception {
        this.sourceCodeGeneratorService = sourceCodeGeneratorService;
    }*/

    public void process(String fileName) throws Exception {
      /*  TibcoBWProcess tibcoBwProcess = new TibcoBWProcessLinqParser().parse(fileName);
        TibcoProcessClassesBuilder tibcoBwProcessBuilder = new TibcoProcessClassesBuilder();
        *//* [UNSUPPORTED] 'var' as type is unsupported "var" *//* targetUnit = tibcoBwProcessBuilder.build(tibcoBwProcess);
        // TODO if exist don't add it ? Ugly but no Config manager on Mono/Xamarin
        if (!StringSupport.equals(ConfigurationApp.getProperty("IsLoggerAlreadyGenerated"), "true"))
        {
            targetUnit.Namespaces.Add((new LoggerInterfaceBuilder()).build());
            ConfigurationApp.saveProperty("IsLoggerAlreadyGenerated","true");
        }

        this.sourceCodeGeneratorService.Generate(targetUnit);*/
    }

}


