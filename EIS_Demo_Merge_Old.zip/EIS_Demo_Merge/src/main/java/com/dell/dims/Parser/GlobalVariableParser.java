package com.dell.dims.Parser;

import com.dell.dims.Model.GlobalVariable;
import com.dell.dims.Model.GlobalVariables;
import com.dell.dims.Model.GlobalVariablesRepository;
import com.dell.dims.Parser.Utils.FileUtility;
import com.dell.dims.service.DimsServiceImpl;
import im.nll.data.extractor.Extractors;
import im.nll.data.extractor.utils.XmlUtils;

import java.io.File;
import java.nio.charset.Charset;
import java.util.*;

import static im.nll.data.extractor.Extractors.xpath;

public class GlobalVariableParser
{
  private  final String fileName="defaultVars.substvar";
  private  final String defaultDirectory= DimsServiceImpl.input_project_path + File.separator+"defaultVars";

    public GlobalVariablesRepository parseVariable(String filePath) throws Exception {
        GlobalVariablesRepository globalVariablesRepository = new GlobalVariablesRepository();
       /* XElement allFileElement = XElement.Load(filePath);
        globalVariablesRepository.setGlobalVariables(this.parseVariableGlobal(allFileElement));*/
      GlobalVariablesRepository.listFilesForFolder(new File(filePath));
      Set<Map.Entry<String, List<String>>> entrySet = GlobalVariablesRepository.dirFiles.entrySet();

      // Collection Iterator
      Iterator<Map.Entry<String, List<String>>> iterator = entrySet.iterator();

      while(iterator.hasNext()) {

        Map.Entry<String, List<String>> entry = iterator.next();

       for(String path : entry.getValue()) {
        // InputStream is = GlobalVariableParser.class.getClassLoader().getResourceAsStream("GlobalVariable.xsd");
         String content =FileUtility.readFile(path, Charset.defaultCharset());
         globalVariablesRepository.getGlobalVariables().add(this.parseVariableGlobal(entry.getKey(),content));
        }
      }

        return globalVariablesRepository;
    }


    public GlobalVariables parseVariableGlobal(String category, String allFileElement) throws Exception {

     /*   Map<String, String> activityMap = Extractors.on(allFileElement)
                .extract("globalVariables", xpath(PropertiesUtil.getPropertyFile().getProperty("repository.globalVariables")))
                .asMap();  */

     // get GlobalVariables str
      GlobalVariables globalVariables = new GlobalVariables();
      globalVariables.setCategory(category);
      String fileString =XmlUtils.removeNamespace(allFileElement);
      System.out.println(fileString);
        String globalVariablesStr = Extractors.on(fileString)
                .extract(xpath("//repository/globalVariables"))
                .asString();
         if(globalVariablesStr==null)
             return null;

        //extract globalvariable
        List<String> listGlobalVariable = Extractors.on(fileString)
                                        .split(xpath("//repository/globalVariables/globalVariable"))
                                        .asStringList();
        if(listGlobalVariable.isEmpty())
            return null;


        GlobalVariable globalVariable=null;
        for(String globalVar : listGlobalVariable)
        {
            globalVariable = new GlobalVariable();
          globalVariable.setCategory(category);
          String name = Extractors.on(globalVar)
            .extract(xpath("//globalVariable/name/text()"))
            .asString();
          globalVariable.setName(name);
          String value = Extractors.on(globalVar)
            .extract(xpath("//globalVariable/value/text()"))
            .asString();
          globalVariable.setValue(value);
          String type = Extractors.on(globalVar)
            .extract(xpath("//globalVariable/type/text()"))
            .asString();

          globalVariable.setType(GlobalVariableType.valueOf(type));
      //    $_globalVariables/ns1:FileAdapter/ns1:SleepTime
          globalVariable.setXpath(getXpath(category, name));
            globalVariables.getGlobalVariables().add(globalVariable);
        }
        return globalVariables;

/**
 * var globalVariablesElement = allFileElement.Element(XmlnsConstant.globalVariableNameSpace + "globalVariables");

 IEnumerable<XElement> xElement = from element in globalVariablesElement.Elements (XmlnsConstant.globalVariableNameSpace + "globalVariable")
 select element;
 if (xElement == null) {
 return null;
 }

 var globalVariables = new List<GlobalVariable>();
 foreach (var element in xElement)
 {
 var globalVariable = new GlobalVariable
 {
 Name = element.Element(XmlnsConstant.globalVariableNameSpace + "name").Value,
 Value = element.Element(XmlnsConstant.globalVariableNameSpace + "value").Value,
 Type = (GlobalVariableType) Enum.Parse(typeof(GlobalVariableType),element.Element(XmlnsConstant.globalVariableNameSpace + "type").Value)
 };
 globalVariables.Add(globalVariable);
 }
 return globalVariables;
 *
 */
    }

  String getXpath(String category,String name)
  {
    return  "$_globalVariables"+"/gbl:"+category+"/gbl:"+name;
  }
}


/*
* xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
        "<repository xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.tibco.com/xmlns/repo/types/2002\">\n" +
        "    <globalVariables>\n" +
        "        <globalVariable>\n" +
        "            <name>Name test 1</name>\n" +
        "            <value>value test 1</value>\n" +
        "            <type>String</type>\n" +
        "            <deploymentSettable>true</deploymentSettable>\n" +
        "            <serviceSettable>false</serviceSettable>\n" +
        "            <modTime>13304412311412</modTime>\n" +
        "        </globalVariable>\n" +
        "        <globalVariable>\n" +
        "            <name>Name test 2</name>\n" +
        "            <value>value test 2</value>\n" +
        "            <type>String</type>\n" +
        "            <deploymentSettable>true</deploymentSettable>\n" +
        "            <serviceSettable>false</serviceSettable>\n" +
        "            <modTime>13304412311411</modTime>\n" +
        "        </globalVariable>\n" +
        "    </globalVariables>\n" +
        "</repository>";
* */


