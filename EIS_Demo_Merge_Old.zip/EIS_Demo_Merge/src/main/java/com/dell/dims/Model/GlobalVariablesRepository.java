package com.dell.dims.Model;

import com.dell.dims.Parser.Utils.FileUtility;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.QNameUtil;
import com.dell.dims.service.DimsServiceImpl;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.namespace.QName;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.dell.dims.Parser.Utils.FileUtility.listFilesAndFilesSubDirectories;

/**
 * Created by Manoj_Mehta on 5/4/2017.
 */
public class GlobalVariablesRepository
{

    private  final String fileName="defaultVars.substvar";
    private  final String defaultDirectory=DimsServiceImpl.input_project_path +File.separator+"defaultVars";
    private List<GlobalVariables> globalVariables=new ArrayList<>();

  public static HashMap<String, List<String>> dirFiles = new HashMap<String, List<String>>();



  public static void listFilesForFolder(File folder)
    throws IOException {

    if(folder.isDirectory()) {

      ArrayList<String> fileNames = new ArrayList<String>();


      for (final File fileEntry : folder.listFiles()) {

        if (fileEntry.isDirectory()) {
         //   System.out.println(fileEntry.toString());
          listFilesForFolder(fileEntry);
        } else {
          String fileName = (fileEntry.getPath()).toString();
       //   System.out.println(fileName);
          fileNames.add(fileEntry.getPath());
        }
      }
      dirFiles.put(folder.getName(), fileNames);
      System.out.println(dirFiles);
    }
  }

  public List<GlobalVariables> getGlobalVariables() {
    return globalVariables;
  }

  public void setGlobalVariables(List<GlobalVariables> globalVariables) {
    this.globalVariables = globalVariables;
  }
}


