package com.dell.dims.Builder;

import com.dell.dims.Model.ActivityType;

public class ActivityBuilderFactory implements ActivityBuilderInterface
{
   /* private final XpathBuilder xpathBuilder;
    private final XslBuilder xslBuilder;
    private final DataAccessBuilder dataAccessBuilder;
    private final DataAccessServiceBuilder dataAccessServiceBuilder;
    private final DataAccessInterfacesCommonBuilder dataAccessInterfacesCommonBuilder;
    private final ResultSetBuilder resultSetBuilder;
    private final XmlParserHelperBuilder xmlParserHelperBuilder;
    private final XsdBuilder xsdBuilder;
    private final XsdParser xsdParser;
    private final SubscriberInterfaceBuilder subscriberBuilder;
    private final EngineCommandServiceHelperBuilder engineCommandServiceHelperBuilder;
    public ActivityBuilderFactory() throws Exception {
        this.xpathBuilder = new XpathBuilder();
        this.xslBuilder = new XslBuilder(this.xpathBuilder);
        this.dataAccessBuilder = new DataAccessBuilder();
        this.dataAccessServiceBuilder = new DataAccessServiceBuilder();
        this.dataAccessInterfacesCommonBuilder = new DataAccessInterfacesCommonBuilder();
        this.resultSetBuilder = new ResultSetBuilder();
        this.xmlParserHelperBuilder = new XmlParserHelperBuilder();
        this.engineCommandServiceHelperBuilder = new EngineCommandServiceHelperBuilder();
        this.xsdBuilder = new XsdBuilder();
        this.xsdParser = new XsdParser();
        this.subscriberBuilder = new SubscriberInterfaceBuilder();
    }
    */

    public Object getBuilder(ActivityType activityType) throws Exception {

        if(activityType.toString().equalsIgnoreCase(ActivityType.startType.toString()))
        {
            return new StartActivityBuilder();
        }
        else if(activityType.toString().equalsIgnoreCase(ActivityType.endType.toString()))
        {
            return new EndActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.jdbcQueryActivityType.toString()) || activityType.toString().equalsIgnoreCase(ActivityType.jdbcCallActivityType.toString()) || activityType.toString().equalsIgnoreCase(ActivityType.jdbcUpdateActivityType.toString()))
        {
            return new JdbcQueryActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.javaActivityType.toString()))
        {
            return new JavaActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.assignActivityType.toString()))
        {
            return new AssignActivityBuilder();
        }

        else if (activityType.toString().equalsIgnoreCase(ActivityType.mapperActivityType.toString()))
        {
            return new MapperActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.nullActivityType.toString()))
        {
            return new NullActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.callProcessActivityType.toString()))
        {
            return new CallProcessActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.writeToLogActivityType.toString()))
        {
            return new WriteToLogActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.generateErrorActivity.toString()))
        {
            return new GenerateErrorActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.sleepActivity.toString()))
        {
            return new SleepActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.loopGroupActivityType.toString()) || activityType.toString().equalsIgnoreCase(ActivityType.criticalSectionGroupActivityType.toString()))
        {
            return new GroupActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.RdvEventSourceActivityType.toString()))
        {
            return new RdvEventSourceActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.rvPubActivityType.toString()))
        {
            return new RdvPublishActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.TimerEventSource.toString()))
        {
            return new TimerActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.AeSubscriberActivity.toString()) || activityType.toString().equalsIgnoreCase(ActivityType.OnStartupEventSource.toString()))
        {
            return new DefaultSubscriberBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.setSharedVariableActivityType.toString()))
        {
            return new SetSharedVariableActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.getSharedVariableActivityType.toString()))
        {
            return new GetSharedVariableActivityBuilder();
        }
        else if (activityType.toString().equalsIgnoreCase(ActivityType.ConfirmActivityType.toString()))
        {
            return new ConfirmActivityBuilder();
        }

        return new DefaultActivityBuilder();
    }

}


