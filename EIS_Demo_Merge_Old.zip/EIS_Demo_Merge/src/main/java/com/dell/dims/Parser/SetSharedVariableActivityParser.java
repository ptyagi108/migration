package com.dell.dims.Parser;

import com.dell.dims.Model.*;
import com.dell.dims.ModelConfig.AssignActivityConfig;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class SetSharedVariableActivityParser implements IActivityParser {

    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        SetSharedVariableActivity sharedVariableActivity = new SetSharedVariableActivity();

        String nodeStr=NodesExtractorUtil.nodeToString(node);

        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                   // .extract("showResult", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.showResult")))
                    .extract("variableConfig", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.variableConfig")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                  //  .extract("showResult", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.showResult")))
                    .extract("variableConfig", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.variableConfig")))
                    .asMap();
        }

        sharedVariableActivity.setName(activityMap.get("name"));
        sharedVariableActivity.setType(new ActivityType(activityMap.get("type")));
        //sharedVariableActivity.setShowResult(Boolean.parseBoolean(activityMap.get("showResult")));
        sharedVariableActivity.setVariableConfig(activityMap.get("variableConfig"));
        sharedVariableActivity.setGroupActivity(isGroupActivity);

        // for input bindings

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,sharedVariableActivity);
        sharedVariableActivity.setInputBindings(activity.getInputBindings());
        sharedVariableActivity.setParameters(activity.getParameters());


        return sharedVariableActivity;
    }
}

/*
<activity name="Rename File">
            <type>com.tibco.plugin.file.FileRenameActivity</type>
            <resourceType>ae.activities.FileRenameActivity</resourceType>
            <x>345</x>
            <y>108</y>
            <config>
                <createMissingDirectories>true</createMissingDirectories>
                <overwrite>true</overwrite>
            </config>
            <inputBindings>
                <RenameActivityConfig>
                    <fromFileName>
                        <value-of select="$Start/root/fromFile"/>
                    </fromFileName>
                    <toFileName>
                        <value-of select="$Start/root/toFile"/>
                    </toFileName>
                </RenameActivityConfig>
            </inputBindings>
        </activity>
 */


