package com.dell.dims.ModelConfig;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileReadActivity;

/**
 * Created by Manoj Mehta
 */
public class FileReadActivityConfig{

    private String encoding;
    private boolean excludeContent;

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public boolean isExcludeContent() {
        return excludeContent;
    }

    public void setExcludeContent(boolean excludeContent) {
        this.excludeContent = excludeContent;
    }

    public Object getConfigAttributes(FileReadActivity activity) throws Exception {
        this.setEncoding(activity.getEncoding());
        this.setExcludeContent(activity.isExcludeContent());
        return this;
    }


}
