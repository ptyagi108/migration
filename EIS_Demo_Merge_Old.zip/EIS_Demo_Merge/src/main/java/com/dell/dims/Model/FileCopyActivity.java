package com.dell.dims.Model;

/**
 * Created by Kriti_Kanodia on 1/16/2017.
 */
public class FileCopyActivity extends Activity {

    public FileCopyActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public FileCopyActivity() throws Exception {
    }

    private boolean overwrite;

    public boolean isOverwrite() {
        return overwrite;
    }

    public void setOverwrite(boolean overwrite) {
        this.overwrite = overwrite;
    }

}
