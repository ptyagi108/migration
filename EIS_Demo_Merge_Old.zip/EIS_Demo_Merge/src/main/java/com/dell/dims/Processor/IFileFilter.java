//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;


public interface IFileFilter
{
    boolean isFileAuthorized(String filePath) throws Exception ;

}


