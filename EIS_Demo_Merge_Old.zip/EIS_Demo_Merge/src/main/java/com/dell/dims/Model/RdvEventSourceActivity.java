package com.dell.dims.Model;

public class RdvEventSourceActivity  extends Activity
{
    public RdvEventSourceActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public RdvEventSourceActivity() throws Exception {
    }

    private String subject;
    private String sharedChannel;
    private String xsdStringReference;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSharedChannel() {
        return sharedChannel;
    }

    public void setSharedChannel(String sharedChannel) {
        this.sharedChannel = sharedChannel;
    }

    public String getXsdStringReference() {
        return xsdStringReference;
    }

    public void setXsdStringReference(String xsdStringReference) {
        this.xsdStringReference = xsdStringReference;
    }
}


