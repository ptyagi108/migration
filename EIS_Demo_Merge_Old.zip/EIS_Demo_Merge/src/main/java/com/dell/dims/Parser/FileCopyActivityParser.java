package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileCopyActivity;
import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

/**
 * Created by Kriti_Kanodia on 1/16/2017.
 */
public class FileCopyActivityParser implements IActivityParser {

    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        FileCopyActivity copyActivity = new FileCopyActivity();

        String nodeStr= NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("overwrite", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.overwrite")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("overwrite", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.overwrite")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .asMap();
        }

        copyActivity.setName(activityMap.get("name"));
        copyActivity.setType(new ActivityType(activityMap.get("type")));
        copyActivity.setOverwrite(Boolean.parseBoolean(activityMap.get("overwrite")));
        copyActivity.setResourceType(activityMap.get("resourceType"));
        copyActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,copyActivity);
        copyActivity.setInputBindings(activity.getInputBindings());
        copyActivity.setParameters(activity.getParameters());

        /*System.out.println("isGroupActitivty:" + isGroupActivity);
        System.out.println("Name:" + activityMap.get("name"));
        System.out.println("Type:" + activityMap.get("type"));
        System.out.println("overwrite:" + activityMap.get("overwrite"));
        System.out.println("createMissingDirectories:" + activityMap.get("createMissingDirectories"));*/

        return copyActivity;
    }
}
