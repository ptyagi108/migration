package com.dell.dims.util;

import static im.nll.data.extractor.Extractors.selector;
import static im.nll.data.extractor.Extractors.xpath;
import im.nll.data.extractor.Extractor;
import im.nll.data.extractor.Extractors;

import com.dell.dims.DimsDemo;
import com.dell.dims.service.DimsServiceImpl;

/**
 * Created by Pramod_Kumar_Tyagi on 8/19/2016.
 */
public class BeanExtractor implements Extractor {

    Object bean;

    public BeanExtractor(Object bean) {
        this.bean = bean;
    }

    public static BeanExtractor extractBean(Object bean) {
        return new BeanExtractor(bean);
    }

    @Override
    public Object extract(String data) {

        Object extractedData = "";
        System.out.println("data for extraction************" + data);

        // extract type of actiivty
        String activityType = Extractors.on(data)
                .extract(selector("type"))
                .asString();


        if (activityType.equalsIgnoreCase("com.tibco.pe.core.LoopGroup")) {
            System.out.println("**************Extracting Group Attributes******");
            extractedData = Extractors.on(data)
                    .extract("groupType", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.group.config.groupType")))
                    .extract("serializable", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.group.config.serializable")))
                    .extract("indexSlot", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.group.config.indexSlot")))
                    .extract("errorCondition", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.group.config.errorCondition")))
                    .extract("suspendAfterErrorRetry", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.group.config.suspendAfterErrorRetry")))
                    .asBean(bean.getClass());
        }
        else if (activityType.equalsIgnoreCase("com.tibco.pe.core.AssignActivity")) {
            System.out.println("**************Extracting Assign Activity Attributes******");

            extractedData = Extractors.on(data)
                    .extract("variableName", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.group.activity.config.variableName")))
                    .asBean(bean.getClass());
        }
        else if (activityType.equalsIgnoreCase("com.tibco.plugin.file.FileRenameActivity")) {
            System.out.println("**************Extracting FileRenameActivity Attributes******");

            extractedData = Extractors.on(data)
                    .extract("createMissingDirectories", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.group.activity.config.createMissingDirectories")))
                    .extract("overwrite", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.group.activity.config.overwrite")))
                    .asBean(bean.getClass());
        }

        else {
            extractedData = Extractors.on(data)

                    .extract("compressFile", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.compressFile")))
                    .extract("pollInterval", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.pollInterval")))
                    .extract("createEvent", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.createEvent")))
                    .extract("modifyEvent", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.modifyEvent")))
                    .extract("deleteEvent", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.deleteEvent")))
                    .extract("mode", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.mode")))
                    .extract("encoding", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.encoding")))
                    .extract("sortby", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.sortby")))
                    .extract("sortorder", xpath(DimsServiceImpl.props.getProperty("ProcessDefinition.activity.config.sortorder")))
                    .asBean(bean.getClass());
        }

        System.out.println("-----------------extractedData :::::::::::::::::::::::::::::"+extractedData.toString());
        return extractedData;
    }
}
