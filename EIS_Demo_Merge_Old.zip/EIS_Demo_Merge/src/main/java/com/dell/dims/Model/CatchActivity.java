package com.dell.dims.Model;

/**
 * Created by Manoj_Mehta on 5/17/2017.
 */
public class CatchActivity extends Activity
{

    public CatchActivity(String name, ActivityType type) {
        super(name, type);
    }


    public CatchActivity() throws Exception{

    }


    private boolean catchAll;

    public boolean isCatchAll() {
        return catchAll;
    }

    public void setCatchAll(boolean catchAll) {
        this.catchAll = catchAll;
    }
}
