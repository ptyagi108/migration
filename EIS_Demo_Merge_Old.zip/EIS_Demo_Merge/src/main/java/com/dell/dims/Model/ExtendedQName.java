package com.dell.dims.Model;

import javax.xml.namespace.QName;

/**
 * Created by Pramod_Kumar_Tyagi on 6/8/2017.
 */
public final class ExtendedQName extends QName {

  //String rootNodeName;
  private final String location;
  private final String schema;
  private final String QNameType;
  private static int prefixCounter;

  public ExtendedQName(ExtendedQNameBuilder builder) {
    super(builder.getNamespaceURI(),builder.getLocalPart(),builder.getPrefix());
   // this.rootNodeName=rootNodeName;

    this.location=builder.getLocation();
    this.schema=builder.getSchema();
    this.QNameType =builder.getType();
  }

  /*public String getRootNodeName() {
    return rootNodeName;
  }

  public void setRootNodeName(String rootNodeName) {
    this.rootNodeName = rootNodeName;
  }*/

  public String getLocation() {
    return location;
  }




  public String getSchema() {
    return schema;
  }



  public String getQNameType() {
    return QNameType;
  }



}
