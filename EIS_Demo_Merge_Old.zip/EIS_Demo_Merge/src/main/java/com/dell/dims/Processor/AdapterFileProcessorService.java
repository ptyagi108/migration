//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;

//import com.dell.dims.EaiConvertor.com.dell.dims.Builder.AdapterSchemaBuilder;
//import com.dell.dims.Parser.AdapterSchemaParser;
//import com.dell.dims.EaiConvertor.CodeGenerator.ISourceCodeGeneratorService;

public class AdapterFileProcessorService   implements IFileProcessorService
{
   /* private ISourceCodeGeneratorService sourceCodeGeneratorService;
    public AdapterFileProcessorService(ISourceCodeGeneratorService sourceCodeGeneratorService) throws Exception {
        this.sourceCodeGeneratorService = sourceCodeGeneratorService;
    } */

    public void process(String fileName) throws Exception {
        // TODO VC TO implement
      /*  AdapterSchemaModel schemaModel = (new AdapterSchemaParser()).parse(fileName);
        AdapterSchemaBuilder adapterSchemaBuilder = new AdapterSchemaBuilder();
        */
        /* [UNSUPPORTED] 'var' as type is unsupported "var" */
       /* targetUnit = new CodeCompileUnit();
        targetUnit.Namespaces.Add(adapterSchemaBuilder.build(schemaModel));
        this.sourceCodeGeneratorService.Generate(targetUnit);
         */
    }

}


