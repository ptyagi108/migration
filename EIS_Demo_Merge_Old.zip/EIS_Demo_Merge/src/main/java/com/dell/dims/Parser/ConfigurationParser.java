//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.TbwConfiguration;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

public class ConfigurationParser
{
   /* public TbwConfiguration parse(String filePathName) throws Exception {

       XElement allFileElement = XElement.Load(filePathName);

        return this.parse(allFileElement);

    }*/

    public TbwConfiguration parse(String inputElement) throws Exception {
        TbwConfiguration configuration = new TbwConfiguration();
        /* [UNSUPPORTED] 'var' as type is unsupported "var" */

        //tibco assign activity
        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("application", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.application")))
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.name")))
                .extract("repoInstanceName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.repoInstanceName")))
                .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                .asMap();

/*

        applicationElement = inputElement.Element(XmlnsConstant.ConfigNamespace + "application");
        configuration.setName(inputElement.Attribute("name").Value);
        configuration.setRepoInstanceName(inputElement.Element(XmlnsConstant.ConfigNamespace + "repoInstanceName").Value);
        servicesElement = inputElement.Element(XmlnsConstant.ConfigNamespace + "services");
        configuration.setServicesConfig(new TbwServiceConfig());
        if (servicesElement.Elements(XmlnsConstant.ConfigNamespace + "adapter") != null)
        {
            configuration.getServicesConfig().setTbwAdapters(this.GetTbwAdapters(servicesElement.Elements(XmlnsConstant.ConfigNamespace + "adapter")));
        }

        if (servicesElement.Elements(XmlnsConstant.ConfigNamespace + "bw") != null)
        {
            configuration.getServicesConfig().setTbwProcessContainers(this.TbwProcessContainers(servicesElement.Elements(XmlnsConstant.ConfigNamespace + "bw")));
        }
        */

        return configuration;
    }

    /* private List<TbwProcessContainerConfig> tbwProcessContainers(IEnumerable<XElement> elements) throws Exception {
        tbwProcessContainerConfigs = new List<TbwProcessContainerConfig>();
    /*    for (bwElement : elements)
        {
            tbwProcessContainerConfigs.Add(this.GetTbxProcessConfig(bwElement));
        }
        return tbwProcessContainerConfigs;
    }

    private TbwProcessContainerConfig getTbxProcessConfig(XElement xElement) throws Exception {
        TbwProcessContainerConfig container = new TbwProcessContainerConfig();
        container.setName(xElement.Attribute("name").Value);
        container.setIsEnabled(XElementParserUtils.GetBoolValue(xElement.Element(XmlnsConstant.ConfigNamespace + "enabled")));
        processesElements = xElement.Element(XmlnsConstant.ConfigNamespace + "bwprocesses").Elements(XmlnsConstant.ConfigNamespace + "bwprocess");
        container.setTbwProcessConfigs(new List<TbwProcessConfig>());
        for (processesElement : processesElements)
        {
            container.getTbwProcessConfigs().Add(new TbwProcessConfig());
        }
        return container;
    }

    private List<TbwAdapterConfig> getTbwAdapters(IEnumerable<XElement> elements) throws Exception {
         tbwAdapterConfigs = new List<TbwAdapterConfig>();
        return tbwAdapterConfigs;
    }
    */

}


