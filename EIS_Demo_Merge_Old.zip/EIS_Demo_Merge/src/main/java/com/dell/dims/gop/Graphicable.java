package com.dell.dims.gop;

/**
 * @author pramod
 */
public interface Graphicable {
    public void graph();
}
