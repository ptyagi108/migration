//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Model;

public class EngineCommandActivity  extends Activity
{
    public EngineCommandActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public EngineCommandActivity() throws Exception {
    }

    private String command;

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }
}


