//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Model;

public class ConfirmActivity  extends Activity
{
    public ConfirmActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public ConfirmActivity() throws Exception {
    }

    private String activityNameToConfirm;


    public String getActivityNameToConfirm() {
        return activityNameToConfirm;
    }

    public void setActivityNameToConfirm(String activityNameToConfirm) {
        this.activityNameToConfirm = activityNameToConfirm;
    }
}


