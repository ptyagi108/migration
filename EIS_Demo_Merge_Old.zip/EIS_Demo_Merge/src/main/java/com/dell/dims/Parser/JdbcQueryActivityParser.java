package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.ClassParameter;
import com.dell.dims.Model.JdbcQueryActivity;
import com.dell.dims.ModelConfig.JdbcQueryActivityConfig;
import com.dell.dims.Parser.Utils.XmlnsConstant;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class JdbcQueryActivityParser implements IActivityParser
{

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        JdbcQueryActivity jdbcQueryActivity = new JdbcQueryActivity();
        String nodeStr=NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .extract("timeout", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.timeout")))
                    .extract("commit", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.commit")))
                    .extract("maxRows", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.maxRows")))
                    .extract("emptyStrAsNil", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.emptyStrAsNil")))
                    .extract("statement", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.statement")))
                    .extract("jdbcSharedConfig", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.jdbcSharedConfig")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("timeout", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.timeout")))
                    .extract("commit", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.commit")))
                    .extract("maxRows", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.maxRows")))
                    .extract("emptyStrAsNil", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.emptyStrAsNil")))
                    .extract("statement", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.statement")))
                    .extract("jdbcSharedConfig", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.jdbcSharedConfig")))
                    .asMap();
        }

        jdbcQueryActivity.setName(activityMap.get("name").toString());
        jdbcQueryActivity.setType(new ActivityType(activityMap.get("type").toString()));
        jdbcQueryActivity.setResourceType(activityMap.get("resourceType").toString());
        jdbcQueryActivity.setTimeOut(activityMap.get("timeout").toString());
        jdbcQueryActivity.setCommit(Boolean.valueOf(activityMap.get("commit").toString()));
        // jdbcQueryActivity.setMaxRows(Integer.valueOf(activityMap.get("maxRows")));
        jdbcQueryActivity.setEmptyStringAsNull(Boolean.valueOf(activityMap.get("emptyStrAsNil")));
        jdbcQueryActivity.setQueryStatement(activityMap.get("statement").toString());
        jdbcQueryActivity.setJdbcSharedConfig(activityMap.get("jdbcSharedConfig").toString());

        //jdbcQueryActivity.setQueryOutputStatementParameters(getOutputParameters(node));

        //For QueryStatementParameters extraction using Nodes to get values as using aove extraction we cannot extract all childs which r at same level.

        /* <Prepared_Param_DataType>
                <parameter>
                    <parameterName>outFilename</parameterName>
                    <dataType>VARCHAR</dataType>
                </parameter>
                <parameter>
                    <parameterName>ack997URI</parameterName>
                    <dataType>VARCHAR</dataType>
                </parameter>
                </Prepared_Param_DataType>
               */
        Map<String,String> mapParams = new HashMap<String,String>();;
        NodeList childNodes= node.getChildNodes();
        for (int j = 0; j < childNodes.getLength(); j++) {
            Node configNode = childNodes.item(j);
            if (configNode instanceof Element && configNode.getNodeName().equalsIgnoreCase("config")) {
                //get child of config
                NodeList configChilds= configNode.getChildNodes();
                for (int indexConfig = 0; indexConfig < configChilds.getLength(); indexConfig++) {

                    if(configChilds.item(indexConfig) instanceof Element && configChilds.item(indexConfig).getNodeName().equalsIgnoreCase("Prepared_Param_DataType"))
                    {
                        //get childs of Prepared_Param_DataType
                        NodeList preparedChilds= configChilds.item(indexConfig).getChildNodes();
                        for (int indexPrep = 0; indexPrep < preparedChilds.getLength(); indexPrep++)
                        {

                            if(preparedChilds.item(indexPrep) instanceof Element && preparedChilds.item(indexPrep).getNodeName().equalsIgnoreCase("parameter"))
                            {
                                // get childs in parameter
                                String key="";
                                String value="";
                                NodeList paramChilds= preparedChilds.item(indexPrep).getChildNodes();
                                for (int indexParam = 0; indexParam < paramChilds.getLength(); indexParam++)
                                {
                                    Node paramNode=paramChilds.item(indexParam);

                                    if(paramNode instanceof Element)
                                    {
                                        if(paramNode.getNodeName().equalsIgnoreCase("parameterName"))
                                        {
                                            key=paramNode.getTextContent();
                                        }
                                        else if(paramNode.getNodeName().equalsIgnoreCase("dataType"))
                                        {
                                            value=paramNode.getTextContent();
                                        }

                                    }
                                }
                                mapParams.put(key,value);
                            }
                        }//childs of Prepared_Param_DataType
                    }
                }
            }
        }
        jdbcQueryActivity.setQueryStatementParameters(mapParams);

        //set QueryOutputCached parameters
        jdbcQueryActivity.setQueryOutputStatementParameters(getOutputParameters(node));

        // for input bindings
        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,jdbcQueryActivity);
        jdbcQueryActivity.setInputBindings(activity.getInputBindings());
        jdbcQueryActivity.setParameters(activity.getParameters());

        return jdbcQueryActivity;
    }

    private List<ClassParameter> getOutputParameters(Node node) throws Exception {
         /* <QueryOutputCachedSchemaColumns>TRX_ID</QueryOutputCachedSchemaColumns>
         <QueryOutputCachedSchemaDataTypes>12</QueryOutputCachedSchemaDataTypes>
         <QueryOutputCachedSchemaStatus>RequiredElement</QueryOutputCachedSchemaStatus>*/

        List<ClassParameter> parameters = new ArrayList<ClassParameter>();
        List<String> listSchemaColumns=new ArrayList<String>();
        List<String> listSchemaDataTypes=new ArrayList<String>();
        List<String> listSchemaStatus=new ArrayList<String>();
        NodeList childs= node.getChildNodes();
        for (int i=0;i<childs.getLength();i++) {
            if(childs.item(i).getNodeName().equalsIgnoreCase("config"))
            {
                NodeList configNodes= childs.item(i).getChildNodes();
                //
                for (int chIndex=0;chIndex<configNodes.getLength();chIndex++) {
                    Node nd = configNodes.item(chIndex);

                    if (nd.getNodeName().equalsIgnoreCase("QueryOutputCachedSchemaColumns")) {
                        listSchemaColumns.add(nd.getTextContent());

                    } else if (nd.getNodeName().equalsIgnoreCase("QueryOutputCachedSchemaDataTypes")) {
                        listSchemaDataTypes.add(nd.getTextContent());
                    } else if (nd.getNodeName().equalsIgnoreCase("QueryOutputCachedSchemaStatus")) {
                        listSchemaStatus.add(nd.getTextContent());
                    }
                }
            }

            if(listSchemaColumns.size()>0) {
                for (int index = 0; index < listSchemaColumns.size(); index++) {

                    ClassParameter classParam = new ClassParameter();

                    classParam.setName(listSchemaColumns.get(index));
                    classParam.setType(listSchemaDataTypes.get(index));
                    classParam.setSpecialOption(listSchemaStatus.get(index));

                    parameters.add(classParam);
                }
            }
        }
        return parameters;

    }

}

/**Sample file
 * ------------------
 * xml = "<pd:activity name=\"GetUndlCurrency\" xmlns:pd=\"http://xmlns.tibco.com/bw/process/2003\" xmlns:xsl=\"http://w3.org/1999/XSL/Transform\">\n" +
 "<pd:type>com.tibco.plugin.jdbc.JDBCQueryActivity</pd:type>\n" +
 "<config>\n" +
 "<timeout>10</timeout>\n" +
 "<commit>false</commit>\n" +
 "<maxRows>100</maxRows>\n" +
 "<emptyStrAsNil>false</emptyStrAsNil>\n" +
 "<jdbcSharedConfig>/Configuration/DAI/PNO/JDBC/JDBCIntegration.sharedjdbc</jdbcSharedConfig>\n" +
 "<statement>select CRNCY from T_EQUITY_PNO\n" +
 "where ID_BB_UNIQUE= ?</statement>\n" +
 "<Prepared_Param_DataType>\n" +
 "\t<parameter>\n" +
 "\t\t<parameterName>IdBbUnique</parameterName>\n" +
 "\t\t<dataType>VARCHAR</dataType>\n" +
 "\t</parameter>\n" +
 "\t<parameter>\n" +
 "\t\t<parameterName>IdBbUnique2</parameterName>\n" +
 "\t\t<dataType>VARCHAR</dataType>\n" +
 "\t</parameter>\n" +
 "</Prepared_Param_DataType>\n" +
 "<QueryOutputCachedSchemaColumns>CRNCY</QueryOutputCachedSchemaColumns>\n" +
 "<QueryOutputCachedSchemaDataTypes>12</QueryOutputCachedSchemaDataTypes>\n" +
 "<QueryOutputCachedSchemaStatus>OptionalElement</QueryOutputCachedSchemaStatus>\n" +
 "</config>\n" +
 "<pd:inputBindings>\n" +
 "    <jdbcQueryActivityInput>\n" +
 "        <IdBbUnique>\n" +
 "            <xsl:value-of select=\"testvalue\"/>\n" +
 "        </IdBbUnique>\n" +
 "        <IdBbUnique2>\n" +
 "            <xsl:value-of select=\"EVL\"/>\n" +
 "        </IdBbUnique2>\n" +
 "    </jdbcQueryActivityInput>\n" +
 "</pd:inputBindings>\n" +
 "</pd:activity>";
 *
 */


