package com.dell.dims.Model;

public class GenerateErrorActivity  extends Activity
{
    public GenerateErrorActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public GenerateErrorActivity() throws Exception {
    }

    private String faultName;

    public String getFaultName() {
        return faultName;
    }

    public void setFaultName(String faultName) {
        this.faultName = faultName;
    }
}


