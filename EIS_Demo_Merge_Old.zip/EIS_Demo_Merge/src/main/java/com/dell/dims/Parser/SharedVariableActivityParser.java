//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.Model.SharedVariableActivity;
import com.dell.dims.ModelConfig.SharedVariableConfig;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class SharedVariableActivityParser implements IActivityParser
{

    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        SharedVariableActivity sharedVariableActivity = new SharedVariableActivity();

        String nodeStr=NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("variableConfig", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.variableConfig")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("variableConfig", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.variableConfig")))
                    .asMap();
        }

        sharedVariableActivity.setName(activityMap.get("name"));
        sharedVariableActivity.setType(new ActivityType(activityMap.get("type")));
        sharedVariableActivity.setVariableConfig(activityMap.get("variableConfig"));
        sharedVariableActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,sharedVariableActivity);
        sharedVariableActivity.setInputBindings(activity.getInputBindings());
        sharedVariableActivity.setParameters(activity.getParameters());


        return sharedVariableActivity;
    }

   /* public Activity parse(String inputElement) throws Exception {
        SharedVariableActivity activity = new SharedVariableActivity();


        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();

        activity.setName(activityMap.get("name"));
        activity.setType(new ActivityType(activityMap.get("type")));

        if (activity.getType() == ActivityType.setSharedVariableActivityType)
        {
            activity.setSetterActivity(true);
        }
        else
        {
            activity.setSetterActivity(false);
        }
        *//* [UNSUPPORTED] 'var' as type is unsupported "var" *//*

        SharedVariableConfig config = Extractors.on(inputElement)
                .extract("config", extractBean(new SharedVariableConfig()))
                .asBean(SharedVariableConfig.class);

        activity.setVariableConfig(config.getVariableConfig());

        NodeList childNodes= NodesExtractorUtil.getChildNode(inputElement);
        for (int j = 0; j < childNodes.getLength(); j++) {
            Node node = childNodes.item(j);

            if (node instanceof Element) {
                // a child element to process
                Element element = (Element) node;
                String nodeName = element.getNodeName();

                if (nodeName.equalsIgnoreCase("inputBindings")) {
                    String nodeSubString = NodesExtractorUtil.nodeToString(node);
                    activity.setInputBindings((List<Node>) NodesExtractorUtil.getChildNode(nodeSubString));
                    activity.setParameters((new XslParser()).parse(activity.getInputBindings()));
                }
            }
        }
        return activity;*/
}