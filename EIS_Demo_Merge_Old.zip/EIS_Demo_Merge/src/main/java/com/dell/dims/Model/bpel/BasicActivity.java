package com.dell.dims.Model.bpel;

/**
 * Created by Pramod_Kumar_Tyagi on 8/1/2017.
 */
public class BasicActivity extends Activity{
@Override
public BpelActivityContainerType getBpelActivityContainerType() {
    return BpelActivityContainerType.BASIC;
  }
}
