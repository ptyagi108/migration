package com.dell.dims.Model;

public class AssignActivity  extends Activity
{
    public AssignActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public AssignActivity() throws Exception {
    }

    private String variableName;

    public String getVariableName() {
        return variableName;
    }

    public void setVariableName(String variableName) {
        this.variableName = variableName;
    }
}


