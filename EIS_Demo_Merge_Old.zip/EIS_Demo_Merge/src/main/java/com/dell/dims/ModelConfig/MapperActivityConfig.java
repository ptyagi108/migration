package com.dell.dims.ModelConfig;
import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.ClassParameter;
import com.dell.dims.Model.MapperActivity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MapperActivityConfig
{
    private String xsdReference;
    private Map<String,LinkedHashMap<Object,Object>> listElements=new LinkedHashMap<String,LinkedHashMap<Object,Object>>();

    public String getXsdReference() {
        return xsdReference;
    }

    public void setXsdReference(String xsdReference) {
        this.xsdReference = xsdReference;
    }

    public Object getConfigAttributes(MapperActivity activity) throws Exception {
       // this.setXsdReference(activity.getXsdReference());
        List<ClassParameter> params =activity.getXsdReference();
        for(ClassParameter param : params)
        {
            if(param.getChildProperties()!=null && param.getChildProperties().size()>0) {
                listElements.put(param.getName(),extractElements(param));
            }
        }
        return this;
    }

    /*
    extract elentes name and type for child attributes
      */
    private LinkedHashMap<Object, Object>  extractElements(ClassParameter param)
    {
        LinkedHashMap<Object, Object> mapElements = new LinkedHashMap<Object, Object>();
        for(ClassParameter childParam : param.getChildProperties())
        {

            if(childParam.getType().equalsIgnoreCase("complexType"))
            {
                LinkedHashMap<Object, Object> complexElements = new LinkedHashMap<Object, Object>();
                // iterate params of complex type
                for(ClassParameter complexParam : childParam.getChildProperties())
                {
                    complexElements.put(complexParam.getName(),complexParam.getType());

                }
                mapElements.put(childParam.getName(), complexElements);
            }
            else
            {
                mapElements.put(childParam.getName(), childParam.getType());
            }

        }
        return mapElements;
    }

    public Map<String, LinkedHashMap<Object, Object>> getListElements() {
        return listElements;
    }

    public void setListElements(Map<String, LinkedHashMap<Object, Object>> listElements) {
        this.listElements = listElements;
    }
}


