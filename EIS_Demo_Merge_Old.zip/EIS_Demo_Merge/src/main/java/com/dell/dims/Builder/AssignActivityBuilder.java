package com.dell.dims.Builder;


import com.dell.dims.Model.Activity;

public class AssignActivityBuilder extends AbstractActivityBuilder // extends AbstractActivityBuilder
{

    @Override
    public String build(Activity activity) {
        return null;
    }
}


