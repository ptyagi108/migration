package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;
import com.dell.dims.Router.RoutingRulesDefinition;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 2/6/2017.
 */
public class InputBinding {

    private String activityType;
    private String activityName;
    private boolean isSubprocess;// in case activity contains sub activity for doing it's task

    private Map<String,Object> endPointOptions;
    private Map<String,Object> attributesList;
    private String schemeName;

    protected RoutingRulesDefinition routeRuleDef= new RoutingRulesDefinition();

    public String getSchemeName() {
        return schemeName;
    }

    public void setSchemeName(String schemeName) {
        this.schemeName = schemeName;
    }

    public Map<String, Object> getEndPointOptions() {
        return endPointOptions;
    }

    public void setEndPointOptions(Map<String, Object> endPointOptions) {
        this.endPointOptions = endPointOptions;
    }

    public RoutingRulesDefinition getRouteRuleDef() {
        return routeRuleDef;
    }

    public void setRouteRuleDef(RoutingRulesDefinition routeRuleDef) {
        this.routeRuleDef = routeRuleDef;
    }

    public Map<String, Object> getAttributesList() {
        return attributesList;
    }

    public void setAttributesList(Map<String, Object> attributesList) {
        this.attributesList = attributesList;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public boolean isSubprocess() {
        return isSubprocess;
    }

    public void setSubprocess(boolean subprocess) {
        isSubprocess = subprocess;
    }

    /***
     * @param activity
     * @return
     */
    public InputBinding captureInputBindingAttributes(Activity activity)
    {
        System.out.println("*************captureEndpoints of super class InputBinding is invoked ********");
        return this;
    }

    /** method to get Attribute value
     * @param classParam
     * @param attributeName
     * @return
     */

    protected StringBuilder captureAttributeValue(ClassParameter classParam,String attributeName)
    {
        ClassParameter param = routeRuleDef.getRouteNode(classParam, attributeName);
        StringBuilder attributeValue=new StringBuilder("");
        if (param != null)
        {
            attributeValue = new StringBuilder();
            attributeValue = routeRuleDef.getValueOfLastNode(param, attributeValue);
            //  mapAttr.put(attributeName, attributeValue.toString().trim());
        }
        return attributeValue;
    }
}
