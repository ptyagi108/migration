package com.dell.dims.Model;

/**
 * Created by Kriti_Kanodia on 1/16/2017.
 */
public class FileWriteActivity extends Activity {

    public FileWriteActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public FileWriteActivity() throws Exception {
    }

    private String encoding;
    private String compressFile;
    private boolean createMissingDirectories;
    private boolean append;

    public boolean isAppend() {
        return append;
    }

    public void setAppend(boolean append) {
        this.append = append;
    }






    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public String getCompressFile() {
        return compressFile;
    }

    public void setCompressFile(String compressFile) {
        this.compressFile = compressFile;
    }

    public boolean isCreateMissingDirectories() {
        return createMissingDirectories;
    }

    public void setCreateMissingDirectories(boolean createMissingDirectories) {
        this.createMissingDirectories = createMissingDirectories;
    }


}
