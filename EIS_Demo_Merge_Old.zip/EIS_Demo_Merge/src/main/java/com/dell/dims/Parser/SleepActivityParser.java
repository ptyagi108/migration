package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.Model.SleepActivity;
import com.dell.dims.Parser.Utils.XmlnsConstant;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

public class SleepActivityParser implements IActivityParser
{

    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        SleepActivity sleepActivity = new SleepActivity();

        String nodeStr=NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .asMap();
        }

        sleepActivity.setName(activityMap.get("name"));
        sleepActivity.setType(new ActivityType(activityMap.get("type")));
        sleepActivity.setResourceType(activityMap.get("resourceType"));
        sleepActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,sleepActivity);
        sleepActivity.setInputBindings(activity.getInputBindings());
        sleepActivity.setParameters(activity.getParameters());


        return sleepActivity;
    }

    /*
    public Activity parse(String inputElement) throws Exception {
    SleepActivity activity = new SleepActivity();
    // sleep activity
    Map<String, String> activityMap = Extractors.on(inputElement)
            .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
            .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
            .asMap();
// for input bindings
    NodeList childNodes= NodesExtractorUtil.getChildNode(inputElement);
    for (int j = 0; j < childNodes.getLength(); j++) {
        Node node = childNodes.item(j);

        if (node instanceof Element) {
            // a child element to process
            Element element = (Element) node;
            String nodeName = element.getNodeName();

            if (nodeName.equalsIgnoreCase("inputBindings")) {
                String nodeSubString = NodesExtractorUtil.nodeToString(node);

                // extract SleepInputSchema
                NodeList cnode= NodesExtractorUtil.getChildNode(nodeSubString);
                for (int cn = 0; cn < cnode.getLength(); cn++) {

                    if(cnode.item(cn).getNodeName().equalsIgnoreCase(XmlnsConstant.sleeptibcoActivityNameSpace + "SleepInputSchema"))
                    {
                        activity.setInputBindings((List<Node>) cnode.item(cn).getChildNodes());
                        activity.setParameters((new XslParser()).parse(activity.getInputBindings()));
                    }
                }

            }
        }
    }


    return activity;
}*/


}



