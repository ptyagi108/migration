package com.dell.dims.Model;

public class WriteToLogActivity  extends Activity
{
    public WriteToLogActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public WriteToLogActivity() throws Exception {
    }

    private String role = new String();
    public String getRole() {
        return role;
    }

    public void setRole(String value) {
        role = value;
    }

}


