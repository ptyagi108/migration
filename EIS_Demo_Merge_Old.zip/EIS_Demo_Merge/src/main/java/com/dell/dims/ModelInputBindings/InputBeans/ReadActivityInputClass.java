package com.dell.dims.ModelInputBindings.InputBeans;

/**
 * Created by Manoj_Mehta on 3/7/2017.
 */
public class ReadActivityInputClass {

    private String fileName;
    private String value;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
