package com.dell.dims.xls_mapper;

import com.dell.dims.endpoint.uri.DefaultEndpoint;
import com.gh.mygreen.xlsmapper.annotation.XlsHorizontalRecords;
import com.gh.mygreen.xlsmapper.annotation.XlsSheet;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Pramod_Kumar_Tyagi on 7/22/2016.
 */

@XlsSheet(name = "ENDPOINTS")
@Component
public class EndpointsXlsRenderer {

    @XlsHorizontalRecords(tableLabel = "ENDPOINTS")
    private List<DefaultEndpoint> endpoints = new ArrayList<DefaultEndpoint>();


    public List<DefaultEndpoint> getEndpoints() {
        return endpoints;
    }

    public void setEndpoints(List<DefaultEndpoint> endpoints) {
        this.endpoints = endpoints;
    }
}
