package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.JavaActivity;
import com.dell.dims.Model.ListFilesActivity;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

/**
 * Created by Manoj_Mehta on 4/7/2017.
 */
public class ListFilesActivityParser implements IActivityParser {
    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        ListFilesActivity listFileActivity = new ListFilesActivity();

        String nodeStr= NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .extract("mode", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.mode")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("mode", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.mode")))
                    .asMap();
        }

        listFileActivity.setName(activityMap.get("name"));
        listFileActivity.setType(new ActivityType(activityMap.get("type")));
        listFileActivity.setResourceType(activityMap.get("resourceType"));
        listFileActivity.setMode(activityMap.get("mode"));

        listFileActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,listFileActivity);
        listFileActivity.setInputBindings(activity.getInputBindings());
        listFileActivity.setParameters(activity.getParameters());

        return listFileActivity;
    }
}
