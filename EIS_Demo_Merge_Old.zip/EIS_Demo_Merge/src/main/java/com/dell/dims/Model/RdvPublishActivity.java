package com.dell.dims.Model;

public class RdvPublishActivity  extends Activity
{
    public RdvPublishActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public RdvPublishActivity() throws Exception {
    }

    private String subject;
    private String sharedChannel;
    private boolean isXmlEncode;
    private String xsdString;


    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSharedChannel() {
        return sharedChannel;
    }

    public void setSharedChannel(String sharedChannel) {
        this.sharedChannel = sharedChannel;
    }

    public boolean isXmlEncode() {
        return isXmlEncode;
    }

    public void setXmlEncode(boolean xmlEncode) {
        isXmlEncode = xmlEncode;
    }

    public String getXsdString() {
        return xsdString;
    }

    public void setXsdString(String xsdString) {
        this.xsdString = xsdString;
    }
}


