package com.dell.dims.ModelConfig;

import com.dell.dims.Model.CallProcessActivity;

/**
 * Created by Manoj_Mehta on 12/28/2016.
 */
public class CallProcessActivityConfig {

    private String  processName;

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public Object getConfigAttributes(CallProcessActivity activity) throws Exception {
        this.setProcessName(activity.getProcessName());
        return this;
    }
}
