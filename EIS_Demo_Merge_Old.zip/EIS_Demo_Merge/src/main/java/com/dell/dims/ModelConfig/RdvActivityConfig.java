package com.dell.dims.ModelConfig;

/**
 * Created by Kriti_Kanodia on 1/2/2017.
 */
public class RdvActivityConfig {

    private String subject;
    private String sharedChannel;
    private boolean xmlEncoding;
    private String xsdString;



    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSharedChannel() {
        return sharedChannel;
    }

    public void setSharedChannel(String sharedChannel) {
        this.sharedChannel = sharedChannel;
    }

    public boolean isXmlEncoding() {
        return xmlEncoding;
    }

    public void setXmlEncoding(boolean xmlEncoding) {
        this.xmlEncoding = xmlEncoding;
    }

    public String getXsdString() {
        return xsdString;
    }

    public void setXsdString(String xsdString) {
        this.xsdString = xsdString;
    }



}
