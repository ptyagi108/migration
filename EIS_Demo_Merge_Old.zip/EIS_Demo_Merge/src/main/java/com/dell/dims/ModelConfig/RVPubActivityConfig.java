package com.dell.dims.ModelConfig;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.RVPubActivity;

/**
 * Created by Manoj_Mehta on 3/1/2017.
 */
public class RVPubActivityConfig
{
    private boolean wantsXMLCompliantFieldNames;
    private String sharedChannel;
    private boolean xmlEncoding;
    private String xsdString;

    public boolean isWantsXMLCompliantFieldNames() {
        return wantsXMLCompliantFieldNames;
    }

    public void setWantsXMLCompliantFieldNames(boolean wantsXMLCompliantFieldNames) {
        this.wantsXMLCompliantFieldNames = wantsXMLCompliantFieldNames;
    }

    public String getSharedChannel() {
        return sharedChannel;
    }

    public void setSharedChannel(String sharedChannel) {
        this.sharedChannel = sharedChannel;
    }

    public boolean isXmlEncoding() {
        return xmlEncoding;
    }

    public void setXmlEncoding(boolean xmlEncoding) {
        this.xmlEncoding = xmlEncoding;
    }

    public String getXsdString() {
        return xsdString;
    }

    public void setXsdString(String xsdString) {
        this.xsdString = xsdString;
    }

    public Object getConfigAttributes(RVPubActivity activity) throws Exception {
        this.setWantsXMLCompliantFieldNames(activity.isWantsXMLCompliantFieldNames());
        this.setSharedChannel(activity.getSharedChannel());
        this.setXmlEncoding(activity.isXmlEncoding());
        this.setXsdString(activity.getXsdString());
        return this;
    }
}
