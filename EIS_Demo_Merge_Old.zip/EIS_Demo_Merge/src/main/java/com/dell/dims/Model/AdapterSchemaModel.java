//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:13 PM
//

package com.dell.dims.Model;


public class AdapterSchemaModel
{
    private String nameSpace;

    public String getNameSpace() {
        return nameSpace;
    }

    public void setNameSpace(String nameSpace) {
        this.nameSpace = nameSpace;
    }
}


