package com.dell.dims.ModelConfig;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileReadActivity;
import com.dell.dims.Model.SetSharedVariableActivity;

public class SetSharedVariableActivityConfig
{

    private String variableConfig;
    private boolean showResult;

    public String getVariableConfig() {
        return variableConfig;
    }

    public void setVariableConfig(String variableConfig) {
        this.variableConfig = variableConfig;
    }

    public boolean isShowResult() {
        return showResult;
    }

    public void setShowResult(boolean showResult) {
        this.showResult = showResult;
    }

    public Object getConfigAttributes(SetSharedVariableActivity activity) throws Exception {
        this.setVariableConfig(activity.setVariableConfig());
        this.setShowResult(activity.isShowResult());
        return this;
    }

}


