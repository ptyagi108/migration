package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 2/27/2017.
 */
public class FileRenameActivityInputBinding extends InputBinding
{
    @Override
    public InputBinding captureInputBindingAttributes(Activity activity)
    {
        InputBinding inputBindings=new InputBinding();
        Map<String,Object> mapAttributesList= new HashMap<String,Object>();
        String attribute="";
        StringBuilder attributeVal;


        // check if current process is subprocess
        if(activity.getResourceType().toUpperCase().contains(".subprocess".toUpperCase()))
        {
            System.out.println("\n*****Subprocess EXIST for*****"+activity.getName() + " Process");
            inputBindings.setSubprocess(true);
        }

        List<ClassParameter> paramList = activity.getParameters();
        if (paramList.size() > 0)
        {
            for (ClassParameter classParam : paramList)
            {
                //check for fromFileName
                attribute="fromFileName";
                attributeVal=captureAttributeValue( classParam,attribute);
                if(attributeVal!=null && attributeVal.length()>0)
                {
                    mapAttributesList.put(attribute,attributeVal.toString());
                }

                //CheckFor toFileName
                attribute="toFileName";
                attributeVal=captureAttributeValue(classParam,attribute);
                if(attributeVal!=null && attributeVal.length()>0)
                {
                    mapAttributesList.put(attribute,attributeVal.toString());
                }
            }
        }
        inputBindings.setSchemeName("FILE");
        inputBindings.setActivityName(activity.getName());
        inputBindings.setActivityType(activity.getType().toString());
        inputBindings.setEndPointOptions(mapAttributesList);

        return inputBindings;

    }
}
