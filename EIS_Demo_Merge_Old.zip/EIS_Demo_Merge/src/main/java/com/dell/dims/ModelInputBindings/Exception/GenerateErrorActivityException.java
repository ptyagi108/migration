package com.dell.dims.ModelInputBindings.Exception;

import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.GenerateErrorActivity;
import com.dell.dims.ModelInputBindings.GenerateErrorActivityInputBinding;

/**
 * Created by Manoj_Mehta on 2/8/2017.
 */
public class GenerateErrorActivityException extends GenerateErrorActivityInputBinding {

    private String messgae;
    private String messgaeCode;

    public String getMessgae() {
        return messgae;
    }

    public void setMessgae(String messgae) {
        this.messgae = messgae;
    }

    public String getMessgaeCode() {
        return messgaeCode;
    }

    public void setMessgaeCode(String messgaeCode) {
        this.messgaeCode = messgaeCode;
    }
}