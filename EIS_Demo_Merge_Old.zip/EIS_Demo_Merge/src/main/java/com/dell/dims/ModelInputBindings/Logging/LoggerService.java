package com.dell.dims.ModelInputBindings.Logging;

/**
 * Created by Manoj_Mehta on 2/28/2017.
 */
public class LoggerService
{
    LoggerService.LogHeader logHeader;
    LoggerService.LogBody logBody;

    public LogHeader getLogHeader() {
        return logHeader;
    }

    public void setLogHeader(LogHeader logHeader) {
        this.logHeader = logHeader;
    }

    public LogBody getLogBody() {
        return logBody;
    }

    public void setLogBody(LogBody logBody) {
        this.logBody = logBody;
    }

    // inner header class
    public class LogHeader
    {
        private String applicationName;
        private String processName;
        private String from;
        private String logType;


        public String getApplicationName() {
            return applicationName;
        }

        public void setApplicationName(String applicationName) {
            this.applicationName = applicationName;
        }

        public String getProcessName() {
            return processName;
        }

        public void setProcessName(String processName) {
            this.processName = processName;
        }

        public String getFrom() {
            return from;
        }

        public void setFrom(String from) {
            this.from = from;
        }

        public String getLogType() {
            return logType;
        }

        public void setLogType(String logType) {
            this.logType = logType;
        }
    }

    // inner body class
    public class LogBody
    {
        private String payloadType;
        private String payload;

        public String getPayloadType() {
            return payloadType;
        }

        public void setPayloadType(String payloadType) {
            this.payloadType = payloadType;
        }

        public String getPayload() {
            return payload;
        }

        public void setPayload(String payload) {
            this.payload = payload;
        }
    }
}
