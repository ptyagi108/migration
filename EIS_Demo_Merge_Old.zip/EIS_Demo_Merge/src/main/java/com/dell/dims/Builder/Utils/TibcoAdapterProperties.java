package com.dell.dims.Builder.Utils;

/**
 * Created by Kriti_Kanodia on 6/8/2017.
 */
public class TibcoAdapterProperties {

    private String activityType;
    private String rootName;
    private String property;
    private String type;
  private String classType;

  public String getActivityType() {
    return activityType;
  }

  public void setActivityType(String activityType) {
    this.activityType = activityType;
  }

  public String getRootName() {
    return rootName;
  }

  public void setRootName(String rootName) {
    this.rootName = rootName;
  }

  public String getProperty() {
    return property;
  }

  public void setProperty(String property) {
    this.property = property;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getClassType() {
    return classType;
  }

  public void setClassType(String classType) {
    this.classType = classType;
  }
}
