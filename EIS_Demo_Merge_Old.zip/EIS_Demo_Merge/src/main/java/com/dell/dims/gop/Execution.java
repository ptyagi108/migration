package com.dell.dims.gop;

/**
 * @author pramod
 */
public class Execution {
    private ProcessDefinition processDefinition;
    private Token mainToken;


    public Execution(ProcessDefinition processDefinition) {
        this.processDefinition = processDefinition;
        this.mainToken = new Token();
        //Setting the first GopNode as the current GopNode

        this.getMainToken().setNode(processDefinition.getNodes().get(0));
    }

    public void start() {
        //Here we send the execution pointer to the node, so all the nodes could change
        //the current node pointer when each node get executed. This could vary from
        //one implementation to another. Because, sometimes there is no need to change
        //the current node until some wait state is reached.
        this.getMainToken().getNode().leave(mainToken);
    }


    /**
     * @return the processDefinition
     */
    public ProcessDefinition getProcessDefinition() {
        return processDefinition;
    }

    /**
     * @param processDefinition the processDefinition to set
     */
    public void setProcessDefinition(ProcessDefinition processDefinition) {
        this.processDefinition = processDefinition;
    }


    public Token getMainToken() {
        return mainToken;
    }

    public void setMainToken(Token mainToken) {
        this.mainToken = mainToken;
    }


}
