package com.dell.dims.service;

import static com.dell.dims.Model.ActivityType.sleepActivity;
import static im.nll.data.extractor.Extractors.xpath;
import static im.nll.data.extractor.Extractors.selector;

import com.dell.dims.Model.*;
import com.dell.dims.ModelConfig.*;
import com.dell.dims.ModelInputBindings.*;
import com.dell.dims.ModelInputBindings.Logging.LoggerService;
import com.dell.dims.Parser.TibcoBWProcessLinqParser;
import com.dell.dims.Router.RoutingRulesDefinition;
import com.dell.dims.Router.TransitionFlow;
import com.dell.dims.Utils.PropertiesUtil;
import com.dell.dims.Utils.UnzipUtility;
import im.nll.data.extractor.Extractors;
import im.nll.data.extractor.utils.XmlUtils;

import java.io.*;
import java.util.*;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.w3c.dom.Node;

import com.dell.dims.dto.DimsDTO;
import com.dell.dims.endpoint.uri.DefaultEndpoint;
import com.dell.dims.endpoint.uri.file.OracleFileEndpoint;
import com.dell.dims.freemarker.TemplateAbsolutePathLoader;
import com.dell.dims.gop.EndGopNode;
import com.dell.dims.gop.GopNode;
import com.dell.dims.gop.ProcessDefinition;
import com.dell.dims.gop.StartGopNode;
import com.dell.dims.gop.Transition;
import com.dell.dims.util.RuntimeDimsException;
import com.dell.dims.xls_mapper.EndpointsXlsRenderer;
import com.gh.mygreen.xlsmapper.XlsMapper;
import com.gh.mygreen.xlsmapper.XlsMapperException;

import freemarker.cache.ConditionalTemplateConfigurationFactory;
import freemarker.cache.FileNameGlobMatcher;
import freemarker.core.TemplateConfiguration;
import freemarker.core.XMLOutputFormat;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import soa.OutputDirect.OutputGeneratorDirect;
import soa.OutputFromTibco.OutputGenerator;
import soa.OutputGeneratorNew;

public class DimsServiceImpl {

    public static ApplicationContext ctx;
    private static String output_project_path;
    private static String templates_path;
    public static String input_project_path;
    public static String input_projectEAR_path;
    public static Properties props;

    OutputGeneratorNew outputGenerator;
    /**
     * Size of the buffer to read/write data
     */
    private static final int BUFFER_SIZE = 4096;

    public void process(DimsDTO dimsDTO) {

        try {
            Init(dimsDTO);

            ProcessDefinition pd = null;

            //iterate files to be processed
            Collection<File> tibcoProcessFiles;
            File dir = new File(input_project_path+File.separator+"BusinessProcesses");
            String[] extensions = new String[]{"process"};
            tibcoProcessFiles = FileUtils.listFiles(dir, extensions, true);

            System.out.println("List of Files to Process ::::::::" + tibcoProcessFiles);
            for (File file : tibcoProcessFiles) {
                System.out.println(file.getName());
            }

            String fileString = "";
            for (File file : tibcoProcessFiles) {
                try {
                    fileString = XmlUtils.removeNamespace(IOUtils.toString(
                            new FileInputStream(file), "UTF-8"));

                    System.out.println("File Going to Process :::::::::::::::::::::::::" + file.getName());

                    //processing start for each file
                    pd = processTibcoFiles(fileString);

                    // Print route graph
                    //	System.out.println(pd.routeGraph());
                    //pd.setRoutegraph(pd.routeGraph());

                    // sort Transition flow in order
                    TransitionFlow transitionFlow = new TransitionFlow();
                    String transitionFlowRoute = String.valueOf(transitionFlow.sortProcessTransition(pd));
                    //System.out.println("************Project Transition Flow at Adapter Level ::*****************\n" + transitionFlowRoute);
                    pd.setRoutegraph(transitionFlowRoute);

                    //****************Now Fetch Process/Actitivity from PD in sequence one at a time to map sililar component in SOA.
                    System.out.println("************Project Transition Flow Graph at Adapter Level ::*****************\n" + transitionFlowRoute);

                    LinkedHashMap<String,ArrayList<String>> listNormalTransition=pd.getSortedNormalTransitionList();
                    if(listNormalTransition!=null) {
                        for (String key : listNormalTransition.keySet()) {
                            System.out.println("Key ::" + key);

                            List<GopNode> listNodes = pd.getNodes();

                            for (int index = 0; index < listNodes.size(); index++) {
                                if (listNodes.get(index).getName().equalsIgnoreCase(key)) {
                                    System.out.println("Node found ::" + listNodes.get(index).getTransitions());

                                    //    Activity activity= (Activity) listNodes.get(index);
                                    //   System.out.println("activity name :"+activity.getName());

                                }
                            }
                        }
                    }


                    //getting global variables from Tibco
                    GlobalVariablesRepository glRepo=new GlobalVariablesRepository();
                  //  pd.setGlobalVariables(glRepo.getGlobalVariables());

                    // Generate XLS
                    //	RenderToXls(pd);
                    //Map<String, Object> root = processXls();
                    //processTemplates(root);

                    //using POI
                    //PoiWrite.RendertoXls(pd);


                    //************************************************ Calling SOA Specific Code******************************************************
                    //Sample "FilePoller" Project
                    pd.setName("BPELProcess1");

                    // needs to uncomment later
                   /* outputGenerator= new OutputGeneratorNew(pd);
                    outputGenerator.generateSOAProject(pd);

                    //temp code , comment later
                    OutputGeneratorDirect soaOutputDirect = new OutputGeneratorDirect();
                    soaOutputDirect.generateSOACode(pd);

                    Map<String, HashMap<String,String>> artifactsMap = OutputGeneratorDirect.soaArtifactsMap;*/


                    //New dynamic code, need to uncomment later
                    OutputGenerator outputGenerator=new OutputGenerator();
                    if(pd!=null)
                    {
                        outputGenerator.iterateTibcoProject(pd);
                    }
                    else
                    {
                        System.out.println("Cannot convert Project to SOA as ProcessDefinition is missing..");
                    }

                    Map<String, HashMap<String,String>> artifactsMap=outputGenerator.soaArtifactsMap;

                    // getting artifacts list
                //     Map<String, HashMap<String,String>> artifactsMap = OutputGeneratorNew.soaArtifactsMap;

                    //	processTemplates(artifactsMap);

                    // Writing artifactes to SOA Directories
                    if(artifactsMap==null)
                    {
                        return;
                    }
                    for (String key : artifactsMap.keySet()) {
                        String value = artifactsMap.get(key).toString();
                        StringBuilder filePath= new StringBuilder(output_project_path);
                        String fileName="";
                        String subPath="SOA";
                        String ext=".txt";

                        String valueArtifact="";

                        if(key.equalsIgnoreCase("COMPOSITE")) //SOA/
                        {
                          //  artifactsMap.get(key).get("composite")
                            filePath.append("\\"+subPath);
                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".xml";
                                fileName=keyInnerMap+ext;
                                writeToFile(valueArtifact,filePath.toString() , fileName);
                            }
                        }
                         else if(key.equalsIgnoreCase("WSDL"))//SOA/WSDLs/
                        {
                            subPath=subPath+"\\"+"WSDLs";
                            filePath.append("\\"+subPath);
                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                              //  System.out.println("valueArtifact *****WSDLs**"+valueArtifact);
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".wsdl";
                                fileName=keyInnerMap+ext;
                                writeToFile(valueArtifact,filePath.toString() , fileName);
                            }
                        }
                        else if(key.equalsIgnoreCase("JCA"))//SOA/Adapters/
                        {
                            subPath=subPath+"\\"+"Adapters";
                            filePath.append("\\"+subPath);
                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                              //  System.out.println("valueArtifact *****Adapters**"+valueArtifact);
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".jca";

                                // append with _file for file operations
                                if(keyInnerMap.equalsIgnoreCase("ListFiles") || keyInnerMap.equalsIgnoreCase("FilePoller") )
                                {
                                    keyInnerMap=keyInnerMap+"_file";
                                }
                                else if(keyInnerMap.equalsIgnoreCase("FTPPut"))
                                {
                                    keyInnerMap=keyInnerMap+"_ftp";
                                }

                                fileName=keyInnerMap+ext;

                                writeToFile(valueArtifact,filePath.toString() , fileName);
                            }
                        }
                        else if(key.equalsIgnoreCase("BPEL"))//SOA/BPEL
                        {
                            subPath=subPath+"\\"+"BPEL";
                            filePath.append("\\"+subPath);
                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".bpel";
                                fileName=keyInnerMap+ext;

                                writeToFile(valueArtifact, filePath.toString(), fileName);
                            }
                        }

                        else if(key.equalsIgnoreCase("SCHEMA"))//SOA/SCHEMAS
                        {
                            subPath=subPath+"\\"+"Schemas";
                            filePath.append("\\"+subPath);
                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".xsd";
                                fileName=keyInnerMap+ext;

                                writeToFile(valueArtifact, filePath.toString(), fileName);
                            }
                        }

                        else if(key.equalsIgnoreCase("TRANSFORMATIONS"))//SOA/TRANSFORMATIONS
                        {
                            subPath=subPath+"\\"+"Transformations";
                            filePath.append("\\"+subPath);

                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".xsl";
                                fileName=keyInnerMap+ext;

                                writeToFile(valueArtifact, filePath.toString(), fileName);
                            }

                        }

                        else if(key.equalsIgnoreCase("SPRING"))//SOA/TRANSFORMATIONS
                        {
                            subPath=subPath+"\\"+"Spring";
                            filePath.append("\\"+subPath);

                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".xml";
                                fileName=keyInnerMap+ext;

                                writeToFile(valueArtifact, filePath.toString(), fileName);
                            }

                        }

                        else if(key.equalsIgnoreCase("SOURCE"))//SOA/TRANSFORMATIONS
                        {
                           // subPath="Application Sources";
                            subPath=subPath+File.separator+File.separator+"Application Sources"+File.separator+"CommonProcesses"+File.separator+"listFiles";

                            //CommonProcesses.listFiles
                            //subPath=subPath+"\\"+"CommonProcesses.listFiles"+\\+"Application Sources";
                            filePath.append("\\"+subPath);

                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".java";
                                fileName=keyInnerMap+ext;

                                writeToFile(valueArtifact, filePath.toString(), fileName);
                            }

                        }
                        else if(key.equalsIgnoreCase("JPR")) //SOA/
                        {
                            //  artifactsMap.get(key).get("composite")
                            //filePath.append("\\"+subPath);
                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".jpr";
                                fileName=keyInnerMap+ext;
                                writeToFile(valueArtifact,filePath.toString() , fileName);
                            }
                        }
                        else if(key.equalsIgnoreCase("DVM"))//DVM
                        {
                            subPath=subPath+"\\"+"DVM";
                            filePath.append("\\"+subPath);
                            for (String keyInnerMap : artifactsMap.get(key).keySet())
                            {
                                valueArtifact=artifactsMap.get(key).get(keyInnerMap);
                                ext=".dvm";
                                fileName=keyInnerMap+ext;

                                writeToFile(valueArtifact, filePath.toString(), fileName);
                            }
                        }


                    }
                    System.out.println("processed");

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (TransformerException e) {
                    e.printStackTrace();
                }
            }
        } catch (XlsMapperException e) {
            throw new RuntimeDimsException(e);
        } catch (IOException e) {
            throw new RuntimeDimsException(e);
        } catch (Exception e) {
            throw new RuntimeDimsException(e);
        }
     }

    private static void RenderToXls(ProcessDefinition pd) throws Exception {
        EndpointsXlsRenderer xls2pojo = new EndpointsXlsRenderer();

        for (GopNode node : pd.getNodes()) {
            //Code for group Activity @Manoj Mehta
            if (node instanceof GroupActivity) {
                DefaultEndpoint endpoint = new DefaultEndpoint();
                //endpoint.setPath(((TibcoGroup) node).getPath());
                //Test code @Manoj
                endpoint.setEndPointName(node.getName());
                GroupActivity groupActivity = (GroupActivity) node;
                GroupActivityConfig groupActivityConfig = new GroupActivityConfig();
                endpoint.createUriParams(groupActivityConfig.getConfigAttributes(groupActivity));
                xls2pojo.getEndpoints().add(endpoint);

                // activity inside Group upto Level-1
                if (groupActivity.getActivities().size() > 0) {
                    List<Activity> listActivity = groupActivity.getActivities();
                    for (Activity activity : listActivity) {
                        //handle for sub group
                        if (activity instanceof GroupActivity) {
                            List<Activity> listActivityGrp = ((GroupActivity) activity).getActivities();
                            for (Activity activityGrp : listActivityGrp) {
                                // add Endpoint for activities
                                addActivityEndpoint(activityGrp, xls2pojo);
                                //routing rule
                                RoutingRulesDefinition routingRule = new RoutingRulesDefinition();
                                System.out.println("routingRule ::::group::::::::: for Activity ::" + activityGrp.getName() + routingRule.getRoutingRule(activityGrp));
                            }
                        } else {
                            // add Endpoint for activities
                            addActivityEndpoint(activity, xls2pojo);

                            //routing rule
                            RoutingRulesDefinition routingRule = new RoutingRulesDefinition();
                            System.out.println("routingRule ::::group::::::::: for Activity ::" + activity.getName() + routingRule.getRoutingRule(activity));
                        }
                    }
                }
            } else if (node instanceof Activity) {
                // Get ACtivity
                Activity activity = (Activity) node;
                addActivityEndpoint(activity, xls2pojo);

                //routing rule
                RoutingRulesDefinition routingRule = new RoutingRulesDefinition();
                System.out.println("routingRule :::for Activity::::::::::" + activity.getName() + "::" + routingRule.getRoutingRule(activity));
            }
        }

        InputStream is = ctx.getResource("Dims_template.xlsm").getInputStream();
        FileOutputStream os = new FileOutputStream("out.xlsm");
        XlsMapper xlsMapper = new XlsMapper();

        xlsMapper.saveMultiple(is, // for template excel file.
                os, // for output excel file.
                new Object[]{pd, xls2pojo} // for created sheet data.
        );
    }


    private static void Init(DimsDTO dimsDTO) throws IOException {
        ctx = new ClassPathXmlApplicationContext("spring-placeholder-config.xml");
//		ctx = SpringApplication.run(DimsServiceImpl.class, args);
        String[] beanNames = ctx.getBeanDefinitionNames();
        Arrays.sort(beanNames);
        for (String beanName : beanNames) {
            System.out.println(beanName);
        }
        input_project_path = dimsDTO.getInputPath();
        output_project_path = dimsDTO.getOutputPath();
        templates_path = dimsDTO.getTemplatesPath();

        /*
         If we need to migrate application using ear
         Extraction of EAR File
          */
        input_projectEAR_path=dimsDTO.getInputPath()+File.separator+"Project_EAR"+File.separator+"FilePoller.ear";
        //check if it contains Project EAR
        File file=new File(input_projectEAR_path);

        if(file.exists())
        {
            // extract Zip/ear files
            String extractonDirectory=dimsDTO.getInputPath()+File.separator+"Extracted_EAR";

            UnzipUtility unzipUtil=new UnzipUtility();

            //unzip .ear
            unzipUtil.unzip(input_projectEAR_path,extractonDirectory);

            //unzip Process Archive.par
            input_projectEAR_path=extractonDirectory+File.separator+"Process Archive.par";
            unzipUtil.unzip(input_projectEAR_path,input_project_path+File.separator+"Processes");

            //unzip Shared Archive.sar
            input_projectEAR_path=extractonDirectory+File.separator+"Shared Archive.sar";
            unzipUtil.unzip(input_projectEAR_path,input_project_path+File.separator+"Processes");
        }
            copyDirectory(output_project_path, templates_path);

//		ConfigurableApplicationContext ap = new ClassPathXmlApplicationContext("file:src/main/resources/tibco.properties");
//		String[] beanNames = ap.getBeanDefinitionNames();
//		Arrays.sort(beanNames);
//		for (String beanName : beanNames) {
//			System.out.println(beanName);
//		}
        Resource resource = new ClassPathResource("tibco.properties");
        props = PropertiesLoaderUtils.loadProperties(resource);
        PropertiesUtil.setProps(props);

    }

    private static void processTemplates(Map<String, Object> root)
            throws IOException, TemplateException {
        File dir = new File(output_project_path);
        String[] extensions = new String[]{"jca"};
        Collection<File> files = FileUtils.listFiles(dir, extensions, true);
        Configuration cfg = getFreemarkerConfiguration();
        for (File file : files) {

            Template temp = cfg.getTemplate(file.getPath());
            OutputStream os = new FileOutputStream(file.getPath());
            // System.out.println("file.getPath()*******************************"+file.getPath());
            Writer out = new OutputStreamWriter(os);
            temp.process(root, out);
        }
    }

    private static Configuration getFreemarkerConfiguration() {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_25);

        try {
            cfg.setDirectoryForTemplateLoading(new File(output_project_path));
        } catch (IOException e) {
            e.printStackTrace();
        }

        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        cfg.setLogTemplateExceptions(false);
        TemplateConfiguration tcXML = new TemplateConfiguration();
        tcXML.setOutputFormat(XMLOutputFormat.INSTANCE);
        cfg.setTemplateConfigurations(new ConditionalTemplateConfigurationFactory(
                new FileNameGlobMatcher("*.jca"), tcXML));
        cfg.setTemplateLoader(new TemplateAbsolutePathLoader());
        return cfg;
    }

    private static Map<String, Object> processXls() throws IOException,
            XlsMapperException {
        Map<String, Object> root = new HashMap<>();
        XlsMapper xlsMapper = new XlsMapper();
        EndpointsXlsRenderer xls2bean = xlsMapper.load(
                ctx.getResource("file:out.xlsm").getInputStream(), // excel
                // sheet.
                EndpointsXlsRenderer.class // POJO class.
        );
        int i = 0;
        for (DefaultEndpoint uri : xls2bean.getEndpoints()) {
            OracleFileEndpoint options = new OracleFileEndpoint();
            System.out.println("**************************PATH**********" + uri.getPath());
            if (uri.getPath() == null) {
                uri.setPath("");
            }
            System.out.println("******************************PATH After **********" + uri.getPath());
            uri.parseQueryOptions(options);
            root.put("File_Endpoint" + i++, uri);
            System.out.println("output ::::File_Endpoint::::::::::::::" + uri.getUriParams());
        }
        return root;
    }

    private static void copyDirectory(String output_project_path,
                                      String templates_path) {
        File source = new File(templates_path);
        File dest = new File(output_project_path);
        try {
            FileUtils.copyDirectory(source, dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String nodeToString(Node node) {
        StringWriter sw = new StringWriter();
        try {
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            t.transform(new DOMSource(node), new StreamResult(sw));
        } catch (TransformerException te) {
            System.out.println("nodeToString Transformer Exception");
        }
        return sw.toString();
    }


    private static Transition groupTransition(String nodeString, ProcessDefinition processDefinition) {
        {
            Transition transition = new Transition();
            GopNode source = null;
            GopNode dest = null;
            String event = "";

            Map<String, String> transitionsMap = Extractors
                    .on(nodeString)
                    .extract(
                            "from",
                            xpath(
                                    props.getProperty("ProcessDefinition.group.transition.from"))
                                    .removeNamespace())
                    .extract(
                            "to",
                            xpath(
                                    props.getProperty("ProcessDefinition.group.transition.to"))
                                    .removeNamespace()).asMap();
					/*.extract(
							"conditiontype",
							xpath(
									props.getProperty("ProcessDefinition.group.transition.conditionType"))
									.removeNamespace()).asMap();*/

            for (Map.Entry<String, String> t : transitionsMap
                    .entrySet()) {
                String key = t.getKey();
                String value = t.getValue();
                System.out.println(":::::::::::::::Key::" + key + "::value" + value);
                if (t.getKey().equalsIgnoreCase("from")) {
                    event = t.getKey();
                    //Map<String, String> newMap = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
                    //	System.out.println("***********"+processDefinition.getNodesMap());
                    source = (GopNode) processDefinition
                            .getNodesMap().get(value);
                } else if (t.getKey().equalsIgnoreCase("to")) {
                    dest = (GopNode) processDefinition.getNodesMap().get(value);
                }
            }
            source.addTransition(event, dest);
            transition.setSource(source);
            transition.setDestination(dest);
            return transition;
        }
    }

    /*
    *@Manoj 16/01/2017
    * @param ProcessDefinition
    * @param List<Transitions>
    * return ProcessDefinition
    * */
    private static ProcessDefinition addTransitionToProcessDef(ProcessDefinition processDefinition, List<com.dell.dims.Model.Transition> transitions) throws Exception {

        GopNode source = null;
        GopNode dest = null;
        String event = "";
        List<GopNode> listGroupNodes = new ArrayList();

        for (com.dell.dims.Model.Transition transition : transitions) {
            String fromKey = transition.getFromActivity();
            String toKey = transition.getToActivity();

            event = fromKey;
            dest = new GopNode(toKey);

            source = new GopNode(event);
            source.addTransition(event, dest);
            transition.setSource(source);
            transition.setDestination(dest);
            processDefinition.addNode(source);
        }
        return processDefinition;
    }

    /**
     * @param activity
     * @param xls2pojo
     * @author Manoj Mehta
     */
    private static void addActivityEndpoint(Activity activity, EndpointsXlsRenderer xls2pojo) throws Exception {

        InputBinding inputBindings = null;
        Object config = null;
        //endpointActivity.setPath(activity.getPath());
        if (activity.getType().toString().equals(ActivityType.fileRenameActivityType.toString())) {
            //file rename activity
            FileRenameActivity fileRenameActivity = (FileRenameActivity) activity;
            config = new FileRenameActivityConfig().getConfigAttributes(fileRenameActivity);

            //input bindings
            FileRenameActivityInputBinding fRABinding = new FileRenameActivityInputBinding();
            inputBindings = fRABinding.captureInputBindingAttributes(fileRenameActivity);

            //check for sub process
		/*if(inputBindings.isSubprocess())
		{
			System.out.println("subprocess of " +activity.getName()+" Activity ");
		}*/
        } else if (activity.getType().toString().equals(ActivityType.assignActivityType.toString())) {
            //assign activity
            AssignActivity assignActivity = (AssignActivity) activity;
            config = new AssignActivityConfig().getConfigAttributes(assignActivity);

            //input bindings
            AssignActivityInputBinding assignActBinding = new AssignActivityInputBinding();
            //inputBindings=new InputBinding();
            inputBindings = assignActBinding.captureInputBindingAttributes(assignActivity);
        } else if (activity.getType().toString().equalsIgnoreCase(ActivityType.startType.toString())) {
            //start activity
            return;
        } else if (activity.getType().toString().equalsIgnoreCase(ActivityType.endType.toString())) {
            //end activity
            return;
        }
        //com.tibco.plugin.xml.XMLParseActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.xmlParseActivityType.toString())) {
            XmlParseActivity xmlActivity = (XmlParseActivity) activity;
            config = new XmlParseActivityConfig().getConfigAttributes(xmlActivity);

            //input bindings
            XmlParseActivityInputBinding xmlParserBinding = new XmlParseActivityInputBinding();
            //inputBindings=new InputBinding();
            inputBindings = xmlParserBinding.captureInputBindingAttributes(xmlActivity);
        }
        //com.tibco.plugin.file.FileReadActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.fileReadActivityType.toString())) {
            FileReadActivity fileReadActivity = (FileReadActivity) activity;
            config = new FileReadActivityConfig().getConfigAttributes(fileReadActivity);

            //input bindings
            FileReadActivityInputBinding readFileBinding = new FileReadActivityInputBinding();
            //inputBindings=new InputBinding();
            inputBindings = readFileBinding.captureInputBindingAttributes(fileReadActivity);

        }
        //com.tibco.pe.core.SetSharedVariableActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.setSharedVariableActivityType.toString())) {
            SetSharedVariableActivity sharedVariablActivity = (SetSharedVariableActivity) activity;
            config = new SetSharedVariableActivityConfig().getConfigAttributes(sharedVariablActivity);
        }
        //com.tibco.plugin.file.FileWriteActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.fileWriteActivityType.toString())) {
            FileWriteActivity fileWriteActivity = (FileWriteActivity) activity;
            config = new FileWriteActivityConfig().getConfigAttributes(fileWriteActivity);

            //input bindings
            FileWriteActivityInputBinding fWABinding = new FileWriteActivityInputBinding();
            //inputBindings=new InputBinding();
            inputBindings = fWABinding.captureInputBindingAttributes(fileWriteActivity);
        }
        //com.tibco.pe.core.GenerateErrorActivity
        else if (activity.getType().toString().equalsIgnoreCase((ActivityType.generateErrorActivity).toString())) {
            config = new GenerateErrorActivityConfig().getConfigAttributes((GenerateErrorActivity) activity);
            GenerateErrorActivity errorActivity = (GenerateErrorActivity) activity;
            config = new GenerateErrorActivityConfig().getConfigAttributes(errorActivity);

            //input bindings
            GenerateErrorActivityInputBinding errorActBinding = new GenerateErrorActivityInputBinding();
            //inputBindings=new InputBinding();
            inputBindings = errorActBinding.captureInputBindingAttributes(errorActivity);
        }
        //com.tibco.pe.core.CallProcessActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.callProcessActivityType.toString())) {
            CallProcessActivity callProcessActivity = (CallProcessActivity) activity;
            config = new CallProcessActivityConfig().getConfigAttributes(callProcessActivity);

            //input bindings
            CallProcessActivityInputBinding callProcBinding = new CallProcessActivityInputBinding();
            inputBindings = callProcBinding.captureInputBindingAttributes(callProcessActivity);

            // if Logger Activity is present
            if (inputBindings.getAttributesList().containsKey("LoggingService")) {
                LoggerService logService = (LoggerService) inputBindings.getAttributesList().get("LoggingService");

                LoggerService.LogBody logBody = logService.getLogBody();
                LoggerService.LogHeader logHeader = logService.getLogHeader();

                System.out.println("ApplicationName :" + logHeader.getApplicationName() + "\n From: " + logHeader.getFrom() + "\n LogType:" + logHeader.getLogType() + "\n Process Name :" + logHeader.getProcessName());
                System.out.println("Payload :" + logBody.getPayload() + "\n PayloadType" + logBody.getPayloadType());
            }

            //check for sub process
            if (inputBindings.isSubprocess()) {
                System.out.println("subprocess of " + activity.getName() + " Activity ==> " + ((CallProcessActivityConfig) config).getProcessName());
            }
        }
        //com.tibco.plugin.file.FileCopyActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.fileCopyActivityType.toString())) {
            FileCopyActivity fileCopyActivity = (FileCopyActivity) activity;
            config = new FileCopyActivityConfig().getConfigAttributes(fileCopyActivity);

            //input bindings
            FileCopyActivityInputBinding fCopyBinding = new FileCopyActivityInputBinding();
            inputBindings = fCopyBinding.captureInputBindingAttributes(fileCopyActivity);
        }
        //com.tibco.plugin.timer.NullActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.nullActivityType.toString())) {
            //No config props
        }
        //com.tibco.pe.core.LoopGroup
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.loopGroupActivityType.toString())) {
            // handles in group itself
            return;
        }
        //com.tibco.plugin.timer.SleepActivity
        else if (activity.getType().toString().equalsIgnoreCase(sleepActivity.toString())) {
            SleepActivity sleepActivity = (SleepActivity) activity;
            config = new SleepActivityConfig().getConfigAttributes(sleepActivity);

            //input bindings
            SleepActivityInputBinding sleepInputBinding = new SleepActivityInputBinding();
            inputBindings = sleepInputBinding.captureInputBindingAttributes(sleepActivity);
        }
        //com.tibco.plugin.mapper.MapperActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.mapperActivityType.toString())) {
            MapperActivity mapperActivity = (MapperActivity) activity;
            config = new MapperActivityConfig().getConfigAttributes(mapperActivity);

            //input bindings
            MapperActivityInputBinding mapperInputBinding = new MapperActivityInputBinding();
            inputBindings = mapperInputBinding.captureInputBindingAttributes(mapperActivity);

		/*
        <config><element>
                <xsd:element name="transaction-file" type="pfx:transaction-file"/>
        </element>  </config>
        <pd:inputBindings>
            <transaction-file>
                <file>
                    <xsl:attribute name="name">
		 */

        }
        //com.tibco.plugin.jdbc.c
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.jdbcUpdateActivityType.toString())) {
            JdbcUpdateActivity jdbcUpdateActivity = (JdbcUpdateActivity) activity;
            config = new JdbcUpdateActivityConfig().getConfigAttributes(jdbcUpdateActivity);

            //input bindings
            JDBCUpdateActivityInputBinding jdbcUpdateInputBinding = new JDBCUpdateActivityInputBinding();
            inputBindings = jdbcUpdateInputBinding.captureInputBindingAttributes(jdbcUpdateActivity);
        } else if (activity.getType().toString().equalsIgnoreCase(ActivityType.jdbcQueryActivityType.toString())) {
            JdbcQueryActivity jdbcQueryActivity = (JdbcQueryActivity) activity;
            config = new JdbcQueryActivityConfig().getConfigAttributes(jdbcQueryActivity);
            //input bindings
            JdbcQueryActivityInputBinding jdbcQueryInputBinding = new JdbcQueryActivityInputBinding();
            inputBindings = jdbcQueryInputBinding.captureInputBindingAttributes(jdbcQueryActivity);
        } else if (activity.getType().toString().equalsIgnoreCase(ActivityType.fileRemoveActivityType.toString())) {
            //no config for this activity
            FileRemoveActivity fileRemoveActivity = (FileRemoveActivity) activity;
            //input bindings
            FileRemoveActivityInputBinding fileRemove = new FileRemoveActivityInputBinding();
            inputBindings = fileRemove.captureInputBindingAttributes(fileRemoveActivity);

            //check for sub process
            if (inputBindings.isSubprocess()) {
                System.out.println("subprocess of " + activity.getName() + " Activity exists");
            }
        }

        //JavaActivity
        else if (activity.getType().toString().equalsIgnoreCase(ActivityType.javaActivityType.toString())) {
            //
            JavaActivity javaActivity = (JavaActivity) activity;
            config = new JavaActivityConfig();
            config = new JavaActivityConfig().getConfigAttributes(javaActivity);

            //input bindings
            JavaActivityInputBinding javaActivityBinding = new JavaActivityInputBinding();
            inputBindings = javaActivityBinding.captureInputBindingAttributes(javaActivity);
            //check for sub process
            if (inputBindings.isSubprocess()) {
                System.out.println("subprocess of " + activity.getName() + " Activity ==> ");
            }

        } else if (activity.getType().toString().equalsIgnoreCase(ActivityType.rvPubActivityType.toString())) {
            RVPubActivity rvpubActivity = (RVPubActivity) activity;
            config = new RVPubActivityConfig().getConfigAttributes(rvpubActivity);

            //input bindings
            RVPubActivityInputBinding rvpBinding = new RVPubActivityInputBinding();
            inputBindings = rvpBinding.captureInputBindingAttributes(rvpubActivity);
        } else if (activity.getType().toString().equalsIgnoreCase(ActivityType.getSharedVariableActivityType.toString())) {
            GetSharedVariableActivity sharedVarActivity = (GetSharedVariableActivity) activity;
            config = new GetSharedVariableActivityConfig().getConfigAttributes(sharedVarActivity);

            //inputbindings
            GetSharedVariableActivityInputBinding sharedVarBinding = new GetSharedVariableActivityInputBinding();
            inputBindings = sharedVarBinding.captureInputBindingAttributes(sharedVarActivity);
        } else {
            System.out.println(" @ DimsServiceImpl.java  ############################### NOT YET HANDLED FOR  :: " + activity.getType() + " ############################");
            return;
        }

        //capture endpoint detals from IinputBinding object
        if (inputBindings != null) {
            if (inputBindings.getAttributesList() != null && inputBindings.getAttributesList().size() > 0) {
                System.out.println("\n*********Activity Name :::" + inputBindings.getActivityName() + " ::: *************");
                for (Map.Entry<String, Object> endPoint : inputBindings.getAttributesList().entrySet()) {
                    DefaultEndpoint endpointActivity = new DefaultEndpoint();
                    System.out.println("\n Key : " + endPoint.getKey() + " \n Value : " + endPoint.getValue());
                    endpointActivity.setEndPointName(endPoint.getKey());
                    endpointActivity.setPath(endPoint.getValue().toString());
                    endpointActivity.setScheme(inputBindings.getSchemeName());

                    if (config != null) {
                        endpointActivity.createUriParams(config);
                    }
                    xls2pojo.getEndpoints().add(endpointActivity);
                }
            }
            if (inputBindings.getEndPointOptions() != null && inputBindings.getEndPointOptions().size() > 0) {
                for (Map.Entry<String, Object> options : inputBindings.getEndPointOptions().entrySet()) {
                    System.out.println("\n Endpoint options : " + options.getKey() + ":::" + options.getValue());
                }
            }
            System.out.println(" SCHEME : " + inputBindings.getSchemeName());
            //	System.out.println("endpointActivity.getPath :" + endpointActivity.getPath());
        }

   /* if(config==null)
		return;

	endpointActivity.createUriParams(config);
	xls2pojo.getEndpoints().add(endpointActivity);*/
    }


    private static StringBuffer getEndpointContextPath(Activity activity) {
        // CONTEXT PATH , fetch from inputbinding parameters
        //checkInputBinding()
        List<ClassParameter> paramList = activity.getParameters();
        StringBuffer contextPath = new StringBuffer("");
        if (paramList.size() > 0) {
            for (ClassParameter classParam : paramList) {

                if (classParam.getChildProperties() == null) {
                    System.out.println("Name : " + classParam.getName());
                    System.out.println("Type : " + classParam.getType());
                    System.out.println("Default value : " + classParam.getDefaultValue());
                    System.out.println("Special option" + classParam.getSpecialOption());
                    contextPath.append(classParam.getDefaultValue());
                } else {
                    contextPath = new StringBuffer(classParam.getName() + "__");// parent node
                    contextPath = processChildParameters(classParam, contextPath);
                    System.out.println("*****************************value :::::=========  " + contextPath);
                }
            }
        }
        return contextPath;
    }

    public static ProcessDefinition processTibcoFiles(String fileString) {

        ProcessDefinition processDefinition = null;
        // Pass file to be processed to main parser
        try {
            TibcoBWProcessLinqParser processParser = new TibcoBWProcessLinqParser();
            TibcoBWProcessLinqParser.props = props;
            TibcoBWProcess tibcoBWProcess = processParser.parse(fileString);
        //    System.out.println("************TibcoBWProcess Deatils***********\n " + tibcoBWProcess);

            // Now populate ProcessDefinition object with tibcoBWProcess attributes

            processDefinition = new ProcessDefinition(tibcoBWProcess.getProcessName());//Process Name
            // Start GopNode
            if (tibcoBWProcess.getStartActivity() != null) {
                StartGopNode startNode = new StartGopNode(tibcoBWProcess.getStartActivity().getName());
                processDefinition.setStartState(startNode);
                processDefinition.setStartActivity(tibcoBWProcess.getStartActivity());
            }

            // added to handle starter
            else if (tibcoBWProcess.getStarterActivity() != null) {
                StartGopNode starterNode = new StartGopNode(tibcoBWProcess.getStarterActivity().getName());
                processDefinition.setStartState(starterNode);
            }
            //processDefinition.addNode(startNode);

            // End node
            if (tibcoBWProcess.getEndActivity() != null) {
                EndGopNode endNode = new EndGopNode(tibcoBWProcess.getEndActivity().getName());
                processDefinition.setEndState(endNode);
                processDefinition.setEndActivity(tibcoBWProcess.getEndActivity());
            }
            //processDefinition.addNode(endNode);

            // Add activity
            List<Activity> listActivities = tibcoBWProcess.getActivities();
            for (Activity activity : listActivities) {
                // for Group Activity simple add it and its transition will be fetched later
                processDefinition.addNode(activity);
            }
            // Add Transition for Activities outside group
            List<com.dell.dims.Model.Transition> transations = tibcoBWProcess.getTransitions();
            addTransitionToProcessDef(processDefinition, transations);

            //add return bindings
            if (tibcoBWProcess.getReturnBindingNode() != null) {
                processDefinition.setReturnBinding(tibcoBWProcess.getReturnBindingNode());
            }

            //Capture Start input arrtibutes
            if(tibcoBWProcess.getStartActivity()!=null)
            {
                processDefinition.setStartActivity(tibcoBWProcess.getStartActivity());
            }
            //Capture End output arrtibutes
            if(tibcoBWProcess.getEndActivity()!=null)
            {
                processDefinition.setEndActivity(tibcoBWProcess.getEndActivity());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return processDefinition;
    }

    /**
     * Created By Manoj Mehta
     *
     * @param param
     */
    static StringBuffer processChildParameters(ClassParameter param, StringBuffer value) {
        if (param.getChildProperties().size() > 0) {
            for (ClassParameter childParam : param.getChildProperties()) {
                if (childParam.getChildProperties() == null) {
                    System.out.println(" Parent Name : " + param.getName());
                    System.out.println(" childParam Name : " + childParam.getName());
                    System.out.println("Type : " + childParam.getType());
                    System.out.println("Default value : " + childParam.getDefaultValue());
                    System.out.println("Special option" + childParam.getSpecialOption());
                    if (childParam.getDefaultValue() != null && childParam.getDefaultValue().length() > 0) {
                        value.append(param.getName() + "__" + childParam.getDefaultValue() + "\n");
                    }
                } else {
                    processChildParameters(childParam, value);
                    //	System.out.println("****************More NESTING Required *********************");
                }
            }
        }
        return value;
    }

    /*Write the Artifacts to files
     */
    public void writeToFile(String content, String dirPath,String fileName) {

        //check directory exists
        File directory = new File(dirPath);
        if (! directory.exists()){
        //    directory.mkdir();
            directory.mkdirs();
            // If you require it to make the entire directory path including parents,
            // use directory.mkdirs(); here instead.
        }

        String filePath=dirPath+"//"+fileName;

        File file = new File(filePath);
        try (FileOutputStream fop = new FileOutputStream(file)) {

            // if file doesn't exists, then create it
            if (!file.exists()) {
                file.createNewFile();
            }

            // get the content in bytes
            byte[] contentInBytes = content.getBytes();

            fop.write(contentInBytes);
            fop.flush();
            fop.close();

        //    System.out.println("File Creation Completed Successfully for :" + fileName);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*private void createDirectories(String output_project_path)
    {
        //create SOA Dir
        sd
    }*/
}
