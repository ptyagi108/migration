//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.AdapterSubscriberActivity;
import com.dell.dims.ModelConfig.AdapterSubscriberActivityConfig;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import im.nll.data.extractor.impl.SelectorExtractor;
import org.w3c.dom.Node;

import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class AdapterSubscriberActivityParser implements IActivityParser
{
    public static final String AeSubscriberPropertyPrefix = "ae.aepalette.SharedProperties.";


    public Activity parse(String inputElement) throws Exception {

        AdapterSubscriberActivity activity = new AdapterSubscriberActivity();

        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();

        activity.setName(activityMap.get("name"));
        activity.setType(new ActivityType(activityMap.get("type")));

      /*
        activity.setName(inputElement.Attribute("name").Value);
        activity.setType((ActivityType)inputElement.Element(XmlnsConstant.tibcoProcessNameSpace + "type").Value);*/

        /* [UNSUPPORTED] 'var' as type is unsupported "var" */



       /* configElement = inputElement.Element("config");*/


        AdapterSubscriberActivityConfig config = Extractors.on(inputElement)
                .extract("config", extractBean(new AdapterSubscriberActivityConfig()))
                .asBean(AdapterSubscriberActivityConfig.class);

        activity.setTpPluginEndpointName(config.getTpPluginEndpointName());
        activity.setUseRequestReply(config.isUseRequestReply());
        activity.setTransportChoice(config.getTransportChoice());
        activity.setAdapterService(config.getAdapterService());
        activity.setTransportType(config.getTransportType());
        activity.setRvSubject(config.getRvSubject());
        activity.setRvSessionService(config.getRvSessionService());
        activity.setRvSessionNetwork(config.getRvSessionNetwork());
        activity.setRvSessionDaemon(config.getRvSessionDaemon());
        activity.setMessageFormat(config.getMessageFormat());
        activity.setRvCmSessionDefaultTimeLimit(config.getRvCmSessionDefaultTimeLimit());
        activity.setRvCmSessionSyncLedger(config.isRvCmSessionSyncLedger());
        activity.setRvCmSessionLedgerFile(config.getRvCmSessionLedgerFile());
        activity.setRvCmSessionName(config.getRvCmSessionName());
        activity.setRvCmSessionRelayAgent(config.getRvCmSessionRelayAgent());
        activity.setRvCmSessionRequireOldMessages(config.isRvCmSessionRequireOldMessages());



        /*activity.setTpPluginEndpointName(XElementParserUtils.GetStringValue(configElement.Element("tpPluginEndpointName")));
        activity.setUseRequestReply(XElementParserUtils.GetBoolValue(configElement.Element(AeSubscriberPropertyPrefix + "useRequestReply")));
        activity.setTransportChoice(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "transportChoice")));
        activity.setAdapterService(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "adapterService")));
        activity.setTransportType(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "transportType")));
        activity.setRvSubject(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "rvSubject")));
        activity.setRvSessionService(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "rvSessionService")));
        activity.setRvSessionNetwork(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "rvSessionNetwork")));
        activity.setRvSessionDaemon(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "rvSessionDaemon")));
        activity.setMessageFormat(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "msgFormat")));
        activity.setRvCmSessionDefaultTimeLimit(XElementParserUtils.GetIntValue(configElement.Element(AeSubscriberPropertyPrefix + "rvCmSessionDefaultTimeLimit")));
        activity.setRvCmSessionSyncLedger(XElementParserUtils.GetBoolValue(configElement.Element(AeSubscriberPropertyPrefix + "rvCmSessionSyncLedger")));
        activity.setRvCmSessionLedgerFile(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "rvCmSessionLedgerFile")));
        activity.setRvCmSessionName(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "rvCmSessionName")));
        activity.setRvCmSessionRelayAgent(XElementParserUtils.GetStringValue(configElement.Element(AeSubscriberPropertyPrefix + "rvCmSessionRelayAgent")));
        activity.setRvCmSessionRequireOldMessages(XElementParserUtils.GetBoolValue(configElement.Element(AeSubscriberPropertyPrefix + "rvCmSessionRequireOldMessages")));*/
        /* [UNSUPPORTED] 'var' as type is unsupported "var" */

        //outputSchemaElement = configElement.Element(AeSubscriberPropertyPrefix + "outputMeta");
        String outputSchemaElement=config.getOutputMeta();
        if (outputSchemaElement != null)
        {
            String outputSchema = Extractors.on(outputSchemaElement)
                    .extract(new SelectorExtractor("aeMeta"))
                    .asString();

            activity.setOutputSchema(outputSchema);
            //activity.setOutputSchemaQname(XElementParserUtils.GetStringValue(outputSchemaElement.Element("aeMeta")));
        }

        return activity;
    }

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        return null;
    }
}


