//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.RdvEventSourceActivity;
import com.dell.dims.ModelConfig.RdvActivityConfig;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class RdvEventSourceActivityParser implements IActivityParser
{
    public Activity parse(String inputElement) throws Exception {
        RdvEventSourceActivity activity = new RdvEventSourceActivity();


        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();

        activity.setName(activityMap.get("name"));
        activity.setType(new ActivityType(activityMap.get("type")));


        /*activity.setName(inputElement.Attribute("name").Value);
        activity.setType((ActivityType)inputElement.Element(XmlnsConstant.tibcoProcessNameSpace + "type").Value);*/



        /* [UNSUPPORTED] 'var' as type is unsupported "var" */

        /*configElement = inputElement.Element("config");
        activity.setSubject(XElementParserUtils.GetStringValue(configElement.Element("subject")));
        activity.setSharedChannel(XElementParserUtils.GetStringValue(configElement.Element("sharedChannel")));*/


        RdvActivityConfig config = Extractors.on(inputElement)
                .extract("config", extractBean(new RdvActivityConfig()))
                .asBean(RdvActivityConfig.class);

        activity.setSubject(config.getSubject());
        activity.setSharedChannel(config.getSharedChannel());

        //TODO manage REF or XSD : is it really used ? Let's do something dirty and assume it's always a string name message
        /*if (configElement.Element ("XsdString").Attribute ("ref") != null) {
        				activity.XsdStringReference = configElement.Element("XsdString").Attribute("ref").ToString();
        			}
        			else
        			{
        				activity.ObjectXNodes = configElement.Element("XsdString").Nodes();
        				var activityParameters = new XsdParser().Parse (configElement.Element("XsdString").Nodes(), string.Empty);
        				activity.Parameters = activityParameters;
        			}*/
        /*activity.setParameters(new List<ClassParameter> { new ClassParameter() });*/

       /* List<ClassParameter> list = new ArrayList<>();*/


        return activity;
    }

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        return null;
    }
}


