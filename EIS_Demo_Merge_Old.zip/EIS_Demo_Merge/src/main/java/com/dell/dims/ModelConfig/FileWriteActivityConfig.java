package com.dell.dims.ModelConfig;

import com.dell.dims.Model.*;
import com.dell.dims.Router.RoutingRulesDefinition;

import java.util.List;

/**
 * Created by Manoj Mehta
 */
public class FileWriteActivityConfig {

    private String encoding;
    private String compressFile;
    private boolean createMissingDirectories;
    private boolean append;

    public boolean isAppend() {
        return append;
    }

    public void setAppend(boolean append) {
        this.append = append;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public String getCompressFile() {
        return compressFile;
    }

    public void setCompressFile(String compressFile) {
        this.compressFile = compressFile;
    }

    public boolean isCreateMissingDirectories() {
        return createMissingDirectories;
    }

    public void setCreateMissingDirectories(boolean createMissingDirectories) {
        this.createMissingDirectories = createMissingDirectories;
    }

    public Object getConfigAttributes(FileWriteActivity activity) throws Exception {
        this.setEncoding(activity.getEncoding());
        this.setCompressFile(activity.getCompressFile());
        this.setCreateMissingDirectories(activity.isCreateMissingDirectories());
        this.setAppend(activity.isAppend());
        return this;
    }
}
