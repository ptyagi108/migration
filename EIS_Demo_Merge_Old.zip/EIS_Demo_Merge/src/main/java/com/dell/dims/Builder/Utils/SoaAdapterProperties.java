package com.dell.dims.Builder.Utils;

/**
 * Created by Kriti_Kanodia on 6/8/2017.
 */
public class SoaAdapterProperties {

    private String interactionSpec;
    private String operation;
    private String property;
    private String rootName;




}
