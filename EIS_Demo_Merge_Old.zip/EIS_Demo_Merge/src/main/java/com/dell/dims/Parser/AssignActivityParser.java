//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.AssignActivity;
import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.ModelConfig.AssignActivityConfig;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class AssignActivityParser implements IActivityParser {

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        AssignActivity assignActivity = new AssignActivity();

        String nodeStr = NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap = null;

        if (isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .extract("variableName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.variableName")))
                    .asMap();
        } else {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("variableName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.variableName")))
                    .asMap();
        }

        assignActivity.setName(activityMap.get("name"));
        assignActivity.setType(new ActivityType(activityMap.get("type")));
        assignActivity.setResourceType(activityMap.get("resourceType"));
        assignActivity.setVariableName(activityMap.get("variableName"));
        assignActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,assignActivity);
        assignActivity.setInputBindings(activity.getInputBindings());
        assignActivity.setParameters(activity.getParameters());

        return assignActivity;
    }
}

/*
 "<pd:activity name=\"Assign Strat\" xmlns:pd=\"http://xmlns.tibco.com/bw/process/2003\" xmlns:xsl=\"http://w3.org/1999/XSL/Transform\">\n" +
        "<pd:type>com.tibco.pe.core.AssignActivity</pd:type>\n" +
                "<config>\n" +
                "    <variableName>var</variableName>\n" +
                "</config>\n" +
                "<pd:inputBindings>\n" +
                "    <sqlParams>\n" +
                "        <FundName>\n" +
                "            <xsl:value-of select=\"testvalue\"/>\n" +
                "        </FundName>\n" +
                "        <AdminID>\n" +
                "            <xsl:value-of select=\"EVL\"/>\n" +
                "        </AdminID>\n" +
                "    </sqlParams>\n" +
                "</pd:inputBindings>\n" +
                "</pd:activity>";
 */


