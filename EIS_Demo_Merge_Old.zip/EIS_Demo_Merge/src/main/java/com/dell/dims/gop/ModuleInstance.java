
package com.dell.dims.gop;

import java.io.Serializable;


public class ModuleInstance implements Serializable {

    private static final long serialVersionUID = 1L;

    long id = 0;
    int version = 0;
    protected ProcessInstance processInstance = null;

    public ModuleInstance() {
    }


    // getters and setters //////////////////////////////////////////////////////

    public long getId() {
        return id;
    }

    public ProcessInstance getProcessInstance() {
        return processInstance;
    }

    public void setProcessInstance(ProcessInstance processInstance) {
        this.processInstance = processInstance;
    }
}
