//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.AdapterSchemaModel;

public class AdapterSchemaParser
{
    public AdapterSchemaModel parse(String fileName) throws Exception {
        return new AdapterSchemaModel();
    }

}


// TODO
