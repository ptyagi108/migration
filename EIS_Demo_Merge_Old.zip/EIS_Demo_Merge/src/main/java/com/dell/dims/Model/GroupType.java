//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Model;


public enum GroupType
{
    INPUTLOOP,
    SIMPLEGROUP,
    REPEAT,
    CRITICALSECTION,
    WHILE,
    ERRORLOOP
}

