package com.dell.dims.ModelConfig;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.SleepActivity;

public class SleepActivityConfig
{
    private int timerDuration;
    public int getTimerDuration() {
        return timerDuration;
    }

    public void setTimerDuration(int value) {
        timerDuration = value;
    }

    public Object getConfigAttributes(SleepActivity activity) throws Exception {
        this.setTimerDuration(activity.getTimerDuration());
        return this;
    }


}


