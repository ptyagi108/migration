package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 2/27/2017.
 */
public class AssignActivityInputBinding extends InputBinding
{
    @Override
    public InputBinding captureInputBindingAttributes(Activity activity)
    {
        InputBinding inputBindings=new InputBinding();
        Map<String,Object> mapAttributesList= new HashMap<String,Object>();
        String endPointName="";
        StringBuffer endPointValue;

        // check if current process is subprocess
        if(activity.getResourceType().toUpperCase().contains(".subprocess".toUpperCase()))
        {
            System.out.println("\n*****Subprocess EXIST for*****"+activity.getName() + " Process");
            inputBindings.setSubprocess(true);
        }

        List<ClassParameter> paramList = activity.getParameters();
        String attribute="";
        StringBuilder attributeVal=null;
        if (paramList.size() > 0)
        {
            for (ClassParameter classParam : paramList)
            {
                //check for Success
                attribute="Success";
                attributeVal=captureAttributeValue(classParam,attribute);
                if(attributeVal!=null && attributeVal.length()>0)
                {
                    mapAttributesList.put(attribute,attributeVal.toString());
                }

                //check for responseFilename
                attribute="responseFilename";
                attributeVal=captureAttributeValue(classParam,attribute);
                if(attributeVal!=null && attributeVal.length()>0)
                {
                    mapAttributesList.put(attribute,attributeVal.toString());
                }

                //responseLocation
                attribute="responseLocation";
                attributeVal=captureAttributeValue(classParam,attribute);
                if(attributeVal!=null && attributeVal.length()>0)
                {
                    mapAttributesList.put(attribute,attributeVal.toString());
                }

                //variable
                //since variables are multiple so need to capture them all as a list.
                if(classParam.getChildProperties()!=null)
                {
                    List variableList = new ArrayList();
                    for(ClassParameter param : classParam.getChildProperties())
                    {
                        if(param.getName().equalsIgnoreCase("variable"))
                        {
                            variableList.add(param.getDefaultValue());
                        }
                    }
                    mapAttributesList.put("variable",variableList);
                }
            }
        }
        inputBindings.setSchemeName("=");
        inputBindings.setActivityName(activity.getName());
        inputBindings.setActivityType(activity.getType().toString());
      //  inputBindings.setEndPointOptions(mapAttributesList);
        inputBindings.setAttributesList(mapAttributesList);

        return inputBindings;
    }
}
