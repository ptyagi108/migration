package com.dell.dims.gop;

/**
 * @author pramod
 */
public interface Action {
    public String getName();

    public void execute(Token token);
}
