package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;
import com.dell.dims.ModelInputBindings.Logging.LoggerService;
import com.dell.dims.Router.RoutingRulesDefinition;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 2/7/2017.
 */
public class CallProcessActivityInputBinding extends InputBinding {

    private RoutingRulesDefinition routeRuleDef= new RoutingRulesDefinition();

    @Override
    public InputBinding captureInputBindingAttributes(Activity activity) {
        InputBinding inputBindings=new InputBinding();
        Map<String,Object> mapAttributesList= new HashMap<String,Object>();
        String attribute="";
        StringBuilder attributeValue=null;

        // check if current process is subprocess
        if(activity.getResourceType().toUpperCase().contains(".subprocess".toUpperCase()))
        {
            System.out.println("\n*****Subprocess EXIST for*****"+activity.getName() + " Process");
            inputBindings.setSubprocess(true);
        }

        List<ClassParameter> paramList = activity.getParameters();

            if (paramList.size() > 0)
            {
                for (ClassParameter classParam : paramList) {

                    //check for fromFile
                    attribute="fromFile";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor toFileName
                    attribute="toFileName";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor toFolder
                    attribute="toFolder";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor renameFile
                    attribute="renameFile";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor archive
                    attribute="archive";
                    attributeValue=captureAttributeValue( classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor CopytoXE
                    attribute="CopytoXE";
                    attributeValue=captureAttributeValue( classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor TxnID
                    attribute="TxnID";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor OFN
                    attribute="OFN";
                    attributeValue=captureAttributeValue( classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor TrxType
                    attribute="TrxType";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor Channel
                    attribute="Channel";
                    attributeValue=captureAttributeValue( classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //CheckFor fileType
                    attribute="fileType";
                    attributeValue=captureAttributeValue( classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //AccessId
                    attribute="AccessId";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //inboundFTA PROCESS
                    //CheckFor TrackingID
                    attribute="TrackingID";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //fullName
                    attribute="fullName";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //sourcefileName
                    attribute="sourcefileName";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //requestFilelocation
                    attribute="requestFilelocation";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //path
                    attribute="path";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //name
                    attribute="name";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //fileSize
                    attribute="fileSize";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //rootPath
                    attribute="rootPath";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //fileExtensions
                    attribute="fileExtensions";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    //destination
                    attribute="fileExtensions";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeValue.toString());
                    }

                    // Logger
                    attribute="LoggingService";
                    attributeValue=captureAttributeValue(classParam,attribute);
                    if(attributeValue!=null && attributeValue.length()>0)
                    {
                        // get LogHeader and LogBody attributes
                        if(classParam.getChildProperties().size()>0)
                        {
                            LoggerService logService=new LoggerService();
                            LoggerService.LogHeader logHeader= logService.new LogHeader();
                            LoggerService.LogBody   logBody= logService.new LogBody();
                            for(int i=0;i<classParam.getChildProperties().size();i++)
                            {
                               ClassParameter childParam=classParam.getChildProperties().get(i);
                                //LogHeader
                                if(childParam!=null && childParam.getName()!=null && childParam.getName().equalsIgnoreCase("LogHeader"))
                                {
                                    //applicationName
                                    logHeader.setApplicationName(captureAttributeValue(childParam,"ApplicationName").toString());

                                     //processName;
                                    logHeader.setProcessName(captureAttributeValue(childParam,"ProcessName").toString());

                                    //from;
                                    logHeader.setFrom(captureAttributeValue(childParam,"From").toString());

                                    //logType;
                                    logHeader.setLogType(captureAttributeValue(childParam,"LogType").toString());

                                }

                                else if(childParam!=null && childParam.getName()!=null && childParam.getName().equalsIgnoreCase("LogBody"))
                                {
                                    logBody.setPayload(captureAttributeValue(childParam,"Payload").toString());
                                    logBody.setPayloadType(captureAttributeValue(childParam,"PayloadType").toString());
                                }
                            }
                            //set log body & header
                            logService.setLogHeader(logHeader);
                            logService.setLogBody(logBody);
                            mapAttributesList.put(attribute,logService);
                        }
                    }
                }
            }
            inputBindings.setSchemeName("FILE");
            inputBindings.setActivityName(activity.getName());
            inputBindings.setActivityType(activity.getType().toString());
            inputBindings.setAttributesList(mapAttributesList);

            return inputBindings;
        }
}
