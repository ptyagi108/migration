package com.dell.dims.Model;

public class TbwConfiguration
{
    private String repoInstanceName;
    private TbwServiceConfig servicesConfig;
    private String name;

    public String getRepoInstanceName() {
        return repoInstanceName;
    }

    public void setRepoInstanceName(String repoInstanceName) {
        this.repoInstanceName = repoInstanceName;
    }

    public TbwServiceConfig getServicesConfig() {
        return servicesConfig;
    }

    public void setServicesConfig(TbwServiceConfig servicesConfig) {
        this.servicesConfig = servicesConfig;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}


