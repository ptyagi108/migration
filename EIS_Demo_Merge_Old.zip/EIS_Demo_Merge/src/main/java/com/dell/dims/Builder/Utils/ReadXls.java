package com.dell.dims.Builder.Utils;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by Kriti_Kanodia on 6/8/2017.
 */
public class ReadXls {

    private static InputStream is;
    private static final String INPUT_FILE = "./Tibco2OracleSOAMappings_1.0.xlsx";


    public static Map<List<TibcoAdapterProperties>,List<SoaAdapterProperties>> readExcelSheet(String excelFilePath) throws IOException {

        is = new FileInputStream(new File(INPUT_FILE));

        XSSFWorkbook workbook = new XSSFWorkbook(is);
        XSSFSheet sheet = workbook.getSheet("Properties Mapping  Tibco2SOA");

        Iterator<Row> iterator = sheet.iterator();


        List<TibcoAdapterProperties> tibcoAttributes = new ArrayList<>();
        List<SoaAdapterProperties> soaAttributes = new ArrayList<>();

        while (iterator.hasNext()) {

            Row nextRow = iterator.next();
            TibcoAdapterProperties tibcoAdapterProperties = new TibcoAdapterProperties();
            SoaAdapterProperties soaAdapterProperties = new SoaAdapterProperties();

            if (nextRow.getRowNum() >= 2 && nextRow.getRowNum()<= sheet.getLastRowNum()) {

                Iterator<Cell> cellIterator = nextRow.cellIterator();


                while (cellIterator.hasNext()) {
                    Cell nextCell = cellIterator.next();
                    int columnIndex = nextCell.getColumnIndex();


                    switch (columnIndex) {
                        case 0:
                            tibcoAdapterProperties.setActivityType((String) getCellValue(nextCell));
                            break;
                        case 1:
                            tibcoAdapterProperties.setRootName((String) getCellValue(nextCell));
                            break;
                        case 2:
                            tibcoAdapterProperties.setProperty((String)getCellValue(nextCell));
                            break;
                        case 3:
                            tibcoAdapterProperties.setType((String) getCellValue(nextCell));
                            break;
                        case 4:
                            soaAdapterProperties.setActivityType((String) getCellValue(nextCell));
                            break;
                        case 5:
                            soaAdapterProperties.setRootnames((String) getCellValue(nextCell));
                            break;
                        case 6:
                            soaAdapterProperties.setProperty((String) getCellValue(nextCell));
                            break;
                        case 7:
                            soaAdapterProperties.setType((String) getCellValue(nextCell));
                            break;
                    }
                }


                tibcoAttributes.add(tibcoAdapterProperties);
                soaAttributes.add(soaAdapterProperties);




               // tibco_rootName.put(readxls.getTibcoRootName(),tibco_propertyAndType);

                //readxls.setTibco_rootName();
                //   tibco_activityType_rootNames.add(readxls);

            }
        }
        Map<List<TibcoAdapterProperties>,List<SoaAdapterProperties>> attributes = new HashMap<>();
        attributes.put(tibcoAttributes,soaAttributes);

        is.close();
        workbook.close();
        return attributes;
    }


    private static Object getCellValue(Cell cell) {
        switch (cell.getCellType()) {
            case Cell.CELL_TYPE_STRING:
                return cell.getStringCellValue();
        }
        return null;
    }
}
