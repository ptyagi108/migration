//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;

//import com.dell.dims.EaiConvertor.com.dell.dims.Builder.ModuleBuilder;
//import com.dell.dims.EaiConvertor.com.dell.dims.Builder.ServiceManagerInterfaceBuilder;
//import com.dell.dims.EaiConvertor.CodeGenerator.ISourceCodeGeneratorService;

public class PostProcessor
{
  /*  private ISourceCodeGeneratorService sourceCodeGeneratorService;
    private ModuleBuilder moduleBuilder;
    private ServiceManagerInterfaceBuilder interfaceBuilder;
    public PostProcessor(ISourceCodeGeneratorService sourceCodeGeneratorService) throws Exception {
        this.sourceCodeGeneratorService = sourceCodeGeneratorService;
        this.moduleBuilder = new ModuleBuilder();
        this.interfaceBuilder = new ServiceManagerInterfaceBuilder();
    }

    public void process() throws Exception {
        /* [UNSUPPORTED] 'var' as type is unsupported "var" */

  /* targetUnit = new CodeCompileUnit();
        targetUnit.Namespaces.Add(this.moduleBuilder.build());
        targetUnit.Namespaces.Add(this.interfaceBuilder.build());
        this.sourceCodeGeneratorService.Generate(targetUnit);
    }
*/
}


