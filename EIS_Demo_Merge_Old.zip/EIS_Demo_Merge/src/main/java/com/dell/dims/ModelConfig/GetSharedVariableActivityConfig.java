package com.dell.dims.ModelConfig;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.GenerateErrorActivity;
import com.dell.dims.Model.GetSharedVariableActivity;

/**
 * Created by Manoj_Mehta on 2/24/2017.
 */
public class GetSharedVariableActivityConfig extends Activity
{

    public GetSharedVariableActivityConfig(String name, ActivityType type) {
        super(name, type);
    }


    public GetSharedVariableActivityConfig() throws Exception {
        super();
    }

    private String variableConfig;

    public String getVariableConfig() {
        return variableConfig;
    }

    public void setVariableConfig(String variableConfig) {
        this.variableConfig = variableConfig;
    }

    public Object getConfigAttributes(GetSharedVariableActivity activity) throws Exception {
        this.setVariableConfig(activity.getVariableConfig());

        return this;
    }
}
