package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileReadActivity;
import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

/**
 * Created by Kriti_Kanodia on 1/20/2017.
 */
public class FileReadActivityParser implements IActivityParser {

    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        FileReadActivity readActivity = new FileReadActivity();

        String nodeStr= NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .extract("encoding", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.encoding")))
                    .extract("excludeContent", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.excludeContent")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("encoding", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.encoding")))
                    .extract("excludeContent", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.excludeContent")))
                    .asMap();
        }

        readActivity.setName(activityMap.get("name"));
        readActivity.setType(new ActivityType(activityMap.get("type")));
        readActivity.setResourceType(activityMap.get("resourceType"));
        readActivity.setEncoding(activityMap.get("encoding"));
        readActivity.setExcludeContent(Boolean.parseBoolean(activityMap.get("excludeContent")));
        readActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,readActivity);
        readActivity.setInputBindings(activity.getInputBindings());
        readActivity.setParameters(activity.getParameters());

        return readActivity;
    }
}

