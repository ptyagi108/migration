package com.dell.dims.ModelConfig;

/**
 * Created by Manoj_Mehta on 12/27/2016.
 */
public class StarterConfig {


}
