package com.dell.dims.Builder;


import com.dell.dims.Model.Activity;
import soa.model.Bpel.BpelProcessDefinition;
import soa.model.Bpel.SequenceDefinition;

public class GroupActivityBuilder extends AbstractActivityBuilder // implements IActivityBuilder
{

    @Override
    public String build(Activity activity)
    {
        System.out.println("SOA Group[] ACtivity com.dell.dims.Builder :: " +activity.getName());
        //start a sequence
        SequenceDefinition sequenceDef=new SequenceDefinition();
        sequenceDef.setName(activity.getName());

       // bpelProcess.getSequences().add(sequenceDef);
        BpelProcessDefinition.sequences.add(sequenceDef);

        return null;
    }
}


