package com.dell.dims.ModelConfig;

import com.dell.dims.Model.GenerateErrorActivity;

/**
 * Created by Manoj_Mehta on 12/29/2016.
 */
public class GenerateErrorActivityConfig {

    private String faultName;

    public String getFaultName() {
        return faultName;
    }

    public void setFaultName(String faultName) {
        this.faultName = faultName;
    }

    public Object getConfigAttributes(GenerateErrorActivity activity) throws Exception {
        this.setFaultName(activity.getFaultName());

        return this;
    }
}
