package com.dell.dims.Model;

/**
 * Created by Kriti_Kanodia on 1/23/2017.
 */
public class FileRemoveActivity extends Activity {

    public FileRemoveActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public FileRemoveActivity() throws Exception {
    }
}
