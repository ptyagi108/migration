package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.RVPubActivity;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

/**
 * Created by Manoj_Mehta on 3/1/2017.
 */
public class RVPubActivityParser implements IActivityParser {
    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        RVPubActivity rvpActivity = new RVPubActivity();

        String nodeStr= NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .extract("wantsXMLCompliantFieldNames", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.wantsXMLCompliantFieldNames")))
                    .extract("xsdString", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.xsdString")))
                    .extract("sharedChannel", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.sharedChannel")))
                    .extract("xmlEncoding", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.xmlEncoding")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))

                    .extract("wantsXMLCompliantFieldNames", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.wantsXMLCompliantFieldNames")))
                    .extract("xsdString", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.xsdString")))
                    .extract("sharedChannel", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.sharedChannel")))
                    .extract("xmlEncoding", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.xmlEncoding")))
                    .asMap();
        }

        rvpActivity.setName(activityMap.get("name"));
        rvpActivity.setType(new ActivityType(activityMap.get("type")));
        rvpActivity.setResourceType(activityMap.get("resourceType"));
        rvpActivity.setWantsXMLCompliantFieldNames(Boolean.parseBoolean(activityMap.get("wantsXMLCompliantFieldNames")));
        rvpActivity.setXsdString(activityMap.get("xsdString"));
        rvpActivity.setSharedChannel(activityMap.get("sharedChannel"));
        rvpActivity.setXmlEncoding(Boolean.parseBoolean(activityMap.get("xmlEncoding")));

        rvpActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,rvpActivity);
        rvpActivity.setInputBindings(activity.getInputBindings());
        rvpActivity.setParameters(activity.getParameters());

        return rvpActivity;
    }
}
