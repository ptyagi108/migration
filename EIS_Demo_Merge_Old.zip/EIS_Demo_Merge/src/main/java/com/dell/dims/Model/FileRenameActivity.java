package com.dell.dims.Model;

public class FileRenameActivity extends Activity
{
    public FileRenameActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public FileRenameActivity() throws Exception {
    }

    private boolean createMissingDirectories;
    private boolean overwrite;

    public boolean isCreateMissingDirectories() {
        return createMissingDirectories;
    }

    public void setCreateMissingDirectories(boolean createMissingDirectories) {
        this.createMissingDirectories = createMissingDirectories;
    }

    public boolean isOverwrite() {
        return overwrite;
    }

    public void setOverwrite(boolean overwrite) {
        this.overwrite = overwrite;
    }
}


