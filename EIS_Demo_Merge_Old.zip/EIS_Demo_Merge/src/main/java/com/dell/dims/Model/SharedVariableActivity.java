package com.dell.dims.Model;

public class SharedVariableActivity  extends Activity
{
    public SharedVariableActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public SharedVariableActivity() throws Exception {
    }

    private String variableConfig;
    private boolean isSetterActivity;

    public String getVariableConfig() {
        return variableConfig;
    }

    public void setVariableConfig(String variableConfig) {
        this.variableConfig = variableConfig;
    }

    public boolean isSetterActivity() {
        return isSetterActivity;
    }

    public void setSetterActivity(boolean setterActivity) {
        isSetterActivity = setterActivity;
    }
}


