package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FTPPutActivity;
import com.dell.dims.Model.FileWriteActivity;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

/**
 * Created by Manoj_Mehta on 4/7/2017.
 */
public class FTPPutActivityParser implements IActivityParser {

    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        FTPPutActivity ftpPutActivity = new FTPPutActivity();

        String nodeStr = NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap = null;

        if (isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .extract("Timeout", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.Timeout")))
                    .extract("FireWall", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.FireWall")))
                    .extract("isBinary", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.isBinary")))
                    .extract("isBinary", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.isBinary")))
                    .extract("Append", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.Append")))
                    .extract("useProcessData", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.useProcessData")))
                    .extract("Overwrite", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.Overwrite")))
                    .extract("SharedUserData", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.SharedUserData")))
                    .asMap();
        } else {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("Timeout", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.Timeout")))
                   .extract("FireWall", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.FireWall")))
                    .extract("isBinary", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.isBinary")))
                    .extract("Append", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.Append")))
                    .extract("useProcessData", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.useProcessData")))
                     .extract("Overwrite", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.Overwrite")))
                    .extract("SharedUserData", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.SharedUserData")))
                    .asMap();
        }

        ftpPutActivity.setName(activityMap.get("name"));
        ftpPutActivity.setType(new ActivityType(activityMap.get("type")));

        ftpPutActivity.setResourceType(activityMap.get("resourceType"));
        ftpPutActivity.setTimeout(activityMap.get("Timeout"));
        ftpPutActivity.setFirewall(Boolean.parseBoolean(activityMap.get("FireWall")));
        ftpPutActivity.setBinary(Boolean.parseBoolean(activityMap.get("isBinary")));
        ftpPutActivity.setAppend(Boolean.parseBoolean(activityMap.get("Append")));
        ftpPutActivity.setUseProcessData(Boolean.parseBoolean(activityMap.get("useProcessData")));
        ftpPutActivity.setOverwrite(Boolean.parseBoolean(activityMap.get("Overwrite")));
        ftpPutActivity.setSharedUserData(activityMap.get("SharedUserData"));
        ftpPutActivity.setGroupActivity(isGroupActivity);

        Activity activity = InputBindingExtractor.extractInputBindingAndParameters(node, ftpPutActivity);
        ftpPutActivity.setInputBindings(activity.getInputBindings());
        ftpPutActivity.setParameters(activity.getParameters());

        return ftpPutActivity;
    }
}