//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Model;

import java.util.List;
import java.util.Map;

public class JdbcUpdateActivity extends Activity
{
    public JdbcUpdateActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public JdbcUpdateActivity() throws Exception {
    }

    //private int timeOut;
    private String timeOut;
    private boolean commit;

    private boolean emptyStringAsNull;
    private String  statement;
    private String jdbcSharedConfig;
    /**
     * Gets or sets the query statement parameters.
     * Key is the parameter Name
     * Value is the parameter Type (VARCHAR, INT, ...)
     * The query statement parameters.
     */
    private Map<String, String> prepared_Param_DataType;

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

    public boolean isCommit() {
        return commit;
    }

    public void setCommit(boolean commit) {
        this.commit = commit;
    }

    public boolean isEmptyStringAsNull() {
        return emptyStringAsNull;
    }

    public void setEmptyStringAsNull(boolean emptyStringAsNull) {
        this.emptyStringAsNull = emptyStringAsNull;
    }

    public String getStatement() {
        return statement;
    }

    public void setStatement(String statement) {
        this.statement = statement;
    }

    public String getJdbcSharedConfig() {
        return jdbcSharedConfig;
    }

    public void setJdbcSharedConfig(String jdbcSharedConfig) {
        this.jdbcSharedConfig = jdbcSharedConfig;
    }

    public Map<String, String> getPrepared_Param_DataType() {
        return prepared_Param_DataType;
    }

    public void setPrepared_Param_DataType(Map<String, String> prepared_Param_DataType) {
        this.prepared_Param_DataType = prepared_Param_DataType;
    }

    public Object getConfigAttributes(JavaActivity activity) throws Exception {

        // implement it
        return this;
    }
}
