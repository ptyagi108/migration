package com.dell.dims.gop;

import java.util.Iterator;

/**
 * This node will represent a specific automatic action
 *
 * @author salaboy
 */
public class ActionGopNode extends GopNode {

    public ActionGopNode(String name) {
        super(name);
    }

    @Override
    public void graph() {
        String padding = "";
        String token = "-";
        for (int i = 0; i < this.getName().length(); i++) {
            padding += token;
        }
        System.out.println("+-----------------------.");
        System.out.println("|<AUTOMATIC ACTION NODE>|");
        System.out.println("+---" + padding + "---.");
        System.out.println("| *  " + this.getName() + "   |");
        System.out.println("+---" + padding + "---+");

        Iterator<Transition> transitionIt = getTransitions().values().iterator();
        while (transitionIt.hasNext()) {
            transitionIt.next().graph();
        }
    }


}
