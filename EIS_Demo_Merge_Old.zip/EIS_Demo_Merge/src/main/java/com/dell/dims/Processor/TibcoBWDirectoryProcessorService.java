//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;

import java.io.File;

public class TibcoBWDirectoryProcessorService   implements IDirectoryProcessorService
{
  //  private static final ILog Log = LogManager.GetLogger(TibcoBWDirectoryProcessorService.class);

    private final IFileProcessorService tibcoFileProcessorService;
    private final IFileProcessorService xsdFileProcessorService;
    private final IFileProcessorService globalVariableProcessor;
    private final IFileProcessorService adapterSchemaProcessor;
    private final IFileFilter filter;
    public TibcoBWDirectoryProcessorService(IFileProcessorService tibcoFileProcessorService, IFileProcessorService xsdFileProcessorService, IFileProcessorService globalVariableProcessor, IFileProcessorService adapterSchemaProcessor, IFileFilter fileFilter) throws Exception {
        this.tibcoFileProcessorService = tibcoFileProcessorService;
        this.xsdFileProcessorService = xsdFileProcessorService;
        this.globalVariableProcessor = globalVariableProcessor;
        this.adapterSchemaProcessor = adapterSchemaProcessor;
        this.filter = fileFilter;
    }

    public void process(String directoryName) throws Exception {

        File directory = new File(directoryName);
        //get all the files from a directory
        File[] fList = directory.listFiles();

        for (File file : fList)
        {
            if (file.isFile())
            {
                System.out.println("file path : "+file.getAbsolutePath());
                //

                if(file.getName().endsWith(".xsd"))
                {
                    //file treatement
                    this.xsdFileProcessorService.process(file.getAbsolutePath());
                }

                if(file.getName().endsWith(".substvar"))
                {
                    //file treatement
                    this.globalVariableProcessor.process(file.getAbsolutePath());
                }


                if(file.getName().endsWith(".aeschema"))
                {
                    //file treatement
                    this.adapterSchemaProcessor.process(file.getAbsolutePath());
                }

            }
            //if file contain directory then get files inside sub directory
            else if (file.isDirectory())
            {
                this.process(file.getAbsolutePath());
            }
        }


        /*String[] files = new String[]();
        String[] directories = new String[]();
        try
        {
            files = Directory.GetFiles(directory);
            directories = Directory.GetDirectories(directory);
        }
        catch (Exception e)
        {
            //Log.Error("Unknow Error I'm going to quit because: ", e);
            return ;
        }

        for (Object dummyForeachVar0 : files)
        {
            //Directory treatement
            String file = (String)__dummyForeachVar0;
            if (file.EndsWith(".process"))
            {
                if (this.filter.isFileAuthorized(file))
                {
                    //file treatement
                    this.tibcoFileProcessorService.process(file);
                }

            }

            if (file.EndsWith(".xsd"))
            {
                //file treatement
                this.xsdFileProcessorService.process(file);
            }

            if (file.EndsWith(".substvar"))
            {
                //file treatement
                this.globalVariableProcessor.process(file);
            }

            if (file.EndsWith(".aeschema"))
            {
                //file treatement
                this.adapterSchemaProcessor.process(file);
            }

        }
        for (Object dummyForeachVar1 : directories)
        {
            String subDirectory = (String)__dummyForeachVar1;
            this.Process(Path.Combine(directory, subDirectory));
        } */
    }

}


