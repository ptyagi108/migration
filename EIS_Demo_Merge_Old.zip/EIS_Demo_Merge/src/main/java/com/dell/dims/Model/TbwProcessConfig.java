package com.dell.dims.Model;

public class TbwProcessConfig
{
    private String name;
    private boolean isEnabled;
    private boolean activation;
    private int maxJob;
    private int flowLimit;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setEnabled(boolean enabled) {
        isEnabled = enabled;
    }

    public boolean isActivation() {
        return activation;
    }

    public void setActivation(boolean activation) {
        this.activation = activation;
    }

    public int getMaxJob() {
        return maxJob;
    }

    public void setMaxJob(int maxJob) {
        this.maxJob = maxJob;
    }

    public int getFlowLimit() {
        return flowLimit;
    }

    public void setFlowLimit(int flowLimit) {
        this.flowLimit = flowLimit;
    }
}


