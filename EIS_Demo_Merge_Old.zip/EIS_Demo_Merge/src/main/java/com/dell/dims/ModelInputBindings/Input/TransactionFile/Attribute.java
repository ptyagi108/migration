package com.dell.dims.ModelInputBindings.Input.TransactionFile;

/**
 * Created by Manoj_Mehta on 3/3/2017.
 */
public class Attribute
{

    private String value;
    private String name;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
