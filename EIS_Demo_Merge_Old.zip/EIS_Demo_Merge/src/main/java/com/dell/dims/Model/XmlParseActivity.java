//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Model;

import java.util.List;

public class XmlParseActivity  extends Activity
{
    public XmlParseActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public XmlParseActivity() throws Exception {
    }

    private String xsdReference = new String();
    private String inputStyle;
    private String xsdVersion;
    private List<ClassParameter> term;

    public List<ClassParameter> getTerm() {
        return term;
    }

    public void setTerm(List<ClassParameter> term) {
        this.term = term;
    }

    public String getXsdReference() {
        return xsdReference;
    }

    public void setXsdReference(String value) {
        xsdReference = value;
    }

    public String getInputStyle() {
        return inputStyle;
    }

    public void setInputStyle(String inputStyle) {
        this.inputStyle = inputStyle;
    }

    public String getXsdVersion() {
        return xsdVersion;
    }

    public void setXsdVersion(String xsdVersion) {
        this.xsdVersion = xsdVersion;
    }

    public boolean isValidateOutput() {
        return validateOutput;
    }

    public void setValidateOutput(boolean validateOutput) {
        this.validateOutput = validateOutput;
    }

    private boolean validateOutput;

}


