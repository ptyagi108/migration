package com.dell.dims.ModelConfig;

import java.util.Date;

/**
 * Created by Manoj_Mehta on 1/2/2017.
 */
public class TimerEventActivityConfig {

    private String FrequencyIndex;
    boolean Frequency;
    int TimeInterval;
    Date StartTime;

    public String getFrequencyIndex() {
        return FrequencyIndex;
    }

    public void setFrequencyIndex(String frequencyIndex) {
        FrequencyIndex = frequencyIndex;
    }

    public void setStartTime(Date startTime) {
        StartTime = startTime;
    }

    public boolean isFrequency() {
        return Frequency;
    }

    public void setFrequency(boolean frequency) {
        Frequency = frequency;
    }

    public int getTimeInterval() {
        return TimeInterval;
    }

    public void setTimeInterval(int timeInterval) {
        TimeInterval = timeInterval;
    }

    public Date getStartTime() {
        return StartTime;
    }
}
