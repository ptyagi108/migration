package com.dell.dims.ModelInputBindings.InputBeans;

import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 3/7/2017.
 */
public class FilesProperties {
    private String TrackingID;
    private String requestFilename;
    private String requestFilelocation;
    private String fullName;
    private String TrxType;
    private String Channel;
    private String LastUpdBy;
    private String Status;

    public String getTrackingID() {
        return TrackingID;
    }

    public void setTrackingID(String trackingID) {
        TrackingID = trackingID;
    }

    public String getRequestFilename() {
        return requestFilename;
    }

    public void setRequestFilename(String requestFilename) {
        this.requestFilename = requestFilename;
    }

    public String getRequestFilelocation() {
        return requestFilelocation;
    }

    public void setRequestFilelocation(String requestFilelocation) {
        this.requestFilelocation = requestFilelocation;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getTrxType() {
        return TrxType;
    }

    public void setTrxType(String trxType) {
        TrxType = trxType;
    }

    public String getChannel() {
        return Channel;
    }

    public void setChannel(String channel) {
        Channel = channel;
    }

    public String getLastUpdBy() {
        return LastUpdBy;
    }

    public void setLastUpdBy(String lastUpdBy) {
        LastUpdBy = lastUpdBy;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}