
package com.dell.dims.gop;

import com.dell.dims.util.RuntimeDimsException;

import java.util.Stack;

public class ExecutionContext {

    protected Token token = null;

    protected Action action = null;
    protected Throwable exception = null;
    protected Transition transition = null;
    protected GopNode transitionSource = null;

    protected ProcessInstance subProcessInstance = null;

    public ExecutionContext(Token token) {
        this.token = token;
    }

    public ExecutionContext(ExecutionContext other) {
        this.token = other.token;
        this.action = other.action;
    }

    public GopNode getNode() {
        return token.getNode();
    }

    public ProcessDefinition getProcessDefinition() {
        ProcessInstance processInstance = getProcessInstance();
        return (processInstance != null ? processInstance.getProcessDefinition() : null);
    }

    public void setAction(Action action) {
        this.action = action;

    }

    public ProcessInstance getProcessInstance() {
        return token.getProcessInstance();
    }

    public String toString() {
        return "ExecutionContext[" + token + "]";
    }

    // convenience methods //////////////////////////////////////////////////////

    /**
     * set a process variable.
     */
    public void setVariable(String name, Object value) {

        getContextInstance().setVariable(name, value, token);

    }

    /**
     * get a process variable.
     */
    public Object getVariable(String name) {

        return getContextInstance().getVariable(name, token);
    }


    public ModuleInstance getInstance(Class clazz) {
        ProcessInstance processInstance = (token != null ? token.getProcessInstance() : null);
        return (processInstance != null ? processInstance.getInstance(clazz) : null);
    }

    public ContextInstance getContextInstance() {
        return (ContextInstance) getInstance(ContextInstance.class);
    }


    // getters and setters //////////////////////////////////////////////////////


    public Token getToken() {
        return token;
    }

    public Action getAction() {
        return action;
    }

    public Throwable getException() {
        return exception;
    }

    public void setException(Throwable exception) {
        this.exception = exception;
    }

    public Transition getTransition() {
        return transition;
    }

    public void setTransition(Transition transition) {
        this.transition = transition;
    }

    public GopNode getTransitionSource() {
        return transitionSource;
    }

    public void setTransitionSource(GopNode transitionSource) {
        this.transitionSource = transitionSource;
    }

    public ProcessInstance getSubProcessInstance() {
        return subProcessInstance;
    }

    public void setSubProcessInstance(ProcessInstance subProcessInstance) {
        this.subProcessInstance = subProcessInstance;
    }

    // thread local execution context

    static ThreadLocal threadLocalContextStack = new ThreadLocal();

    static Stack getContextStack() {
        Stack stack = (Stack) threadLocalContextStack.get();
        if (stack == null) {
            stack = new Stack();
            threadLocalContextStack.set(stack);
        }
        return stack;
    }

    public static void pushCurrentContext(ExecutionContext executionContext) {
        getContextStack().push(executionContext);
    }

    public static void popCurrentContext(ExecutionContext executionContext) {
        if (getContextStack().pop() != executionContext) {
            throw new RuntimeDimsException("current execution context mismatch.  make sure that every pushed context gets popped");
        }
    }

    public static ExecutionContext currentExecutionContext() {
        ExecutionContext executionContext = null;
        Stack stack = getContextStack();
        if (!stack.isEmpty()) {
            executionContext = (ExecutionContext) stack.peek();
        }
        return executionContext;
    }
}
