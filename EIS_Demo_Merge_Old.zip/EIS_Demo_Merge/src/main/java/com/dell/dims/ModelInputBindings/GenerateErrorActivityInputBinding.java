package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;
import com.dell.dims.Router.RoutingRulesDefinition;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 2/7/2017.
 */
public class GenerateErrorActivityInputBinding extends InputBinding{

    private RoutingRulesDefinition routeRuleDef= new RoutingRulesDefinition();
    @Override
    public InputBinding captureInputBindingAttributes(Activity activity) {
        {
            InputBinding inputBindings=new InputBinding();
            Map<String,Object> mapAttributesList= new HashMap<String,Object>();
            Map<String,String> mapEndpointOptions= new HashMap<String,String>();
            String attribute="";
            StringBuilder attributeVal;

            // check if current process is subprocess
            if(activity.getResourceType().toUpperCase().contains(".subprocess".toUpperCase()))
            {
                System.out.println("\n*****Subprocess EXIST for*****"+activity.getName() + " Process");
                inputBindings.setSubprocess(true);
            }

            List<ClassParameter> paramList = activity.getParameters();
            if (paramList.size() > 0)
            {
                for (ClassParameter classParam : paramList)
                {
                    //check for message
                    attribute="message";
                    attributeVal=captureAttributeValue(classParam,attribute);
                    if(attributeVal!=null && attributeVal.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeVal.toString());
                    }

                    //check for messageCode
                    attribute="messageCode";
                    attributeVal=captureAttributeValue( classParam,attribute);
                    if(attributeVal!=null && attributeVal.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeVal.toString());
                    }

                }
            }
            inputBindings.setSchemeName("LOG");
            inputBindings.setActivityName(activity.getName());
            inputBindings.setActivityType(activity.getType().toString());
            inputBindings.setAttributesList(mapAttributesList);

            return inputBindings;
        }
    }

}
