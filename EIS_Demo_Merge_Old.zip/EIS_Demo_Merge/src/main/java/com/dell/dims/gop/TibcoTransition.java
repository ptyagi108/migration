package com.dell.dims.gop;

/**
 * Created by Pramod_Kumar_Tyagi on 8/1/2016.
 */
public class TibcoTransition extends Transition {

    protected String conditionType;
}
