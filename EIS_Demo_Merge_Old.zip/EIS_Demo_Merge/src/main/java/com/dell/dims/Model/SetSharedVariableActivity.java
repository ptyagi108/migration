package com.dell.dims.Model;

public class SetSharedVariableActivity  extends Activity
{
    public SetSharedVariableActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public SetSharedVariableActivity() throws Exception {
    }

    private String variableConfig;
    private boolean showResult;

    public String setVariableConfig() {
        return variableConfig;
    }

    public void setVariableConfig(String variableConfig) {
        this.variableConfig = variableConfig;
    }

    public boolean isShowResult() {
        return showResult;
    }

    public void setShowResult(boolean showResult) {
        this.showResult = showResult;
    }

}


