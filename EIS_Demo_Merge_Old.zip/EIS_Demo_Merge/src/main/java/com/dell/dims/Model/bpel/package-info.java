//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.5-2
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a>
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen.
// Generado el: PM.02.21 a las 09:44:00 PM CET
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.dell.dims.Model.bpel;
