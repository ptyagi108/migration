//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:12 PM
//

package com.dell.dims.Builder;

import com.dell.dims.Model.Activity;

public class SleepActivityBuilder extends AbstractActivityBuilder
{

    public SleepActivityBuilder() throws Exception {
    }

    @Override
    public String build(Activity activity) {
        return null;
    }
}


