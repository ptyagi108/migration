package com.dell.dims.ModelConfig;

import com.dell.dims.Model.ActivityType;

/**
 * Created by Manoj_Mehta on 4/7/2017.
 */
public class ListFilesActivityConfig {

    private String mode;
    public ListFilesActivityConfig() {
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }
}
