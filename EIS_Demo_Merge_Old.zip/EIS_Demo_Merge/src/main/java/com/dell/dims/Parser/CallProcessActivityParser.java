package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.CallProcessActivity;
import com.dell.dims.Parser.Utils.FileUtility;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;


public class CallProcessActivityParser extends  AbstractActivityParser {

    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        CallProcessActivity processActivity = new CallProcessActivity();

        String nodeStr=NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("processName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.processName")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("processName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.processName")))
                    .asMap();
        }

        processActivity.setName(activityMap.get("name"));
        processActivity.setType(new ActivityType(activityMap.get("type")));
        processActivity.setResourceType(activityMap.get("resourceType"));
        processActivity.setProcessName(activityMap.get("processName"));
        processActivity.setGroupActivity(isGroupActivity);
        /*System.out.println("isGroupActitivty:" + isGroupActivity);
        System.out.println("Name:" + activityMap.get("name"));
        System.out.println("Type:" + activityMap.get("type"));
        System.out.println("overwrite:" + activityMap.get("overwrite"));
        System.out.println("createMissingDirectories:" + activityMap.get("createMissingDirectories"));*/

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,processActivity);
        processActivity.setInputBindings(activity.getInputBindings());
        processActivity.setParameters(activity.getParameters());
      //  processActivity.setInputSchemaQname(doCreateOrFindInputSchema(processActivity));
      //  processActivity.setOutputSchemaQname(doCreateOrFindOutputSchema(processActivity));
        return processActivity;
    }


}


  /*  public Activity parse(String inputElement) throws Exception {
        CallProcessActivity callProcessActivity = new CallProcessActivity();

        //tibco Process activity
        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();


        callProcessActivity.setName(activityMap.get("name"));
        callProcessActivity.setType(new ActivityType(activityMap.get("type")));

        CallProcessActivityConfig callProcessConfig = Extractors.on(inputElement)
                .extract("config", extractBean(new AssignActivityConfig()))
                .asBean(CallProcessActivityConfig.class);

        //process name
        callProcessActivity.setProcessName(callProcessConfig.getProcessName());


        // for input bindings
        NodeList childNodes= NodesExtractorUtil.getChildNode(inputElement);
        for (int j = 0; j < childNodes.getLength(); j++) {
            Node node = childNodes.item(j);

            if (node instanceof Element) {
                // a child element to process
                Element element = (Element) node;
                String nodeName = element.getNodeName();

                if (nodeName.equalsIgnoreCase("inputBindings")) {
                    String nodeSubString = NodesExtractorUtil.nodeToString(node);
                    callProcessActivity.setInputBindings((List<Node>) NodesExtractorUtil.getChildNode(nodeSubString));
                    callProcessActivity.setParameters((new XslParser()).parse(callProcessActivity.getInputBindings()));
                }
            }
        }



        return callProcessActivity;
    }
*/
