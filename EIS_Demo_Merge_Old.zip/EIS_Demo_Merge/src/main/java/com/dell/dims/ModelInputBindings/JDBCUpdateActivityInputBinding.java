package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 3/1/2017.
 */
public class JDBCUpdateActivityInputBinding extends InputBinding {

    InputBinding inputBindings = new InputBinding();
    Map<String, Object> mapAttributesList = new HashMap<String, Object>();
    Map<String, Object> mapEndpointOptions = new HashMap<String, Object>();
    String attribute = "";
    StringBuilder attributeVal;

    @Override
    public InputBinding captureInputBindingAttributes(Activity activity) {
        // check if current process is subprocess
        if (activity.getResourceType().toUpperCase().contains(".subprocess".toUpperCase())) {
            System.out.println("\n*****Subprocess EXIST for*****" + activity.getName() + " Process");
            inputBindings.setSubprocess(true);
        }

        List<ClassParameter> paramList = activity.getParameters();
        if (paramList.size() > 0) {
            for (ClassParameter classParam : paramList) {
                //check for outFilename
                attribute = "outFilename";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //ack997URI
                attribute = "ack997URI";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //ackTA1URI
                attribute = "ackTA1URI";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //LastUpdateBy
                attribute = "LastUpdateBy";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }
                //TrxID
                attribute = "TrxID";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //InFileNm
                attribute = "InFileNm";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //TrxType
                attribute = "TrxType";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //Channel
                attribute = "Channel";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }
                //Status
                attribute = "Status";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //LastUpdBy
                attribute = "LastUpdBy";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }
                //AccessId
                attribute = "AccessId";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0)
                {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }
            }
        }

        inputBindings.setSchemeName("JDBC");
        inputBindings.setActivityName(activity.getName());
        inputBindings.setActivityType(activity.getType().toString());
        inputBindings.setAttributesList(mapAttributesList);
        inputBindings.setEndPointOptions(mapEndpointOptions);

        return inputBindings;
    }
}
