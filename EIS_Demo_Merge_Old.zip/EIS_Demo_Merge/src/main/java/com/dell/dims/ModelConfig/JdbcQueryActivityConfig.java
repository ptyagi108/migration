package com.dell.dims.ModelConfig;

import com.dell.dims.Model.*;

import java.util.List;
import java.util.Map;

public class JdbcQueryActivityConfig
{
    public JdbcQueryActivityConfig() throws Exception {
    }

    //private int timeOut;
    private String timeOut;
    private boolean commit;
    private int maxRows;

    private boolean emptyStringAsNull;
    private String jdbcSharedConfig;
    private String queryStatement;
    /**
     * Gets or sets the query statement parameters.
     * Key is the parameter Name
     * Value is the parameter Type (VARCHAR, INT, ...)
     * The query statement parameters.
     */
    private Map<String, String> queryStatementParameters;

    /**
     *Gets or sets the query queryOutputStatementParameters.
     * Name is SchemaColumn Name
     * Type is Schema Data Types
     *   SpecialOption is SchemaStatus
     */
    private List<ClassParameter> queryOutputStatementParameters;
    private String className;

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

    public boolean isCommit() {
        return commit;
    }

    public void setCommit(boolean commit) {
        this.commit = commit;
    }

    public int getMaxRows() {
        return maxRows;
    }

    public void setMaxRows(int maxRows) {
        this.maxRows = maxRows;
    }

    public boolean isEmptyStringAsNull() {
        return emptyStringAsNull;
    }

    public void setEmptyStringAsNull(boolean emptyStringAsNull) {
        this.emptyStringAsNull = emptyStringAsNull;
    }

    public String getJdbcSharedConfig() {
        return jdbcSharedConfig;
    }

    public void setJdbcSharedConfig(String jdbcSharedConfig) {
        this.jdbcSharedConfig = jdbcSharedConfig;
    }

    public String getQueryStatement() {
        return queryStatement;
    }

    public void setQueryStatement(String queryStatement) {
        this.queryStatement = queryStatement;
    }

    public Map<String, String> getQueryStatementParameters() {
        return queryStatementParameters;
    }

    public void setQueryStatementParameters(Map<String, String> queryStatementParameters) {
        this.queryStatementParameters = queryStatementParameters;
    }

    public List<ClassParameter> getQueryOutputStatementParameters() {
        return queryOutputStatementParameters;
    }

    public void setQueryOutputStatementParameters(List<ClassParameter> queryOutputStatementParameters) {
        this.queryOutputStatementParameters = queryOutputStatementParameters;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Object getConfigAttributes(JdbcQueryActivity activity) throws Exception {

        this.setTimeOut(activity.getTimeOut());
        this.setCommit(activity.isCommit());
        this.setMaxRows(activity.getMaxRows());
        this.setEmptyStringAsNull(activity.isEmptyStringAsNull());
        this.setJdbcSharedConfig(activity.getJdbcSharedConfig());
        this.setQueryStatement(activity.getQueryStatement());
        this.setQueryStatementParameters(activity.getQueryStatementParameters());
        this.setQueryOutputStatementParameters(activity.getQueryOutputStatementParameters());

        return this;
    }
}
