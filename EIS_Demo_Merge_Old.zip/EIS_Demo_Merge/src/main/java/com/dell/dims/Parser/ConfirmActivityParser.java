//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.ConfirmActivity;
import com.dell.dims.ModelConfig.ConfirmActivityConfig;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

/* Sample xml
    xml = "<pd:activity name=\"Mappe Equity\" xmlns:pd=\"http://xmlns.tibco.com/bw/process/2003\" xmlns:xsl=\"http://w3.org/1999/XSL/Transform\">\n" +
        "<pd:type>com.tibco.pe.core.ConfirmActivity</pd:type>\n" +
        "<config>\n" +
        "<ConfirmEvent>Rendez vous suscriber</ConfirmEvent>\n" +
        "</config>\n" +
        "<pd:inputBindings/>\n" +
        "</pd:activity>";  */
public class ConfirmActivityParser implements IActivityParser
{
    public Activity parse(String inputElement) throws Exception {
        ConfirmActivity activity = new ConfirmActivity();

    //tibco assign activity
        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();
        activity.setName(activityMap.get("name"));
        activity.setType(new ActivityType(activityMap.get("type")));

        //config
        ConfirmActivityConfig confirmConfig = Extractors.on(inputElement)
                .extract("config", extractBean(new ConfirmActivityConfig()))
                .asBean(ConfirmActivityConfig.class);

        activity.setActivityNameToConfirm(confirmConfig.getConfirmEvent().replace(' ','_'));

/*
        activity.setName(inputElement.Attribute("name").Value);
        activity.setType((ActivityType)inputElement.Element(XmlnsConstant.tibcoProcessNameSpace + "type").Value);
        *//* [UNSUPPORTED] 'var' as type is unsupported "var" *//* configElement = inputElement.Element("config");
        activity.setActivityNameToConfirm(XElementParserUtils.GetStringValue(configElement.Element("ConfirmEvent")).
                Replace(' ', '_'));*/
        return activity;
    }

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        return null;
    }
}


