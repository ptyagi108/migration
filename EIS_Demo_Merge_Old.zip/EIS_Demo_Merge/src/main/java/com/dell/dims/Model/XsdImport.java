package com.dell.dims.Model;


public class XsdImport
{
    private String namespace = new String();
    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String value) {
        namespace = value;
    }

    private String schemaLocation = new String();
    public String getSchemaLocation() {
        return schemaLocation;
    }

    public void setSchemaLocation(String value) {
        schemaLocation = value;
    }

}


