/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.dell.dims.endpoint.uri;


import com.gh.mygreen.xlsmapper.annotation.XlsColumn;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;


@Component
@Qualifier("default")
public class DefaultEndpointURI implements EndpointURI {


    @XlsColumn(columnName = "ENDPOINT NAME")
    private String endPointName = "ENDPOINT 1";
    @XlsColumn(columnName = "SCHEME")
    private String scheme = "file";
    @XlsColumn(columnName = "CONTEXT PATH")

    private String path;

    private String query;

    private String schemeSpecificPart;
    private String authority;
    private String userInfo;
    private String host;
    private String port;
    private String fragment;
    @XlsColumn(columnName = "OPTIONS")
    private String queryParams;

    @Autowired
    @Qualifier("tibco")
    private EndpointUriOptions queryOptions;

   /* @PostConstruct
    public void init() {
        try {
            queryParams = queryOptions.toUriQueryParametersString(toMap(queryOptions));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }*/

    public void createUriParams() {
        try {
            queryParams = queryOptions.toUriQueryParametersString(toMap(queryOptions));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public String getEndPointName() {
        return "ENDPOINT 1";
    }

    public void setEndPointName(String endPointName) {
        this.endPointName = endPointName;
    }

    public String getScheme() {
        return getURI().getScheme();
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getQuery() {
        return getURI().getQuery();
    }

    public void setQuery(String query) {
        this.query = query;
    }

    @Override
    public URI getURI() {
        return null;
    }

    private Map<String, Object> toMap(Object bean) throws Exception {
        Map<String, Object> properties = new HashMap<>();
        for (PropertyDescriptor property : Introspector.getBeanInfo(bean.getClass(), bean.getClass().getSuperclass()).getPropertyDescriptors()) {
            String name = property.getName();
            Object value = property.getReadMethod().invoke(bean);
            properties.put(name, value);
        }
        return properties;
    }

    public void parseQueryOptions()

    {
        try {
            BeanUtils.populate(queryOptions, URISupport.parseQuery(queryParams));
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public String getSchemeSpecificPart() {
        return schemeSpecificPart;
    }

    public void setSchemeSpecificPart(String schemeSpecificPart) {
        this.schemeSpecificPart = schemeSpecificPart;
    }

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getFragment() {
        return fragment;
    }

    public void setFragment(String fragment) {
        this.fragment = fragment;
    }

    public String getQueryParams() {
        return queryParams;
    }

    public void setQueryParams(String queryParams) {
        this.queryParams = queryParams;
    }

    public EndpointUriOptions getQueryOptions() {
        return queryOptions;
    }

    public void setQueryOptions(EndpointUriOptions queryOptions) {
        this.queryOptions = queryOptions;
    }
}
