package com.dell.dims.ModelConfig;

import com.dell.dims.Model.JavaActivity;

/**
 * Created by Manoj_Mehta on 12/29/2016.
 */
public class JavaActivityConfig {

private String fileName;
private String packageName;
private String fullsource;
private String inputData;
private String outputData;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getFullsource() {
        return fullsource;
    }

    public void setFullsource(String fullsource) {
        this.fullsource = fullsource;
    }

    public String getInputData() {
        return inputData;
    }

    public void setInputData(String inputData) {
        this.inputData = inputData;
    }

    public String getOutputData() {
        return outputData;
    }

    public void setOutputData(String outputData) {
        this.outputData = outputData;
    }

    public Object getConfigAttributes(JavaActivity activity) throws Exception {
        this.setFileName(activity.getFileName());
        this.setPackageName(activity.getPackageName());
        this.setFullsource(activity.getFullsource());
        this.setInputData(String.valueOf(activity.getInputData()));
        this.setOutputData(String.valueOf(activity.getOutputData()));

        return this;
    }

}
