
package com.dell.dims.Model;

import java.util.List;

public class JavaActivity  extends Activity
{
    public JavaActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public JavaActivity() throws Exception {
    }

    private String fileName;
    private String packageName;
    private String fullsource;
    private List<ClassParameter> inputData;
    private List<ClassParameter> outputData;


    public String getFullsource() {
        return fullsource;
    }

    public void setFullsource(String fullsource) {
        this.fullsource = fullsource;
    }



    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }



    public List<ClassParameter> getInputData() {
        return inputData;
    }

    public void setInputData(List<ClassParameter> inputData) {
        this.inputData = inputData;
    }

    public List<ClassParameter> getOutputData() {
        return outputData;
    }

    public void setOutputData(List<ClassParameter> outputData) {
        this.outputData = outputData;
    }
}


