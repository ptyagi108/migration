package com.dell.dims.Model;

/**
 * Created by Manoj_Mehta on 4/7/2017.
 */
public class FTPPutActivity extends Activity {
    public FTPPutActivity(String name, ActivityType type) {
        super(name, type);
    }

    public FTPPutActivity() throws Exception {
    }

    private String timeout;
    private boolean firewall;
    private boolean isBinary;
    private boolean append;
    private boolean useProcessData;
    private boolean Overwrite;
    private String sharedUserData;

    public String getTimeout() {
        return timeout;
    }

    public void setTimeout(String timeout) {
        this.timeout = timeout;
    }

    public boolean isFirewall() {
        return firewall;
    }

    public void setFirewall(boolean firewall) {
        this.firewall = firewall;
    }

    public boolean isBinary() {
        return isBinary;
    }

    public void setBinary(boolean binary) {
        isBinary = binary;
    }

    public boolean isAppend() {
        return append;
    }

    public void setAppend(boolean append) {
        this.append = append;
    }

    public boolean isUseProcessData() {
        return useProcessData;
    }

    public void setUseProcessData(boolean useProcessData) {
        this.useProcessData = useProcessData;
    }

    public boolean isOverwrite() {
        return Overwrite;
    }

    public void setOverwrite(boolean overwrite) {
        Overwrite = overwrite;
    }

    public String getSharedUserData() {
        return sharedUserData;
    }

    public void setSharedUserData(String sharedUserData) {
        this.sharedUserData = sharedUserData;
    }
}
