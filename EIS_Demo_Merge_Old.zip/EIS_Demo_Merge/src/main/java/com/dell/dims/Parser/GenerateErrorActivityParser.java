package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.Model.GenerateErrorActivity;
import com.dell.dims.ModelConfig.GenerateErrorActivityConfig;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;


public class GenerateErrorActivityParser implements IActivityParser {

    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        GenerateErrorActivity errorActivity = new GenerateErrorActivity();

        String nodeStr=NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("faultName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.faultName")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("faultName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.faultName")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .asMap();
        }

        errorActivity.setName(activityMap.get("name"));
        errorActivity.setType(new ActivityType(activityMap.get("type")));
        errorActivity.setFaultName(activityMap.get("faultName"));
        errorActivity.setResourceType(activityMap.get("resourceType"));
        errorActivity.setGroupActivity(isGroupActivity);


        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,errorActivity);
        errorActivity.setInputBindings(activity.getInputBindings());
        errorActivity.setParameters(activity.getParameters());

        /*System.out.println("isGroupActitivty:" + isGroupActivity);
        System.out.println("Name:" + activityMap.get("name"));
        System.out.println("Type:" + activityMap.get("type"));
        System.out.println("overwrite:" + activityMap.get("overwrite"));
        System.out.println("createMissingDirectories:" + activityMap.get("createMissingDirectories"));*/

        return errorActivity;
    }
}





/*xml = "<pd:activity name=\"ERROR activity\" xmlns:pd=\"http://xmlns.tibco.com/bw/process/2003\" xmlns:xsl=\"http://w3.org/1999/XSL/Transform\" xmlns:ns=\"http://www.tibco.com/pe/GenerateErrorActivity/InputSchema\">\n" +
        "        <pd:type>com.tibco.pe.core.GenerateErrorActivity</pd:type>\n" +
        "        <pd:resourceType>ae.activities.throw</pd:resourceType>\n" +
        "        <pd:x>624</pd:x>\n" +
        "        <pd:y>253</pd:y>\n" +
        "        <config>\n" +
        "            <faultName>Info</faultName>\n" +
        "        </config>\n" +
        "        <pd:inputBindings>\n" +
        "            <ns:ActivityInput>\n" +
        "              <message>\n" +
        "                 <xsl:value-of select=\"\'ReadState\'\"/>\n" +
        "              </message>\n" +
        "              <messageCode>\n" +
        "                    <xsl:value-of select=\"\'Not last tuesday : trade filtered\'\"/>\n" +
        "                </messageCode>\n" +
        "            </ns:ActivityInput>\n" +
        "        </pd:inputBindings>\n" +
        "    </pd:activity>";
 */
/*public class GenerateErrorActivityParser implements IActivityParser
{
    public Activity parse(String inputElement) throws Exception {
        GenerateErrorActivity activity = new GenerateErrorActivity();

        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();


        GenerateErrorActivityConfig config = Extractors.on(inputElement)
                .extract("config", extractBean(new GenerateErrorActivityConfig()))
                .asBean(GenerateErrorActivityConfig.class);

        activity.setName(activityMap.get("name"));
        activity.setType(new ActivityType(activityMap.get("type")));
        activity.setFaultName(config.getFaultName());

        // for input bindings
        NodeList childNodes= NodesExtractorUtil.getChildNode(inputElement);
        for (int j = 0; j < childNodes.getLength(); j++) {
            Node node = childNodes.item(j);

            if (node instanceof Element) {
                // a child element to process
                Element element = (Element) node;
                String nodeName = element.getNodeName();

                if (nodeName.equalsIgnoreCase("inputBindings")) {
                    String nodeSubString = NodesExtractorUtil.nodeToString(node);
                    activity.setInputBindings((List<Node>) NodesExtractorUtil.getChildNode(nodeSubString));
                    activity.setParameters((new XslParser()).parse(activity.getInputBindings()));
                }
            }
        }

        return activity;
    }*/





