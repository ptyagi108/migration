

package com.dell.dims.gop;

import java.util.Iterator;

/**
 * @author salaboy
 */
public class HumanDecisionGopNode extends GopNode {

    public HumanDecisionGopNode(String name) {
        super(name);
    }

    @Override
    public void graph() {
        String padding = "";
        String token = "-";
        for (int i = 0; i < this.getName().length(); i++) {
            padding += token;
        }
        System.out.println("+---------------------.");
        System.out.println("|<HUMAN DECISION NODE>|");
        System.out.println("+---" + padding + "---.");
        System.out.println("|   " + this.getName() + " (???) |");
        System.out.println("+---" + padding + "---+");

        Iterator<Transition> transitionIt = getTransitions().values().iterator();
        while (transitionIt.hasNext()) {
            transitionIt.next().graph();
        }
    }

    @Override
    public void execute(Token mainTokenb) {
        System.out.println("Waiting for human interaction ... ");
        System.out.println("the user need to choose between the possible transitions:");
        Iterator<Transition> transitionIt = getTransitions().values().iterator();
        int i = 1;
        while (transitionIt.hasNext()) {
            System.out.println(i++ + ") " + transitionIt.next().getLabel());
        }
        //This node will not propagate the execution to the next node ...
        //because the human interaction will be in charge of that.
        //leave(execution);
    }

    public void decide(String transition, Token mainToken) {
        System.out.println("The user choose the transition: " + transition);
        leave(transition, mainToken);
    }

}
