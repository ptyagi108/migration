package com.dell.dims.ModelConfig;

import com.dell.dims.Model.AssignActivity;
import com.dell.dims.Model.FileRenameActivity;

/**
 * Created by Manoj_Mehta on 12/28/2016.
 */
public class AssignActivityConfig {
    private String variableName;

    public String getVariableName() {
        return variableName;
    }

    public void setVariableName(String variableName) {
        this.variableName = variableName;
    }


    public Object getConfigAttributes(AssignActivity activity) throws Exception {
        this.setVariableName(activity.getVariableName());
        return this;
    }
}
