package com.dell.dims.Parser;

import com.dell.dims.Model.*;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

public class MapperActivityParser implements IActivityParser {
    private final XsdParser xsdParser;

    public MapperActivityParser(XsdParser xsdParser) throws Exception {
        this.xsdParser = xsdParser;
    }


    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        MapperActivity mapperActivity = new MapperActivity();

        String nodeStr = NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap = null;
        List<ClassParameter> activityParameters = null;

        if (isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .asMap();
        } else {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .asMap();
        }

        mapperActivity.setName(activityMap.get("name"));
        mapperActivity.setType(new ActivityType(activityMap.get("type")));
        mapperActivity.setResourceType(activityMap.get("resourceType"));
        mapperActivity.setGroupActivity(isGroupActivity);
        /*System.out.println("isGroupActitivty:" + isGroupActivity);
        System.out.println("Name:" + activityMap.get("name"));
        System.out.println("Type:" + activityMap.get("type"));
        System.out.println("overwrite:" + activityMap.get("overwrite"));
        System.out.println("createMissingDirectories:" + activityMap.get("createMissingDirectories"));*/

        //for config nodes
        NodeList xmlNodes = node.getChildNodes();
        boolean isRefExist = false;
        for (int i = 0; i < xmlNodes.getLength(); i++) {

           // System.out.println( "xmlNodes.item(i).getNodeName() ::" +xmlNodes.item(i).getNodeName());
            if (xmlNodes.item(i).getNodeName().equalsIgnoreCase("config")) {
                //get child node of config
                NodeList configNodes = xmlNodes.item(i).getChildNodes();
                for (int n = 0; n < configNodes.getLength(); n++) {

                    Node nd = configNodes.item(n);
                    if (nd.getNodeName().equalsIgnoreCase("element")) {
                        for (int c = 0; c < nd.getAttributes().getLength(); c++) {
                            Node attributeNode = nd.getAttributes().item(c);

                            if (attributeNode.getNodeName().equalsIgnoreCase("ref")) {
                                isRefExist = true;
                                ClassParameter classParam=new ClassParameter();
                                System.out.println(" Node attr :::" + attributeNode.getTextContent());
                                classParam.setType("ref");
                                classParam.setDefaultValue(attributeNode.getTextContent());
                                classParam.setName(attributeNode.getNodeName());

                                mapperActivity.setXsdReference((List<ClassParameter>) classParam);
                            }
                        }
                    }

                    //attribute
                    else if (node.getNodeName().equalsIgnoreCase("attribute"))
                    {
                        for (int c = 0; c < node.getAttributes().getLength(); c++) {
                            Node attributeNode = node.getAttributes().item(c);

                            System.out.println(attributeNode.getNodeName() + attributeNode.getTextContent());
                        }
                    }
                }
                if (!isRefExist) {
                    for (int n = 0; n < configNodes.getLength(); n++) {
                        Node nd = configNodes.item(n);
                        if (nd.getNodeName().equalsIgnoreCase("element")) {
                            //mapperActivity.setObjectXNodes(xsdParser.parse(configNodes.item(n), ""));
                            mapperActivity.setXsdReference(xsdParser.parse(configNodes.item(n), ""));

                        }
                    }
                }
            }
        }


        //input bindings
        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,mapperActivity);
        mapperActivity.setInputBindings(activity.getInputBindings());
        mapperActivity.setParameters(activity.getParameters());

        return mapperActivity;
    }
}

   /* public Activity parse(String inputElement) throws Exception {
        MapperActivity mapperActivity = new MapperActivity();

        //tibco assign activity
        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();


        mapperActivity.setName(activityMap.get("name"));
        mapperActivity.setType(new ActivityType(activityMap.get("type")));


        //config Node
        String configStr = Extractors.on(inputElement)
                .extract("config")
                .asString();

        boolean isRefExist=false;
        NodeList configNdList=NodesExtractorUtil.getChildNode(configStr);
        for (int n = 0; n < configNdList.getLength(); n++) {
            Node nd = configNdList.item(n);
            if(nd.getNodeName().equalsIgnoreCase("element"))
            {
                for(int c=0;c <nd.getAttributes().getLength();c++) {
                    Node attributeNode = nd.getAttributes().item(c);

                    if(attributeNode.getNodeName().equalsIgnoreCase("ref"))
                    {
                        isRefExist=true;
                        System.out.println(" Node attr :::" + attributeNode.getTextContent());
                        mapperActivity.setXsdReference(attributeNode.getTextContent());
                    }
                }
            }
        }

        if(!isRefExist)
        {
            for (int n = 0; n < configNdList.getLength(); n++) {
                Node nd = configNdList.item(n);
                if (nd.getNodeName().equalsIgnoreCase("element")) {

                    NodeList chList =nd.getChildNodes();
                    mapperActivity.setObjectXNodes((List<Node>) chList);
                }
            }

        }


// for input bindings
        NodeList childNodes= NodesExtractorUtil.getChildNode(inputElement);
        for (int j = 0; j < childNodes.getLength(); j++) {
            Node node = childNodes.item(j);

            if (node instanceof Element) {
                // a child element to process
                Element element = (Element) node;
                String nodeName = element.getNodeName();

                if (nodeName.equalsIgnoreCase("inputBindings")) {
                    String nodeSubString = NodesExtractorUtil.nodeToString(node);
                    mapperActivity.setInputBindings((List<Node>) NodesExtractorUtil.getChildNode(nodeSubString));
                    mapperActivity.setParameters((new XslParser()).parse(mapperActivity.getInputBindings()));
                }
            }
        }


        return mapperActivity;
    }

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        return null;
    }*/
