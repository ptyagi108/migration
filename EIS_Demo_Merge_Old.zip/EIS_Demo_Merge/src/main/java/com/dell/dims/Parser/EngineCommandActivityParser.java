//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.EngineCommandActivity;
import com.dell.dims.ModelConfig.EngineCommandActivityConfig;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;
/* xml = "<pd:activity name=\"null activity\" xmlns:pd=\"http://xmlns.tibco.com/bw/process/2003\" xmlns:xsl=\"http://w3.org/1999/XSL/Transform\" xmlns:pfx4=\"com/tibco/pe/commands\">\n" +
        "        <pd:type>com.tibco.pe.core.EngineCommandActivity</pd:type>\n" +
        "        <pd:resourceType>ae.activities.enginecommand</pd:resourceType>\n" +
        "        <config>\n" +
        "            <command>GetProcessInstanceInfo</command>\n" +
        "        </config>\n" +
        "        <pd:inputBindings>\n" +
        "            <pfx4:input/>\n" +
        "        </pd:inputBindings>\n" +
        "\n" +
        "</pd:activity>";
 */

public class EngineCommandActivityParser implements IActivityParser
{
    public Activity parse(String inputElement) throws Exception {
        EngineCommandActivity activity = new EngineCommandActivity();

        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();

        activity.setName(activityMap.get("name"));
        activity.setType(new ActivityType(activityMap.get("type")));

        EngineCommandActivityConfig config = Extractors.on(inputElement)
                .extract("config", extractBean(new EngineCommandActivityConfig()))
                .asBean(EngineCommandActivityConfig.class);

        activity.setCommand(config.getCommand());

        /*configElement = inputElement.Element("config");
        if (configElement != null)
        {
            activity.setCommand(XElementParserUtils.GetStringValue(configElement.Element("command")));
        }*/

        return activity;
    }

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        return null;
    }
}


