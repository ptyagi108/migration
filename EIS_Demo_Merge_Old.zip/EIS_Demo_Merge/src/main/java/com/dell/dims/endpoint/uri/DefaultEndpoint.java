/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.dell.dims.endpoint.uri;


import com.gh.mygreen.xlsmapper.annotation.XlsColumn;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.net.URISyntaxException;
import java.util.*;

/**
 * A default endpoint useful for implementation inheritance.
 * <p/>
 * Components which leverages asynchronous
 * processing model_old</a> should check the {isSynchronous()} to determine
 * if asynchronous processing is allowed. The <tt>synchronous</tt> option on the
 * endpoint allows Camel end users to dictate whether they want the asynchronous
 * model_old or not. The option is default <tt>false</tt> which means asynchronous
 * processing is allowed.
 */

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class DefaultEndpoint implements EndpointUriOptions {

    @XlsColumn(columnName = "ENDPOINT NAME")
    protected String endPointName ="ENDPOINT" + "_"+nextEndpointNumber++;;
    @XlsColumn(columnName = "SCHEME")
    protected String scheme = "file";
    @XlsColumn(columnName = "CONTEXT PATH")
    protected String path;
    @XlsColumn(columnName = "OPTIONS")
    protected String uriParams;

    private static int nextEndpointNumber = 0;



    public String toUriQueryParametersString(Map params) {

        //params = new BeanMap(this);
        Set<Map.Entry<Object, Object>> entries = params.entrySet();
        List<String> queryParams = new ArrayList<String>();
        //    TypeConverter converter = getCamelContext().getTypeConverter();

        // Separate URI values from query parameters
        for (Map.Entry<Object, Object> entry : entries) {
            String key = (String) (entry.getKey());
            Object value = entry.getValue();
            if (value instanceof List) {
                for (Object item : (List<?>) value) {
                    if (StringUtils.isNotEmpty(item.toString()))
                        queryParams.add(key + "=" + UnsafeUriCharactersEncoder.encode(item.toString()));
                }
            } else {
                if (StringUtils.isNotEmpty(value.toString()))
                    queryParams.add(key + "=" + UnsafeUriCharactersEncoder.encode(value.toString()));
            }
        }

        Collections.sort(queryParams);
        String q = "";
        for (String entry : queryParams) {
            q += q.length() == 0 ? "" : "&";
            q += entry;
        }
        return q;
    }

    public void createUriParams(Object queryOptions) {
        try {
            uriParams = toUriQueryParametersString(toMap(queryOptions));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void createUriParams() {
        try {
            uriParams = toUriQueryParametersString(toMap(this));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private Map<String, Object> toMap(Object bean) throws Exception {
        Map<String, Object> properties = new HashMap<>();
        for (PropertyDescriptor property : Introspector.getBeanInfo(bean.getClass(), bean.getClass().getSuperclass()).getPropertyDescriptors()) {
            String name = property.getName();
            Object value = property.getReadMethod().invoke(bean);
            if(value!=null) {
                properties.put(name, value);
            }
        }
        return properties;
    }

    public void parseQueryOptions(Object queryOptions)

    {
        try {
            BeanUtils.populate(queryOptions, URISupport.parseQuery(uriParams));
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public String getEndPointName() {
        return "ENDPOINT" + nextEndpointNumber++;
    }

    public void setEndPointName(String endPointName) {
        this.endPointName = endPointName;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getUriParams() {
        return uriParams;
    }

    public void setUriParams(String uriParams) {
        this.uriParams = uriParams;
    }
}



