//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Model;

import java.util.List;

public class TbwServiceConfig
{
    private List<TbwAdapterConfig> tbwAdapters;
    private List<TbwProcessContainerConfig> tbwProcessContainers;

    public List<TbwAdapterConfig> getTbwAdapters() {
        return tbwAdapters;
    }

    public void setTbwAdapters(List<TbwAdapterConfig> tbwAdapters) {
        this.tbwAdapters = tbwAdapters;
    }

    public List<TbwProcessContainerConfig> getTbwProcessContainers() {
        return tbwProcessContainers;
    }

    public void setTbwProcessContainers(List<TbwProcessContainerConfig> tbwProcessContainers) {
        this.tbwProcessContainers = tbwProcessContainers;
    }
}


