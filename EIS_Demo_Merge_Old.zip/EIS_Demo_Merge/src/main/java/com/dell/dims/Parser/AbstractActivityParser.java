package com.dell.dims.Parser;

import com.dell.dims.Model.*;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;
import soa.model.project.OutputProject;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;


public abstract class AbstractActivityParser implements IActivityParser {



}
