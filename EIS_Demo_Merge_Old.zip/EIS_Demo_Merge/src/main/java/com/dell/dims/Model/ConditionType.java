
package com.dell.dims.Model;


public enum ConditionType
{
    always,
    xpath,
    otherwise,
    error
}

