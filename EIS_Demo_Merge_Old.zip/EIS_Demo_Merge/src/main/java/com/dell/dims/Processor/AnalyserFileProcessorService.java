//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;

import com.dell.dims.Model.*;
import com.dell.dims.Parser.TibcoBWProcessLinqParser;

import java.util.List;

public class AnalyserFileProcessorService   implements IFileProcessorService
{
    private String projectDir = new String();
    public AnalyserFileProcessorService() throws Exception {
       // this.projectDir = ConfigurationApp.getProperty(MainClass.ProjectDirectory);
    }

    public void process(String processFileName) throws Exception {
      //  String projectDirectory = ConfigurationApp.getProperty(MainClass.ProjectDirectory);
        String projectDirectory = "";
        TibcoBWProcess tibcoBwProcess = new TibcoBWProcessLinqParser().parse(processFileName);
        writeToFile(processFileName,this.projectDir);

        List<Activity> activities = tibcoBwProcess.getActivities();
        this.processActivities(projectDirectory, activities);
    }

    private static void writeToFile(String processFileName, String outputDir) throws Exception {

        System.out.println("Writ to file #####################");

       /* Console.WriteLine(processFileName);

        file = new StreamWriter(outputDir + "/MyOuput.txt", true);
        try
        {
            {
                file.WriteLine(processFileName);
            }
        }
        finally
        {
            if (file != null)
                Disposable.mkDisposable(file).dispose();

        }
        */
    }

    public void processActivities(String projectDirectory, List<Activity> activities) throws Exception {

        for (Activity activity : activities)
        {
            if (activity.getType() == ActivityType.callProcessActivityType)
            {
                CallProcessActivity callActivity = (CallProcessActivity)activity;
                this.process(projectDirectory + callActivity.getProcessName());
            }
            else if (activity.getType() == ActivityType.criticalSectionGroupActivityType || activity.getType() == ActivityType.loopGroupActivityType)
            {
                GroupActivity groupActivity = (GroupActivity)activity;
                this.processActivities(projectDirectory, groupActivity.getActivities());
            }

        }
    }

}


