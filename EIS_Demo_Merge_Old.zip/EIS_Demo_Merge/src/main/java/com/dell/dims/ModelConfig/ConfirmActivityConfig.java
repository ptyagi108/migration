package com.dell.dims.ModelConfig;

/**
 * Created by Manoj_Mehta on 12/29/2016.
 */
public class ConfirmActivityConfig {

    private String confirmEvent;

    public String getConfirmEvent() {
        return confirmEvent;
    }

    public void setConfirmEvent(String confirmEvent) {
        this.confirmEvent = confirmEvent;
    }
}
