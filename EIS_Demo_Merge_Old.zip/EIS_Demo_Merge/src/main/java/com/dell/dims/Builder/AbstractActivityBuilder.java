package com.dell.dims.Builder;

import com.dell.dims.Model.Activity;

/**
 * Created by Manoj_Mehta on 5/18/2017.
 */
public abstract class AbstractActivityBuilder
{
    private String builderName;

    public abstract String build(Activity activity) throws Exception;
}
