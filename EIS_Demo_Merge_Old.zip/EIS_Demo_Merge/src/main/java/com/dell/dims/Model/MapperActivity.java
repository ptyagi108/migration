package com.dell.dims.Model;

import java.util.List;

public class MapperActivity  extends Activity
{
    public MapperActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public MapperActivity() throws Exception {
    }

    private List<ClassParameter> xsdReference;

    public List<ClassParameter> getXsdReference() {
        return xsdReference;
    }

    public void setXsdReference(List<ClassParameter> xsdReference) {
        this.xsdReference = xsdReference;
    }
}


