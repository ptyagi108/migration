package com.dell.dims.ModelConfig;

import com.dell.dims.Model.ClassParameter;
import com.dell.dims.Model.XmlParseActivity;

import java.util.List;

/**
 * Created by Kriti_Kanodia on 1/3/2017.
 */
public class XmlParseActivityConfig {

private String inputStyle;
private boolean validateOutput;
private String xsdReference;
private List<ClassParameter> term;


    public List<ClassParameter> getTerm() {
        return term;
    }

    public void setTerm(List<ClassParameter> term) {
        this.term = term;
    }

    public String getXsdReference() {
        return xsdReference;
    }

    public void setXsdReference(String xsdReference) {
        this.xsdReference = xsdReference;
    }

    public String getInputStyle() {
        return inputStyle;
    }

    public void setInputStyle(String inputStyle) {
        this.inputStyle = inputStyle;
    }

    public boolean isValidateOutput() {
        return validateOutput;
    }

    public void setValidateOutput(boolean validateOutput) {
        this.validateOutput = validateOutput;
    }


    public Object getConfigAttributes(XmlParseActivity activity) throws Exception {
        this.setInputStyle(activity.getInputStyle());
        this.setValidateOutput(activity.isValidateOutput());
        this.setTerm(activity.getTerm());

        return this;
    }


}
