package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.GetSharedVariableActivity;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

/**
 * Created by Manoj_Mehta on 2/24/2017.
 */
public class GetSharedVariableActivityParser implements  IActivityParser {
    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        GetSharedVariableActivity sharedVariableActivity = new GetSharedVariableActivity();

        String nodeStr= NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .extract("variableConfig", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.variableConfig")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("variableConfig", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.variableConfig")))
                    .asMap();
        }

        sharedVariableActivity.setName(activityMap.get("name"));
        sharedVariableActivity.setType(new ActivityType(activityMap.get("type")));
        sharedVariableActivity.setResourceType(activityMap.get("resourceType"));
        sharedVariableActivity.setVariableConfig(activityMap.get("variableConfig"));
        sharedVariableActivity.setGroupActivity(isGroupActivity);

        return sharedVariableActivity;

    }
}
