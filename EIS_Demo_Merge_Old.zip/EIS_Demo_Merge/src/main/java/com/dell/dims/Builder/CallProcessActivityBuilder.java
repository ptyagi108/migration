package com.dell.dims.Builder;


import com.dell.dims.Model.Activity;
import com.dell.dims.Model.CallProcessActivity;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.QNameUtil;
import com.dell.dims.gop.ProcessDefinition;
import soa.OutputFromTibco.OutputGenerator;

import java.io.File;

public class CallProcessActivityBuilder extends AbstractActivityBuilder
{

    @Override
    public String build(Activity activity) throws Exception {
        System.out.println("-------------Activity Name ::---------"+activity.getName());

        CallProcessActivity callProcessActivity= (CallProcessActivity) activity;
        ProcessDefinition subProcess=callProcessActivity.getSubProcess();

        Activity startActivity=subProcess.getStartActivity();
        Activity endActivity=subProcess.getEndActivity();

        //input Schema
        if(startActivity!=null && startActivity.getInputBindings()!=null )
        {
            String strStartXSD = subProcess.getStartActivity().getInputBindings();
            System.out.println("strStartXSD :\n"+strStartXSD);

            String rootElementName = NodesExtractorUtil.getRootElementName(strStartXSD);
//xmlns:{prefix}=http://xmlns.oracle.com/{project.name}/{composite.name}/{process.name}*/{activity.name}
    //public QNameUtil(String namespaceURI, String localPart, String prefix)


            QNameUtil qname=new QNameUtil("http://xmlns.oracle.com/"+OutputGenerator.projectName+ File.separator+activity.getName()+"_Input","","tns");
            qname.setRootElement(rootElementName);
            qname.setType("xsd");
            qname.setLocation("../Schemas/"+callProcessActivity.getName()+".xsd");

            //capture input xsd in Map
            OutputGenerator.xsdMap.put(qname,strStartXSD);


           // OutputGenerator.xsdMap.putAll();
        }

        if(endActivity!=null && endActivity.getInputBindings()!=null)
        {
            String outputXSD=endActivity.getInputBindings();
            System.out.println("outputXSD :\n"+outputXSD);

            String rootElementName = NodesExtractorUtil.getRootElementName(outputXSD);

            QNameUtil qname=new QNameUtil("http://xmlns.oracle.com/"+OutputGenerator.projectName+ File.separator+activity.getName()+"_Output","","tns");
            qname.setRootElement(rootElementName);
            qname.setType("xsd");
            qname.setLocation("../Schemas/"+callProcessActivity.getName()+".xsd");

            //capture output xsd in Map
            OutputGenerator.xsdMap.put(qname,outputXSD);
        }

        //create Transformation




        return null;
    }

}


