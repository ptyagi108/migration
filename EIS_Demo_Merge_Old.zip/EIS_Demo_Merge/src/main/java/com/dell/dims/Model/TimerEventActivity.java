//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Model;


import java.util.Date;

public class TimerEventActivity  extends Activity
{
    public TimerEventActivity() throws Exception {
    }

    /**
    * Indicates this process should be run only once at the day and time indicated by the Start Time field.
    * If unchecked, the TimeInterval and IntervalUnit fields allow you to specify the frequency of the process.
    * The run once.
    */
    private boolean runOnce;
    private Date startTime = new Date();
    /**
    * Integer indicating the number of units specified in the Interval Unit field
    * The time interval.
    */
    private int timeInterval;

    /**
    * Unit of time to use with the Time Interval field to determine how often to start a new process.
    * The units can be: Millisecond, Second, Minute, Hour, Day, Week, Month, Year.
    * The interval unit.
    */
    private TimerUnit intervalUnit = TimerUnit.Millisecond;

    public boolean isRunOnce() {
        return runOnce;
    }

    public void setRunOnce(boolean runOnce) {
        this.runOnce = runOnce;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public int getTimeInterval() {
        return timeInterval;
    }

    public void setTimeInterval(int timeInterval) {
        this.timeInterval = timeInterval;
    }

    public TimerUnit getIntervalUnit() {
        return intervalUnit;
    }

    public void setIntervalUnit(TimerUnit intervalUnit) {
        this.intervalUnit = intervalUnit;
    }
}


