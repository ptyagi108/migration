package com.dell.dims.Utils;

import com.dell.dims.Model.Activity;
import com.dell.dims.Parser.XslParser;
import com.dell.dims.dto.DimsDTO;
import com.dell.dims.service.DimsServiceImpl;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 1/20/2017.
 */
public class InputBindingExtractor {

    public static Activity extractInputBindingAndParameters(Node node, Activity activity) throws Exception {

        NodeList updateInputBinding=null;
        NodeList childNodes = node.getChildNodes();
        //Activity activity=new Activity();


      if(childNodes.getLength()==1 && childNodes.item(0).getNodeName().equalsIgnoreCase("activity"))//for testing from BuildMain code
      {
        activity=extractInputBindingAndParameters(childNodes.item(0), activity);
      }
      else {
        for (int j = 0; j < childNodes.getLength(); j++) {
          Node chNode = childNodes.item(j);
          if (chNode instanceof Element) {
            String nodeName = chNode.getNodeName();
            if (nodeName.equalsIgnoreCase("inputBindings")) {

                /*    String inputBin=NodesExtractorUtil.nodeToString(chNode);
                    System.out.println("input binding ::"+ inputBin);
*/
              // replace global variables with actual values

              String nodeString = NodesExtractorUtil.nodeToString(chNode);

              //Golbal Variable replacement commented for now

                /*    if (nodeString.contains("$_globalVariables")) {
                        String subStr = nodeString.substring(nodeString.indexOf("$_globalVariables"), nodeString.lastIndexOf('"'));

                        String globVarName = subStr.substring(subStr.lastIndexOf('/')+1, subStr.length());
                        String globVarValue="";

                        //System.out.println("***subStr Input binding :******" + subStr); //$_globalVariables/ns1:GlobalVariables/NewItem/fileExtension

                        //get All global variables list
                        Map glbVariables=GlobalVariablesProvider.getGlobalVariables();

                        if(glbVariables!=null)
                        {
                            if(glbVariables.containsKey(globVarName))
                            {
                                globVarValue= glbVariables.get(globVarName).toString();
                            }
                        }

                        System.out.println("*********************Global VARIABLE :NAME ::"+globVarName +"\n Value ::"+globVarValue);

                        System.out.println("\n\n******String before global variable replaced ::\n"+nodeString +"\n\n");

                        // now replace the global var with actual value

                        String remplacedStr=nodeString.replace(subStr,globVarValue);
                        System.out.println("******String after global variable replaced ::\n"+remplacedStr);

                        // getting Node from string
                        Element inputBindingUpdated=NodesExtractorUtil.getNodeElementFromStr(remplacedStr);

                        updateInputBinding= inputBindingUpdated.getChildNodes();
                        System.out.println("After changes::::::::::::");
                        for (int n = 0; n < updateInputBinding.getLength(); n++) {
                            Node chnode = updateInputBinding.item(n);
                            System.out.println(chnode.getNodeName());
                        }
                    }*/
              activity.setInputBindings(nodeString);
              //activity.setInputBindings(updateInputBinding);
              // activity.setParameters((new XslParser()).parse(activity.getInputBindings()));
            }
          }
        }
      }
        return activity;
    }


}
