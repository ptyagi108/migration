package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;
import com.dell.dims.Router.RoutingRulesDefinition;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 2/6/2017.
 */
public class FileWriteActivityInputBinding extends InputBinding {

    private RoutingRulesDefinition routeRuleDef= new RoutingRulesDefinition();

    @Override
    public InputBinding captureInputBindingAttributes(Activity activity) {
        {
            InputBinding inputBindings=new InputBinding();
            Map<String,Object> mapAttributesList= new HashMap<String,Object>();
            Map<String,Object> mapEndpointOptions= new HashMap<String,Object>();
            String attribute="";
            StringBuilder attributeVal;

            List<ClassParameter> paramList = activity.getParameters();
            if (paramList.size() > 0)
            {
                for (ClassParameter classParam : paramList)
                {
                    //check for fileName
                    attribute="fileName";
                    attributeVal=captureAttributeValue(classParam,attribute);
                    if(attributeVal!=null && attributeVal.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeVal.toString());
                    }

                    //check for textContent
                    attribute="textContent";
                    attributeVal=captureAttributeValue( classParam,attribute);
                    if(attributeVal!=null && attributeVal.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeVal.toString());
                    }

                    //check for addLineSeparator
                    attribute="addLineSeparator";
                    attributeVal=captureAttributeValue(  classParam,attribute);
                    if(attributeVal!=null && attributeVal.length()>0)
                    {
                        mapAttributesList.put(attribute,attributeVal.toString());
                    }
                }
            }
            inputBindings.setSchemeName("FILE");
            inputBindings.setActivityName(activity.getName());
            inputBindings.setActivityType(activity.getType().toString());
            inputBindings.setAttributesList(mapAttributesList);
            inputBindings.setEndPointOptions(mapEndpointOptions);

            return inputBindings;
        }
    }

}

