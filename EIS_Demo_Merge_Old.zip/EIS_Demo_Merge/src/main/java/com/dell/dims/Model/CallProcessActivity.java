//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:14 PM
//

package com.dell.dims.Model;

import com.dell.dims.gop.ProcessDefinition;

public class CallProcessActivity  extends Activity
{
    private String processName;
    private TibcoBWProcess tibcoProcessToCall;
    //it contains subprocess
    private ProcessDefinition subProcess;

    public ProcessDefinition getSubProcess() {
        return subProcess;
    }

    public void setSubProcess(ProcessDefinition subProcess) {
        this.subProcess = subProcess;
    }

    public CallProcessActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public CallProcessActivity() throws Exception {
    }

    public String getProcessName() {
        return processName;
    }

    //public void setProcessName(String processName) {
    //    this.processName = processName;
   // }

    public TibcoBWProcess getTibcoProcessToCall() {
        return tibcoProcessToCall;
    }

    public void setTibcoProcessToCall(TibcoBWProcess tibcoProcessToCall) {
        this.tibcoProcessToCall = tibcoProcessToCall;
    }

    public void setProcessName(String value) throws Exception {
        this.processName = value;
        this.setTibcoProcessToCall(new TibcoBWProcess(value));
    }




}


