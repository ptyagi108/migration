//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Processor;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class SqlRequestToActivityMapper
{
    public static int Counter = 0;
    /**
    * Map that contains the list of SQL request and its corresponding Service
    */
    private static final Map<String,String> sqlToJbdcService = new HashMap<String,String>();
    private static final HashSet<String> jbdcActivityNameAlreadyUsed = new HashSet<String>();
    public static void saveSqlRequest(String sqlRequest, String serviceClassName) throws Exception {
        if (!sqlToJbdcService.containsKey(sqlRequest.toUpperCase()))
        {
            sqlToJbdcService.put(sqlRequest.toUpperCase(), serviceClassName);
        }

    }

    public static boolean containsKey(String sqlRequest) throws Exception {
        return sqlToJbdcService.containsKey(sqlRequest.toUpperCase());
    }

    public static int count() throws Exception {
        return sqlToJbdcService.size();
    }

    public static void clear() throws Exception {
        sqlToJbdcService.clear();
    }

    public static String getJdbcServiceName(String sqlRequest) throws Exception {
        String jdbcServiceName = new String();
        jdbcServiceName=sqlToJbdcService.get(sqlRequest.toUpperCase());
        /*string jdbcServiceName;
        sqlToJbdcService.TryGetValue(sqlRequest.ToUpper(), out jdbcServiceName);*/
        return jdbcServiceName;
    }

    public static void setThisJdbcActivityNameHasUsed(String activityName) throws Exception {
        if (!jbdcActivityNameAlreadyUsed.contains(activityName.toUpperCase()))
        {
            jbdcActivityNameAlreadyUsed.add(activityName.toUpperCase());
        }

    }

    public static boolean isThisJdbcActivityNameUsed(String activityName) throws Exception {
        return jbdcActivityNameAlreadyUsed.contains(activityName.toUpperCase());
    }

    public static void clearActivityHasSet() throws Exception {
        jbdcActivityNameAlreadyUsed.clear();
    }

}


