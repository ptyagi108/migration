package com.dell.dims.Model;

public class SleepActivity  extends Activity
{
    public SleepActivity(String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public SleepActivity() throws Exception {
    }

    private int timerDuration;
    public int getTimerDuration() {
        return timerDuration;
    }

    public void setTimerDuration(int value) {
        timerDuration = value;
    }

}


