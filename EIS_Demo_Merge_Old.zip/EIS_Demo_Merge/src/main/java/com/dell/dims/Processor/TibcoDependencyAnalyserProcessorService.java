package com.dell.dims.Processor;

import com.dell.dims.Model.TbwConfiguration;
import com.dell.dims.Model.TbwProcessConfig;
import com.dell.dims.Model.TbwProcessContainerConfig;
import com.dell.dims.Parser.ConfigurationParser;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class TibcoDependencyAnalyserProcessorService
{
    private final AnalyserFileProcessorService analyserFileProcessorService;
    private ConfigurationParser configurationParser;
    public TibcoDependencyAnalyserProcessorService(AnalyserFileProcessorService analyserFileProcessorService) throws Exception {
        this.analyserFileProcessorService = analyserFileProcessorService;
        this.configurationParser = new ConfigurationParser();
    }

    /**
    * analyse the dependancy of your project via the XML application config file
    * It's usefull when you don't know which process are used or not.
    * What out !! TibcoBW aloow you to have dynamic process loading, in that case the analyser doesn't work
    *
    *  @param processToAnalyseFileName the path of the XML application configuration file
    */
    public void process(String processToAnalyseFileName) throws Exception {
        //this.AnalyseViaTheTbwXmlConfigFile(processToAnalyseFileName);
        this.analyseViaGivenListOfProcess(processToAnalyseFileName);
    }

    private void analyseViaTheTbwXmlConfigFile(String processToAnalyseFileName) throws Exception {
        TbwConfiguration config = this.configurationParser.parse(processToAnalyseFileName);

       // String projectDir = ConfigurationApp.getProperty(MainClass.ProjectDirectory);
        String projectDir = "";
        for (TbwProcessContainerConfig tbwProcessContainerConfig : config.getServicesConfig().getTbwProcessContainers())
        {
            for (TbwProcessConfig processConfig : tbwProcessContainerConfig.getTbwProcessConfigs())
            {
                if (processConfig.isEnabled())
                {
                    this.analyserFileProcessorService.process(projectDir + "/" + processConfig.getName());
                }

            }
        }
    }

    private void analyseViaGivenListOfProcess(String processToAnalyseFileName) throws Exception {

        InputStream is = new FileInputStream(processToAnalyseFileName);
        BufferedReader buf = new BufferedReader(new InputStreamReader(is));
        String line = buf.readLine();
        while(line != null) {
            this.analyserFileProcessorService.process(line);
        }

       /* *//* [UNSUPPORTED] 'var' as type is unsupported "var" *//*
        File file = new System.IO.StreamReader(processToAnalyseFileName);
        while ((line = file.ReadLine()) != null)
        {
            this.analyserFileProcessorService.process(line);
        }
        file.Close(); */
    }

}


