
package com.dell.dims.gop;

import java.io.Serializable;
import java.util.Map;


/**
 * is a jinternal map of variableInstances related to one {@link Token}.
 * Each token has it's own map of variableInstances, thereby creating
 * hierarchy and scoping of process variableInstances.
 */
public class TokenVariableMap extends VariableContainer implements Serializable {

    private static final long serialVersionUID = 1L;

    long id = 0;
    int version = 0;
    protected Token token = null;
    protected ContextInstance contextInstance = null;

    public TokenVariableMap() {
    }

    public TokenVariableMap(Token token, ContextInstance contextInstance) {
        this.token = token;
        this.contextInstance = contextInstance;
    }

    public void addVariableInstance(VariableInstance variableInstance) {
        super.addVariableInstance(variableInstance);
        variableInstance.setTokenVariableMap(this);
    }

    public String toString() {
        return "TokenVariableMap" + ((token != null) && (token.getName() != null) ? "[" + token.getName() + "]" : Integer.toHexString(System.identityHashCode(this)));
    }

    // protected ////////////////////////////////////////////////////////////////

    protected VariableContainer getParentVariableContainer() {
        Token parentToken = token.getParent();
        if (parentToken == null) {
            return null;
        }
        return contextInstance.getTokenVariableMap(parentToken);
    }

    // getters and setters //////////////////////////////////////////////////////

    public ContextInstance getContextInstance() {
        return contextInstance;
    }

    public Token getToken() {
        return token;
    }

    public Map getVariableInstances() {
        return variableInstances;
    }

    // private static final Log log = LogFactory.getLog(TokenVariableMap.class);
}
