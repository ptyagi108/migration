package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileRenameActivity;
import com.dell.dims.Model.FileWriteActivity;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

/**
 * Created by Kriti_Kanodia on 1/16/2017.
 */
public class FileWriteActivityParser implements IActivityParser{


    public Activity parse(String node) throws Exception {
        return null;
    }
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        FileWriteActivity writeActivity = new FileWriteActivity();

        String nodeStr= NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap=null;

        if(isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("encoding", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.encoding")))
                    .extract("compressFile", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.compressFile")))
                    .extract("createMissingDirectories", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.createMissingDirectories")))
                     .extract("append", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.append")))
                    .asMap();
        }
        else
        {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("encoding", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.encoding")))
                    .extract("compressFile", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.compressFile")))
                    .extract("createMissingDirectories", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.createMissingDirectories")))
                    .extract("append", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.append")))
                    .asMap();
        }

        writeActivity.setName(activityMap.get("name"));
        writeActivity.setType(new ActivityType(activityMap.get("type")));
        writeActivity.setEncoding(activityMap.get("encoding"));
        writeActivity.setCompressFile(activityMap.get("compressFile"));
        writeActivity.setCreateMissingDirectories(Boolean.parseBoolean(activityMap.get("createMissingDirectories")));
        writeActivity.setAppend(Boolean.parseBoolean(activityMap.get("append")));
        writeActivity.setGroupActivity(isGroupActivity);

        Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,writeActivity);
        writeActivity.setInputBindings(activity.getInputBindings());
        writeActivity.setParameters(activity.getParameters());



        return writeActivity;
    }

}
