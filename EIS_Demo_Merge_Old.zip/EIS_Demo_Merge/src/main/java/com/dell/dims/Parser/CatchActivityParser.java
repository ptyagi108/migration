package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.CatchActivity;
import com.dell.dims.Model.FTPPutActivity;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static im.nll.data.extractor.Extractors.xpath;

/**
 * Created by Manoj_Mehta on 5/17/2017.
 */
public class CatchActivityParser implements IActivityParser
{
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {

        CatchActivity catchActivity = new CatchActivity();

        String nodeStr = NodesExtractorUtil.nodeToString(node);
        Map<String, String> activityMap = null;

        if (isGroupActivity) {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
                    .extract("catchAll", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.catchAll")))

                    .asMap();
        } else {
            activityMap = Extractors.on(nodeStr)
                    .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                    .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                    .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
                    .extract("catchAll", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.catchAll")))
                    .asMap();
        }

        catchActivity.setName(activityMap.get("name"));
        catchActivity.setType(new ActivityType(activityMap.get("type")));

        catchActivity.setResourceType(activityMap.get("resourceType"));
        catchActivity.setCatchAll(Boolean.parseBoolean(activityMap.get("catchAll")));

        Activity activity = InputBindingExtractor.extractInputBindingAndParameters(node, catchActivity);
        catchActivity.setInputBindings(activity.getInputBindings());
        catchActivity.setParameters(activity.getParameters());

        return catchActivity;
    }
}
