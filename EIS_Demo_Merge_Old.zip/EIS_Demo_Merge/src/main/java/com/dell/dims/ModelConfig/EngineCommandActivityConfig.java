package com.dell.dims.ModelConfig;

/**
 * Created by Manoj_Mehta on 12/29/2016.
 */
public class EngineCommandActivityConfig {

    private String command;

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }
}
