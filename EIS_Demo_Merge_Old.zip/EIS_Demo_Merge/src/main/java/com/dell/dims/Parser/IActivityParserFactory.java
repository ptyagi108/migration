//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Parser;

public interface IActivityParserFactory
{
    IActivityParser getParser(String activityType) throws Exception ;

}


