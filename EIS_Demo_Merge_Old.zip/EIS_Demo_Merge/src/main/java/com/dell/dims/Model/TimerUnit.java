
package com.dell.dims.Model;


public enum TimerUnit
{
    Millisecond,
    Second,
    Minute,
    Hour,
    Day,
    Week,
    Month,
    Year
}

