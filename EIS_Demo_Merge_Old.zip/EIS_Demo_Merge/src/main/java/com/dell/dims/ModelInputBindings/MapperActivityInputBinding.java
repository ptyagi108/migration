package com.dell.dims.ModelInputBindings;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ClassParameter;
import com.dell.dims.ModelInputBindings.Input.TransactionFile.Attribute;
import com.dell.dims.ModelInputBindings.Input.TransactionFile.MapperTransactionFile;
import com.dell.dims.ModelInputBindings.InputBeans.FilesProperties;
import com.dell.dims.ModelInputBindings.InputBeans.ListFiles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 3/1/2017.
 */
public class MapperActivityInputBinding extends InputBinding
{
    InputBinding inputBindings = new InputBinding();
    Map<String, Object> mapAttributesList = new HashMap<String, Object>();
    Map<String, Object> mapEndpointOptions = new HashMap<String, Object>();
    String attribute = "";
    StringBuilder attributeVal;

    @Override
    public InputBinding captureInputBindingAttributes(Activity activity) {
        // check if current process is subprocess
        if (activity.getResourceType().toUpperCase().contains(".subprocess".toUpperCase())) {
            System.out.println("\n*****Subprocess EXIST for*****" + activity.getName() + " Process");
            inputBindings.setSubprocess(true);
        }

        List<ClassParameter> paramList = activity.getParameters();
        if (paramList.size() > 0) {
            for (ClassParameter classParam : paramList) {
                //check for fileId
                attribute = "fileId";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0) {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //check for fileType
                attribute = "fileType";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0) {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //check for trxType
                attribute = "trxType";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0) {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //filecontent
                attribute = "filecontent";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0) {
                    mapAttributesList.put(attribute, attributeVal.toString());
                }

                //version
                attribute = "version";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0) {
                    mapAttributesList.put(attribute, attributeVal.toString());
                    mapEndpointOptions.put(attribute,attributeVal.toString());
                }

                //transaction-file
                attribute = "transaction-file";
                if (classParam.getName().equalsIgnoreCase(attribute)) {
                    MapperTransactionFile transactionFile = new MapperTransactionFile();
                    Map<String, List<Attribute>> fileAttributes = new HashMap<String, List<Attribute>>();
                    Map<String, List<Attribute>> destinationAttributes = new HashMap<String, List<Attribute>>();

                    transactionFile.setTransactionFileName(attribute);
                    Attribute attr = null;

                    //get the nested child properties
                    List<ClassParameter> listParms = classParam.getChildProperties();
                    for (ClassParameter param : listParms) {
                        if (param.getName().equalsIgnoreCase("file")) {
                            List<Attribute> listAttrFile = new ArrayList<Attribute>();

                            List<ClassParameter> fileParams = new ArrayList<ClassParameter>();
                            fileParams=param.getChildProperties();
                            for (ClassParameter chParam : fileParams)
                            {
                                attr = new Attribute();

                                attr.setName(chParam.getName());
                                attr.setValue(chParam.getDefaultValue());

                                listAttrFile.add(attr);

                            }
                            fileAttributes.put(param.getName(), listAttrFile);
                        }

                        //description
                        else if (param.getName().equalsIgnoreCase("description")) {
                            Attribute description = new Attribute();
                            description.setName(param.getName());
                            description.setValue(param.getDefaultValue());

                            transactionFile.setFileDescription(description);
                        }

                        //destination
                        else if (param.getName().equalsIgnoreCase("destination")) {
                            List<ClassParameter> listDestination = param.getChildProperties();

                            List<Attribute> listAttrDest = new ArrayList<Attribute>();
                            for (ClassParameter chParam : listDestination)
                            {
                                attr = new Attribute();
                                attr.setName(chParam.getName());
                                attr.setValue(chParam.getDefaultValue());
                                listAttrDest.add(attr);
                            }
                            destinationAttributes.put(param.getName(), listAttrDest);
                        }
                    }
                    transactionFile.setFileAttributes(fileAttributes);
                    transactionFile.setDestinationAttributes(destinationAttributes);

                    mapAttributesList.put(attribute,transactionFile);
                }

                //rootPath
                attribute = "rootPath";
                attributeVal = captureAttributeValue(classParam, attribute);
                if (attributeVal != null && attributeVal.length() > 0) {
                    mapAttributesList.put(attribute, attributeVal.toString());
                    mapEndpointOptions.put(attribute,attributeVal.toString());
                }

                // chek for attributes such as choose, for each,when
                if(classParam.getName().equalsIgnoreCase("root"))
                {
                    checkForConditionalAttributes(classParam);
                }

                /*attribute="for-each";
                System.out.println("class param :"+classParam.getName());
                if (classParam.getName().equalsIgnoreCase(attribute))
                {
                    //get the nested child properties
                    List<ClassParameter> listParms = classParam.getChildProperties();
                    for (ClassParameter param : listParms) {
                        if (param.getName().equalsIgnoreCase("file"))
                        {

                        }
                    }
                }*/

            }
        }
        inputBindings.setSchemeName("FILE");
        inputBindings.setActivityName(activity.getName());
        inputBindings.setActivityType(activity.getType().toString());
        inputBindings.setAttributesList(mapAttributesList);
        inputBindings.setEndPointOptions(mapEndpointOptions);

        return inputBindings;
    }

    /**
     *Check for conditional options : choose, for-each, when
     * @param classParam
     */
    private void checkForConditionalAttributes(ClassParameter classParam)
    {
        Map<String,String> mapOptions=new HashMap<String, String>();
        StringBuilder valueOptions=new StringBuilder();
        List<ClassParameter> listAttr= classParam.getChildProperties();
        for(ClassParameter param : listAttr)
        {
            if(param.getName().equalsIgnoreCase("for-each"))
            {
                valueOptions.append(param.getName());
                valueOptions.append("\n");
                valueOptions.append(param.getDefaultValue());

                ListFiles listFiles=new ListFiles();
                FilesProperties fileProps=new FilesProperties();

                Map<String,String> variables=new HashMap<String,String>();

                List<ClassParameter> chParams = param.getChildProperties();
                for(ClassParameter variable : chParams)
                {
                    if(variable.getType().equalsIgnoreCase("variable"))
                    {
                        variables.put(variable.getName(), variable.getDefaultValue());
                    }
                    else if(variable.getType().equalsIgnoreCase("if"))
                    {
                        StringBuilder value=new StringBuilder();
                        valueOptions.append("\n");
                        valueOptions.append(variable.getType());
                        valueOptions.append(" "+variable.getSpecialOption());
                        valueOptions.append("\n");

                        for(ClassParameter chParam : variable.getChildProperties())
                        {
                            if(chParam.getName().equalsIgnoreCase("files"))
                            {
                                valueOptions.append("\n");
                                valueOptions.append("[");
                                valueOptions.append(chParam.getName());
                                valueOptions.append("]");
                                valueOptions.append("\n");
                            }

                            // get file attributes
                            fileProps.setTrackingID(captureAttributeValue(chParam,"TrackingID").toString());
                            fileProps.setRequestFilename(captureAttributeValue(chParam,"requestFilename").toString());
                            fileProps.setRequestFilelocation(captureAttributeValue(chParam,"requestFilelocation").toString());
                            fileProps.setFullName(captureAttributeValue(chParam,"fullName").toString());
                            fileProps.setTrxType(captureAttributeValue(chParam,"TrxType").toString());
                            fileProps.setChannel(captureAttributeValue(chParam,"Channel").toString());
                            fileProps.setStatus(captureAttributeValue(chParam,"Status").toString());
                            fileProps.setLastUpdBy(captureAttributeValue(chParam,"LastUpdBy").toString());
                        }
                    }
                }

                listFiles.setFileProperties(fileProps);
                valueOptions.append(listFiles.getVariablesList(fileProps));

                listFiles.setFileLocation(param.getDefaultValue());
                listFiles.setListVariables(variables);
                listFiles.setCondition(valueOptions.toString());

                mapEndpointOptions.put(param.getName(),listFiles);
            }
            else if(param.getName().equalsIgnoreCase("choose"))
            {
                for(ClassParameter chParam : param.getChildProperties())
                {
                    valueOptions.append(chParam.getName()); //when,otherwise
                    valueOptions.append("\n\t");
                    valueOptions.append(chParam.getDefaultValue()); //condition
                    valueOptions.append("\n\t");
                    valueOptions.append(chParam.getSpecialOption());//option
                }
                mapEndpointOptions.put(param.getName(),valueOptions.toString());
            }


        }
    }
}
