
package com.dell.dims.endpoint.uri;

import java.util.Map;

public interface EndpointUriOptions {

    String toUriQueryParametersString(Map params);

}
