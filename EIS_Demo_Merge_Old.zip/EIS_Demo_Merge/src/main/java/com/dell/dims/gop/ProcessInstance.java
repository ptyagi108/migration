
package com.dell.dims.gop;

import com.dell.dims.util.RuntimeDimsException;

import java.io.Serializable;
import java.util.*;

/**
 * is one execution of a {@link ProcessDefinition}.
 * To create a new process execution of a process definition, just use the
 * {@link #ProcessInstance(ProcessDefinition)}.
 */
public class ProcessInstance implements Serializable {

    private static final long serialVersionUID = 1L;

    long id = 0;
    int version = 0;
    protected String key = null;
    protected Date start = null;
    protected Date end = null;
    protected ProcessDefinition processDefinition = null;
    protected Token rootToken = null;
    protected Token superProcessToken = null;
    protected boolean isSuspended = false;
    protected Map instances = null;
    protected Map transientInstances = null;
    protected List runtimeActions = null;
    /**
     * not persisted
     */
    protected List cascadeProcessInstances = null;

    // constructors /////////////////////////////////////////////////////////////

    public ProcessInstance() {
    }

    /**
     * creates a new process instance for the given process definition,
     * puts the root-token (=main path of execution) in the start state
     * and executes the initial node.  In case the initial node is a
     * start-state, it will behave as a wait state.
     * For each of the optional module definitions contained in the
     * {@link ProcessDefinition}, the corresponding module instance
     * will be created.
     *
     * @throws com.dell.dims.util.RuntimeDimsException if processDefinition is null.
     */
    public ProcessInstance(ProcessDefinition processDefinition) {
        this(processDefinition, null, null);
    }

    /**
     * creates a new process instance for the given process definition,
     * puts the root-token (=main path of execution) in the start state
     * and executes the initial node.  In case the initial node is a
     * start-state, it will behave as a wait state.
     * For each of the optional module definitions contained in the
     * {@link ProcessDefinition}, the corresponding module instance
     * will be created.
     *
     * @param variables will be inserted into the context variables
     *                  after the context submodule has been created and before the
     *                  process-start event is fired, which is also before the execution
     *                  of the initial node.
     * @throws com.dell.dims.util.RuntimeDimsException if processDefinition is null.
     */
    public ProcessInstance(ProcessDefinition processDefinition, Map variables) {
        this(processDefinition, variables, null);
    }

    /**
     * creates a new process instance for the given process definition,
     * puts the root-token (=main path of execution) in the start state
     * and executes the initial node.  In case the initial node is a
     * start-state, it will behave as a wait state.
     * For each of the optional module definitions contained in the
     * {@link ProcessDefinition}, the corresponding module instance
     * will be created.
     *
     * @param variables will be inserted into the context variables
     *                  after the context submodule has been created and before the
     *                  process-start event is fired, which is also before the execution
     *                  of the initial node.
     * @throws com.dell.dims.util.RuntimeDimsException if processDefinition is null.
     */
    public ProcessInstance(ProcessDefinition processDefinition, Map variables, String key) {
        if (processDefinition == null)
            throw new RuntimeDimsException("can't create a process instance when processDefinition is null");

        // initialize the members
        this.processDefinition = processDefinition;
        this.rootToken = new Token(this);

        this.key = key;

        // set the variables
        ContextInstance contextInstance = getContextInstance();
        if ((contextInstance != null)
                && (variables != null)
                ) {
            contextInstance.addVariables(variables);
        }

        GopNode initialNode = rootToken.getNode();
        // fire the process start event
        if (initialNode != null) {
            ExecutionContext executionContext = new ExecutionContext(rootToken);
            //  processDefinition.fireEvent(Event.EVENTTYPE_PROCESS_START, executionContext);
            // execute the start node
            //  initialNode.execute(executionContext);
        }
    }


    /**
     * process instance extension for process variableInstances.
     */
    public ContextInstance getContextInstance() {
        return (ContextInstance) getInstance(ContextInstance.class);
    }


    // various information retrieval methods ////////////////////////////////////

    /**
     * tells if this process instance is still active or not.
     */
    public boolean hasEnded() {
        return (end != null);
    }


    /**
     * collects all instances for this process instance.
     */
    public List findAllTokens() {
        List tokens = new ArrayList();
        tokens.add(rootToken);
        rootToken.collectChildrenRecursively(tokens);
        return tokens;
    }

    void addCascadeProcessInstance(ProcessInstance cascadeProcessInstance) {
        if (cascadeProcessInstances == null) {
            cascadeProcessInstances = new ArrayList();
        }
        cascadeProcessInstances.add(cascadeProcessInstance);
    }

    public Collection removeCascadeProcessInstances() {
        Collection removed = cascadeProcessInstances;
        cascadeProcessInstances = null;
        return removed;
    }


    // getters and setters //////////////////////////////////////////////////////

    public long getId() {
        return id;
    }

    public Token getRootToken() {
        return rootToken;
    }

    public Date getStart() {
        return start;
    }

    public Date getEnd() {
        return end;
    }

    public Map getInstances() {
        return instances;
    }

    public ProcessDefinition getProcessDefinition() {
        return processDefinition;
    }

    public Token getSuperProcessToken() {
        return superProcessToken;
    }

    public void setSuperProcessToken(Token superProcessToken) {
        this.superProcessToken = superProcessToken;
    }

    public boolean isSuspended() {
        return isSuspended;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public void setProcessDefinition(ProcessDefinition processDefinition) {
        this.processDefinition = processDefinition;
    }

    public void setRootToken(Token rootToken) {
        this.rootToken = rootToken;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    /**
     * a unique business key
     */
    public String getKey() {
        return key;
    }

    /**
     * set the unique business key
     */
    public void setKey(String key) {
        this.key = key;
    }

    // private static Log log = LogFactory.getLog(ProcessInstance.class);

    /**
     * looks up an optional module instance by its class.
     */
    public ModuleInstance getInstance(Class clazz) {
        ModuleInstance moduleInstance = null;
        if (instances != null) {
            moduleInstance = (ModuleInstance) instances.get(clazz.getName());
        }

        if (moduleInstance == null) {
            if (transientInstances == null) transientInstances = new HashMap();

            // client requested an instance that is not in the map of instances.
            // so we can safely assume that the client wants a transient instance
            moduleInstance = (ModuleInstance) transientInstances.get(clazz.getName());
            if (moduleInstance == null) {
                try {
                    moduleInstance = (ModuleInstance) clazz.newInstance();
                    moduleInstance.setProcessInstance(this);

                } catch (Exception e) {
                    e.printStackTrace();
                    throw new RuntimeDimsException("couldn't instantiate transient module '" + clazz.getName() + "' with the default constructor");
                }
                transientInstances.put(clazz.getName(), moduleInstance);
            }
        }

        return moduleInstance;
    }

}
