package com.dell.dims.ModelConfig;

/**
 * Created by Kriti_Kanodia on 1/3/2017.
 */
public class WriteToLogActivityConfig {

    private String role;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
