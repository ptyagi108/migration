package com.dell.dims.Model;

import java.util.List;

public class TbwProcessContainerConfig
{
    private String name;
    private boolean isEnabled;
    private List<TbwProcessConfig> tbwProcessConfigs;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setEnabled(boolean enabled) {
        isEnabled = enabled;
    }

    public List<TbwProcessConfig> getTbwProcessConfigs() {
        return tbwProcessConfigs;
    }

    public void setTbwProcessConfigs(List<TbwProcessConfig> tbwProcessConfigs) {
        this.tbwProcessConfigs = tbwProcessConfigs;
    }
}


