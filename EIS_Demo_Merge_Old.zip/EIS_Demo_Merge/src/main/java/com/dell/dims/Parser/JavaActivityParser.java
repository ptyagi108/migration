package com.dell.dims.Parser;

import com.dell.dims.Model.*;
import com.dell.dims.ModelConfig.JavaActivityConfig;
import com.dell.dims.Utils.InputBindingExtractor;
import com.dell.dims.Utils.NodesExtractorUtil;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import static im.nll.data.extractor.Extractors.xpath;

public class JavaActivityParser implements IActivityParser
{

  public Activity parse(String node) throws Exception {
    return null;
  }
  public Activity parse(Node node, boolean isGroupActivity) throws Exception {

    JavaActivity javaActivity = new JavaActivity();

    String nodeStr=NodesExtractorUtil.nodeToString(node);
    Map<String, String> activityMap=null;

    if(isGroupActivity) {
      activityMap = Extractors.on(nodeStr)
        .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.name")))
        .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.type")))
        .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.resourceType")))
        .extract("fileName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.fileName")))
        .extract("packageName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.packageName")))
        //  .extract("fullsource", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.group.activity.config.fullsource")))
        .asMap();
    }
    else
    {
      activityMap = Extractors.on(nodeStr)
        .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
        .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
        .extract("resourceType", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.resourceType")))
        .extract("fileName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.fileName")))
        .extract("packageName", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.packageName")))
        .extract("fullsource", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.fullsource")))
        // .extract("outputData", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.config.outputData")))
        .asMap();
    }

    javaActivity.setName(activityMap.get("name"));
    javaActivity.setType(new ActivityType(activityMap.get("type")));
    javaActivity.setResourceType(activityMap.get("resourceType"));
    javaActivity.setFileName(activityMap.get("fileName"));
    javaActivity.setPackageName(activityMap.get("packageName"));
    javaActivity.setFullsource(activityMap.get("fullsource"));
    javaActivity.setGroupActivity(isGroupActivity);

    javaActivity=parseInputOrOutPutData(node,javaActivity);

    Activity activity= InputBindingExtractor.extractInputBindingAndParameters(node,javaActivity);
    javaActivity.setInputBindings(activity.getInputBindings());
    javaActivity.setParameters(activity.getParameters());

    return javaActivity;
  }

  /**
   * Parse Input/Output Data
   * @param node
   * @param javaActivity
   * @return
   * @throws Exception
   */
  private JavaActivity parseInputOrOutPutData(Node node, JavaActivity javaActivity) throws Exception
  {
    NodeList nodeList = node.getChildNodes();

    if(nodeList.getLength()==1 && nodeList.item(0).getNodeName().equalsIgnoreCase("activity"))//for testing from BuildMain code
    {
      javaActivity=parseInputOrOutPutData(nodeList.item(0), javaActivity);
    }
    else
    {
      for(int i=0;i<nodeList.getLength();i++)
      {
        Node inputNode = nodeList.item(i);
        if (inputNode.getNodeName().equalsIgnoreCase("config")) {

          NodeList configChildNode = inputNode.getChildNodes();

          for (int j = 0; j < configChildNode.getLength(); j++) {

            Node configNode = configChildNode.item(j);
            if (configNode.getNodeName().equalsIgnoreCase("outputData")) {
              List<ClassParameter> data = new ArrayList<ClassParameter>();
              data = getInputOrOutputData(configNode);
              javaActivity.setOutputData(data);

            } else if (configNode.getNodeName().equalsIgnoreCase("inputData")) {
              List<ClassParameter> data = new ArrayList<ClassParameter>();
              data = getInputOrOutputData(configNode);
              javaActivity.setInputData(data);

            }
          }
        }
      }
    }
    return javaActivity;
  }

  /**
   *
   * @param node
   * @return
   * @throws Exception
   */
  public List<ClassParameter> getInputOrOutputData(Node node) throws Exception {
    if (node == null)
    {
      return null;
    }

    List<ClassParameter> datas = new ArrayList<ClassParameter>();
    NodeList childNodes= node.getChildNodes();
    for (int j = 0; j < childNodes.getLength(); j++) {
      Node chNode = childNodes.item(j);

      if (chNode instanceof Element) {
        // a child element to process
        Element element = (Element) chNode;
        String nodeName = element.getNodeName();

        ClassParameter classParam=null;
        if (nodeName.equalsIgnoreCase("row")) {

          classParam= new ClassParameter();

          //String nodeSubString = NodesExtractorUtil.nodeToString(node);
          //NodeList rowNodes= NodesExtractorUtil.getChildNode(nodeSubString);

          //child node of row
          NodeList listNode =element.getChildNodes();
          for (int n = 0; n < listNode.getLength(); n++) {

            Node nd = listNode.item(n);
            if(nd.getNodeName().toString().equalsIgnoreCase("fieldName")) {
              classParam.setName(nd.getTextContent());
            }
            else if(nd.getNodeName().toString().equalsIgnoreCase("fieldType")) {
              classParam.setType(nd.getTextContent());
            }
            else if(nd.getNodeName().toString().equalsIgnoreCase("fieldRequired")) {
              classParam.setFieldRequired(nd.getTextContent());
            }
          }
        }
        datas.add(classParam);
      }
    }
    return datas;
  }
}
