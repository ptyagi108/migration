//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:15 PM
//

package com.dell.dims.Parser;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.TimerEventActivity;
import com.dell.dims.Model.TimerUnit;
import com.dell.dims.ModelConfig.TimerEventActivityConfig;
import com.dell.dims.Utils.PropertiesUtil;
import im.nll.data.extractor.Extractors;
import org.w3c.dom.Node;

import java.util.Map;

import static com.dell.dims.Utils.BeanExtractor.extractBean;
import static im.nll.data.extractor.Extractors.xpath;

public class TimerEventActivityParser implements IActivityParser
{
    public Activity parse(String inputElement) throws Exception {
        TimerEventActivity activity = new TimerEventActivity();

        Map<String, String> activityMap = Extractors.on(inputElement)
                .extract("name", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.name")))
                .extract("type", xpath(PropertiesUtil.getPropertyFile().getProperty("ProcessDefinition.activity.type")))
                .asMap();

        activity.setName(activityMap.get("name"));
        activity.setType(new ActivityType(activityMap.get("type")));

        //config
        TimerEventActivityConfig timerConfig = Extractors.on(inputElement)
                .extract("config", extractBean(new TimerEventActivityConfig()))
                .asBean(TimerEventActivityConfig.class);

        activity.setIntervalUnit((TimerUnit)Enum.valueOf(TimerUnit.class,timerConfig.getFrequencyIndex().toString()));
        activity.setRunOnce(timerConfig.isFrequency());
        activity.setTimeInterval(timerConfig.getTimeInterval());
       // activity.setStartTime(new Date(1970,1,1));
        activity.setStartTime(timerConfig.getStartTime());


        /*
        configElement = inputElement.Element("config");
        activity.setIntervalUnit((TimerUnit)Enum.Parse(TimerUnit.class, XElementParserUtils.GetStringValue(configElement.Element("FrequencyIndex"))));
        activity.setRunOnce(XElementParserUtils.GetBoolValue(configElement.Element("Frequency")));
        activity.setTimeInterval(XElementParserUtils.GetIntValue(configElement.Element("TimeInterval")));
        activity.setStartTime(new DateTime(1970, 1, 1));
        activity.setStartTime(activity.getStartTime().AddMilliseconds(double.Parse(XElementParserUtils.GetStringValue(configElement.Element("StartTime")))));
        */
        return activity;
    }

    @Override
    public Activity parse(Node node, boolean isGroupActivity) throws Exception {
        return null;
    }
}
/**
 * xml = "<pd:activity name=\"GetUndlCurrency\" xmlns:pd=\"http://xmlns.tibco.com/bw/process/2003\" xmlns:xsl=\"http://w3.org/1999/XSL/Transform\">\n" +
 "<pd:type>com.tibco.plugin.timer.TimerEventSource</pd:type>\n" +
 "<config>\n" +
 "\t<FrequencyIndex>Minute</FrequencyIndex>\n" +
 "\t<Frequency>false</Frequency>\n" +
 "\t<TimeInterval>10</TimeInterval>\n" +
 "\t<StartTime>86400000</StartTime>\n" +
 "</config>\n" +
 "</pd:activity>";
 */

