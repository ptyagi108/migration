package com.dell.dims.ModelConfig;

import com.dell.dims.Model.Activity;
import com.dell.dims.Model.ActivityType;
import com.dell.dims.Model.FileCopyActivity;

/**
 * Created by Manoj Mehta
 */
public class FileCopyActivityConfig {

    private boolean overwrite;

    public boolean isOverwrite() {
        return overwrite;
    }

    public void setOverwrite(boolean overwrite) {
        this.overwrite = overwrite;
    }

    public Object getConfigAttributes(FileCopyActivity activity) throws Exception {
        this.setOverwrite(activity.isOverwrite());
        return this;
    }

}
