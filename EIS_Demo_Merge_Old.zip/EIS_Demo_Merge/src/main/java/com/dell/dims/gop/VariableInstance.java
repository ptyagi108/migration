
package com.dell.dims.gop;

import com.dell.dims.util.RuntimeDimsException;

import java.io.Serializable;

/**
 * is a internal class that serves as a base class for classes
 * that store variable values in the database.
 */
public abstract class VariableInstance implements Serializable {

    private static final long serialVersionUID = 1L;

    long id = 0;
    int version = 0;
    protected String name = null;
    protected Token token = null;
    protected TokenVariableMap tokenVariableMap = null;
    protected ProcessInstance processInstance = null;
    protected Converter converter = null;
    protected Object valueCache = null;
    protected boolean isValueCached = false;

    // constructors /////////////////////////////////////////////////////////////

    public VariableInstance() {
    }

    public static VariableInstance create(Token token,
                                          String name,
                                          Object value) {

        VariableInstance variableInstance = null;
        if (value == null) {
            variableInstance = new NullInstance();
        } else {
            variableInstance = createVariableInstance(value);
        }

        variableInstance.token = token;
        variableInstance.name = name;
        variableInstance.processInstance = (token != null ? token.getProcessInstance() : null);

        variableInstance.setValue(value);
        return variableInstance;
    }

    public static VariableInstance createVariableInstance(Object value) {
        return newVariableInstance();
    }

    public static VariableInstance newVariableInstance() {
        VariableInstance variableInstance = null;
        Class variableInstanceClass = null;
        try {
            variableInstance = (VariableInstance) variableInstanceClass.newInstance();
            //variableInstance.converter = converter;
        } catch (Exception e) {
            throw new RuntimeDimsException("couldn't instantiate variable instance class '" + variableInstanceClass.getName() + "'");
        }
        return variableInstance;
    }

    // abstract methods /////////////////////////////////////////////////////////

    /**
     * is true if this variable-instance supports the given value, false otherwise.
     */
    public abstract boolean isStorable(Object value);

    /**
     * is the value, stored by this variable instance.
     */
    protected abstract Object getObject();

    /**
     * stores the value in this variable instance.
     */
    protected abstract void setObject(Object value);


    public void setValue(Object value) {
        valueCache = value;
        isValueCached = true;

        if (converter != null) {
            if (!converter.supports(value)) {
                throw new RuntimeDimsException("the converter '" + converter.getClass().getName() + "' in variable instance '" + this.getClass().getName() + "' does not support values of type '" + value.getClass().getName() + "'.  to change the type of a variable, you have to delete it first");
            }
            value = converter.convert(value);
        }
        if ((value != null)
                && (!this.isStorable(value))) {
            throw new RuntimeDimsException("variable instance '" + this.getClass().getName() + "' does not support values of type '" + value.getClass().getName() + "'.  to change the type of a variable, you have to delete it first");
        }
        setObject(value);
    }

    public Object getValue() {
        if (isValueCached) {
            return valueCache;
        }
        Object value = getObject();
        if ((value != null)
                && (converter != null)) {
            value = converter.revert(value);
            valueCache = value;
            isValueCached = true;
        }
        return value;
    }

    public void removeReferences() {
        tokenVariableMap = null;
        token = null;
        processInstance = null;
    }

    // utility methods /////////////////////////////////////////////////////////

    public String toString() {
        return "${" + name + "}";
    }

    // getters and setters //////////////////////////////////////////////////////

    public String getName() {
        return name;
    }

    public ProcessInstance getProcessInstance() {
        return processInstance;
    }

    public Token getToken() {
        return token;
    }

    public void setTokenVariableMap(TokenVariableMap tokenVariableMap) {
        this.tokenVariableMap = tokenVariableMap;
    }

    // private static Log log = LogFactory.getLog(VariableInstance.class);
}
