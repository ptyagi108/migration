//
// Translated by CS2J (http://www.cs2j.com): 12/23/2016 12:19:13 PM
//

package com.dell.dims.Builder;

import com.dell.dims.Model.Activity;

public class XsdBuilder extends AbstractActivityBuilder
{
  //  private static final String HttpwwwworgXmlSchema = "http://www.w3.org/2001/XMLSchema";
    private static final String Schema = "schema";
    private static final String Xsd = "xsd";
   // private static final ILog Log = LogManager.GetLogger(XsdBuilder.class);
   // private final XsdParser xsdParser;
    public XsdBuilder() throws Exception {
        //this.xsdParser = new XsdParser();
    }

    @Override
    public String build(Activity activity) {
        return null;
    }
}


