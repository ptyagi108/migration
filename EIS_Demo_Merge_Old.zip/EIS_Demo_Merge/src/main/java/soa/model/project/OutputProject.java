package soa.model.project;

import com.dell.dims.Parser.Utils.FileUtility;
import com.sun.org.apache.bcel.internal.classfile.Utility;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
//import java.util.logging.Level;
//import java.util.logging.Logger;

public class OutputProject

{
   private  String projectName;
   private   String projectFolder;
   private  String compositeFileName;
   private  String processName;


    public  String getOutputProjectFullPath()
    {
        return this.projectFolder + File.separator + projectName;
    }

    public  void createProjectDirectoriesStructure()
    {

      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/Adapters");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/BPEL");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/DVM");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/Events");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/SCA-INF");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/Spring");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/testsuites");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/Transformations");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/WSDLs");
      FileUtility.createDirectories(getOutputProjectFullPath()+ File.separator +"SOA/Schemas");
      }

  public  String getProjectName() {
    return projectName;
  }

  public  void setProjectName(String projectName) {
    this.projectName = projectName;
  }

  public  String getProjectFolder() {
    return projectFolder;
  }

  public  void setProjectFolder(String projectFolder) {
    this.projectFolder = projectFolder;
  }

  public  String getCompositeFileName() {
    return compositeFileName;
  }

  public  void setCompositeFileName(String compositeFileName) {
    this.compositeFileName = compositeFileName;
  }

  public  String getProcessName() {
    return processName;
  }

  public  void setProcessName(String processName) {
    this.processName = processName;
  }
}
