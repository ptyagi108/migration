package soa;

import com.dell.dims.Model.GlobalVariable;
import soa.model.Component;
import soa.model.adapter.AdapterOperation;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

/**
 * Created by Manoj_Mehta on 5/5/2017.
 */
public class BPELGenarator
{

    /**
     * @param processName
     * @param component
     * @param globalVariables
     * @return
     */
    public String generateBPEL(String processName, Component component, Map<String, ArrayList<GlobalVariable>> globalVariables)
    {
        int transformationCount=0;
        int assignCount=0;



        StringBuilder buffer = new StringBuilder("");
        buffer.append("<?xml version = \"1.0\" encoding = \"UTF-8\" ?>\n");
        buffer.append("<process name=\""+processName+"\"\n");
        buffer.append("\t\t targetNamespace=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/"+processName+"\"\n");
        buffer.append("\t\t xmlns=\"http://docs.oasis-open.org/wsbpel/2.0/process/executable\"\n");
        buffer.append("\t\t xmlns:client=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/"+processName+"\"\n");
        buffer.append("\t\t xmlns:ora=\"http://schemas.oracle.com/xpath/extension\"\n");
        buffer.append("\t\t xmlns:ui=\"http://xmlns.oracle.com/soa/designer\"\n");
        buffer.append("\t\t xmlns:bpelx=\"http://schemas.oracle.com/bpel/extension\"\n");
        buffer.append("\t\t xmlns:bpel=\"http://docs.oasis-open.org/wsbpel/2.0/process/executable\"");

        buffer.append("\t\txmlns:ns1=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/GlobalVariable\"");
        buffer.append("\t\txmlns:ns2=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/ListFiles_Input\"");
        buffer.append("\t\txmlns:ns3=\"http://redstack.com/\" xmlns:ns5=\"http://listFiles.CommonProcesses/\"");
        buffer.append("\t\txmlns:oraext=\"http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc\"");
        buffer.append("\t\txmlns:bpm=\"http://xmlns.oracle.com/bpmn20/extensions\"");
        buffer.append("\t\txmlns:xp20=\"http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20\"");
        buffer.append("\t\txmlns:ess=\"http://xmlns.oracle.com/scheduler\" xmlns:hwf=\"http://xmlns.oracle.com/bpel/workflow/xpath\"");
        buffer.append("\t\txmlns:xref=\"http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions\"");
        buffer.append("\t\txmlns:dvm=\"http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue\"");

        buffer.append("\t\txmlns:bpws=\"http://schemas.xmlsoap.org/ws/2003/03/business-process/\"");
        buffer.append("\t\txmlns:xdk=\"http://schemas.oracle.com/bpel/extension/xpath/function/xdk\"");
        buffer.append("\t\txmlns:ids=\"http://xmlns.oracle.com/bpel/services/IdentityService/xpath\"");
        buffer.append("\t\txmlns:ldap=\"http://schemas.oracle.com/xpath/extension/ldap\">");
        buffer.append("\t\t");
        buffer.append("\t\t");

      /*  if(component.getComponentNames()!=null)
        {
            int counter = 0;
            for (String compName : component.getComponentNames())
            {
                if(!compName.equalsIgnoreCase(processName))
                {
                    counter++;
                    buffer.append("\n \t\t xmlns:ns" + counter + "=\"http://xmlns.oracle.com/pcbpel/adapter/file/SOAApplicationTest/FilePoller/" + compName + "\"");
                }
            }
        }*/

        buffer.append(">\n");
        buffer.append(" <import namespace=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/ListFiles\"\n" +
                        "\t\t location=\"../SCA-INF/src/xsd/ListFiles.xsd\" importType=\"http://www.w3.org/2001/XMLSchema\"/>\n");

        buffer.append("<import namespace=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/"+processName+"\"\n" +
                "\t\t location=\"../Schemas/"+processName+".xsd\" importType=\"http://www.w3.org/2001/XMLSchema\"/>");

        buffer.append("<import namespace=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/CheckFileInPath\" location=\"../Schemas/CheckFileInPath.xsd\"\n" +
                "\t\t importType=\"http://www.w3.org/2001/XMLSchema\"/>");

        buffer.append("<import namespace=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/GlobalVariable\"\n" +
                "\t\tlocation=\"../Schemas/GlobalVariable.xsd\" importType=\"http://www.w3.org/2001/XMLSchema\"/>\n");

        buffer.append("<import ui:processWSDL=\"true\" namespace=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/BPELProcess1\" location=\"../WSDLs/BPELProcess1.wsdl\" importType=\"http://schemas.xmlsoap.org/wsdl/\"/>\n");

        buffer.append("    <import namespace=\"http://xmlns.oracle.com/IESN_BatchFileAdapter_27XApplication1/Test/GlobalVariable\"\n" +
                      "\t\t location=\"../Schemas/GlobalVariable.xsd\" importType=\"http://www.w3.org/2001/XMLSchema\"/>");
        buffer.append("<import location=\"oracle.xml.parser.v2.XMLElement\" importType=\"http://schemas.oracle.com/bpel/extension/java\"/>\n");

        buffer.append("<import location=\"CommonProcesses.listFiles.listFilesInFolders\" importType=\"http://schemas.oracle.com/bpel/extension/java\"/>\n");

        buffer.append(
                " \n\n <!--   PARTNERLINKS        \n" +
                        "        List of services participating in this BPEL process --> \n");

        buffer.append(" <partnerLinks>\n");

        buffer.append("<!-- \n" +
                "The 'client' role represents the requester of this service. It is  used for callback. The location and correlation information associated with the client role are automatically set using WS-Addressing.-->\n");

        //   buffer.append("\t\t <partnerLink name=\""+processName.toLowerCase()+"_client\"" + " partnerLinkType=\"client:"+processName+"\" myRole=\""+processName+"Provider"+"\"/>\n");
        //other existing components
        if(component.getComponentNames()!=null)
        {
            int counter=0;
            for(String compName:component.getComponentNames())
            {   counter++;
                String operation= AdapterOperation.getOperationType(compName);
                String role="";
                if(compName.equalsIgnoreCase(processName))
                {
                    role=" myRole=\""+processName+"Provider\" partnerRole=\""+processName+"Requester\"";

                    buffer.append("\t\t <partnerLink name=\"" + processName.toLowerCase()+"_client" + "\"" + " partnerLinkType=\"client:"+ processName + "\"" + role + "/>\n");
                }
                else
                {
                    //buffer.append("\t\t <partnerLink name=\"" + compName + "\"" + " partnerLinkType=\"ns" + counter + ":" + operation + "_plt\" " + role + "/>\n");
                    buffer.append("<partnerLink name=\""+compName+"\" partnerLinkType=\"ns4:"+compName+"\" partnerRole=\"IlistFilesInFolders\"/>");
                }
            }

            /**
             * <partnerLink name="bpelprocess1_client" partnerLinkType="client:BPELProcess1" myRole="BPELProcess1Provider" partnerRole="BPELProcess1Requester"/>
             <partnerLink name="listFilesInFolders.test" partnerLinkType="ns4:listFilesInFolders.test" partnerRole="IlistFilesInFolders"/>
             *
             */
        }
        buffer.append("</partnerLinks>\n");

        //******************************************************* Define Global Variables here ***************************//
        buffer.append("<variables>\n");

        /**
         <!-- Reference to the message that will be sent back to the requester during callback -->
         <variable name="Start" messageType="client:BPELProcess1ResponseMessage"/>
         <variable name="_globalVariables" element="ns1:globalVariables"/>
         <variable name="InFolders_input" element="ns2:javaCodeActivityInput"/>
         <variable name="InFolder" element="ns2:javaCodeActivityOutput"/>
         */
        buffer.append(" <!-- input -->\n");
        buffer.append("\t\t <variable name=\"inputVariable\" messageType=\"client:"+processName+"RequestMessage\"/>\n");

        buffer.append(" <!-- output -->\n");
        buffer.append(" <variable name=\"empty\" element=\"client:empty\"/>");
        buffer.append("\t\t <variable name=\"Start\" messageType=\"client:"+processName+"ResponseMessage\"/>\n");
        buffer.append("<variable name=\"_globalVariables\" element=\"ns1:GlobalVariables\"/>\n"); //
        buffer.append("<variable name=\"listFiles\" element=\"ns2:javaCodeActivityInput\"/>\n");
        buffer.append("<variable name=\"checkFileInPath\" element=\"ns8:root\"/>\n");

        buffer.append("</variables>\n");


        buffer.append("    <!--  ORCHESTRATION LOGIC                                               \n" +
                " Set of activities coordinating the flow of messages across the services integrated within this business process -->\n");

        buffer.append("\t<sequence name=\"main\">\n");
        buffer.append("\t\t<!-- Receive input from requestor. (Note: This maps to operation defined in "+processName+"+.wsdl) -->\n");
        buffer.append("\t\t<receive name=\"receiveInput\"");
        buffer.append(" partnerLink=\""+processName+"_client\"");
        buffer.append(" portType=\"client:" +processName+"\"");
        buffer.append(" operation=\"process\"");
        buffer.append(" variable=\"inputVariable\" createInstance=\"yes\"/>\n");
        //need DFyanamic values

        //get Input for FileAdapter
        String variableCategory="FileAdapter";
        ArrayList<GlobalVariable> listVariable=globalVariables.get(variableCategory);
        if(listVariable!=null)
        {
            for(GlobalVariable objVar : listVariable)
            {
                String toValue="";
                String fromValue="";
                assignCount++;
                buffer.append("<assign name=\"Assign"+ assignCount +"\">\n");
                if(objVar.getName().equalsIgnoreCase("PollFolder"))
                {
                    toValue="$_globalVariables"+ File.separator+"ns1:"+variableCategory+File.separator+"ns1:PollFolder";
                    fromValue=objVar.getValue();

                    buffer.append("\t\t<copy>\n");
                    buffer.append("\t\t\t<from><literal>"+fromValue+"</literal></from>\n");
                    buffer.append("\t\t\t<to expressionLanguage=\"urn:oasis:names:tc:wsbpel:2.0:sublang:xpath1.0\">"+toValue+"</to>\n");
                    buffer.append("\t\t</copy>\n");

                }
                else if(objVar.getName().equalsIgnoreCase("fileExtensions"))
                {
                    toValue="$_globalVariables"+ File.separator+"ns1:"+variableCategory+File.separator+"ns1:fileExtensions";
                    fromValue=objVar.getValue();

                   // buffer.append("<assign name=\"Assign"+ count +"\">\n");

                    buffer.append("\t\t<copy>\n");
                    buffer.append("\t\t\t<from><literal>"+fromValue+"</literal></from>\n");
                    buffer.append("\t\t\t<to expressionLanguage=\"urn:oasis:names:tc:wsbpel:2.0:sublang:xpath1.0\">"+toValue+"</to>\n");
                    buffer.append("\t\t</copy>\n");
                }

                buffer.append("</assign>\n");
            }
        }

        //scope 1
        buffer.append("<scope name=\"Scope1\">\n");

        buffer.append("\t<variables>");
        buffer.append("\t\t<variable name=\"InFolders_input\" element=\"ns2:javaCodeActivityInput\"/>");
        buffer.append("\t\t<variable name=\"InFolders\" element=\"ns2:javaCodeActivityOutput\"/>");
        buffer.append("\t\t<variable name=\"Invoke1_invoke_InputVariable\" messageType=\"ns5:invokeInput\"/>");
        buffer.append("\t\t<variable name=\"Invoke1_invoke_OutputVariable\" messageType=\"ns5:invokeOutput\"/>");
        buffer.append("\t\t<variable name=\"listFiles\" element=\"ns2:javaCodeActivityOutput\"/>");
        buffer.append("\t\t<variable name=\"checkFileInPath\" element=\"ns8:root\"/>");
        buffer.append("\t\t<variable name=\"Start\" element=\"ns2:root\"/>");

        buffer.append("\t</variables>");

        //Transformation1
        buffer.append("<assign name=\"Transformation"+transformationCount+"\">\n" +
                "            <bpelx:annotation>\n" +
                "                <bpelx:pattern patternName=\"bpelx:transformation\"></bpelx:pattern>\n" +
                "            </bpelx:annotation>\n" +
                "            <copy>\n" +
                "                <from>ora:doXSLTransformForDoc(\"../Transformations/Transformation_1.xsl\", $empty, \"_globalVariables\", $_globalVariables)</from>\n" +
                "                  <to variable=\"Start\"/>\n" +
                "            </copy>\n" +
                "        </assign>");

        //Transformation2
        transformationCount++;
        buffer.append("<assign name=\"Transformation"+transformationCount+"\">\n" +
                "            <bpelx:annotation>\n" +
                "                <bpelx:pattern patternName=\"bpelx:transformation\"></bpelx:pattern>\n" +
                "            </bpelx:annotation>\n" +
                "            <copy>\n" +
                "                <from>ora:doXSLTransformForDoc(\"../Transformations/Transformation_2.xsl\", $empty, \"Start\", $Start)</from>\n" +
                "                  <to variable=\"InFolders_input\"/>\n" +
                "            </copy>\n" +
                "        </assign>");

        //ASSIGN 2sds
        assignCount++;
        buffer.append(" <assign name=\"Assign"+assignCount+"\">");
        buffer.append(" <copy>");
        buffer.append("\t <from>$Invoke1_invoke_InputVariable.parameters/arg0</from>");
        buffer.append("\t <to expressionLanguage=\"urn:oasis:names:tc:wsbpel:2.0:sublang:xpath1.0\">$InFolderss_input</to>");
        buffer.append(" <copy>");
        buffer.append("/assign");


        buffer.append(" <invoke name=\"Invoke1\" partnerLink=\"listFilesInFolders.test\" portType=\"ns5:IlistFilesInFolders\"\n" +
                "                        operation=\"invoke\" inputVariable=\"Invoke1_invoke_InputVariable\"\n" +
                "                        outputVariable=\"Invoke1_invoke_OutputVariable\" bpelx:invokeAsDetail=\"no\"/>");

        assignCount++;
        buffer.append("<assign name=\"Assign"+assignCount+"\">\n" +
                "                    <copy>\n" +
                "                        <from>$Invoke1_invoke_OutputVariable.parameters/return</from>\n" +
                "                        <to expressionLanguage=\"urn:oasis:names:tc:wsbpel:2.0:sublang:xpath1.0\">$InFolders</to>\n" +
                "                    </copy>\n" +
                "                </assign>");

        buffer.append("\n <!--Asynchronous callback to the requester. (Note: the callback location and correlation id is transparently handled using WS-addressing.)-->\n");

        // add new
        buffer.append("\t\t<invoke name=\"callbackClient\" partnerLink=\""+processName+"_client\" ");
        buffer.append(" portType=\"client:"+processName+"Callback\"" );
        buffer.append(" operation=\"processResponse\" inputVariable=\"InFolder\" bpelx:invokeAsDetail=\"no\"/>\n");
        buffer.append("\t</sequence>\n");
        buffer.append("</process>");
        return buffer.toString();
    }
}
