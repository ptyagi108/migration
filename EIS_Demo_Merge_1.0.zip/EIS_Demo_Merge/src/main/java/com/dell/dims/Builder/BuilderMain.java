/*
package com.dell.dims.Builder;

import com.dell.dims.Builder.Utils.GenericBuilder;
import com.dell.dims.Model.Activity;
import com.dell.dims.Model.*;
import com.dell.dims.Model.bpel.*;
import com.dell.dims.Model.bpel.Process;
import com.dell.dims.Parser.CallProcessActivityParser;
import com.dell.dims.Parser.GlobalVariableParser;
import com.dell.dims.Parser.JavaActivityParser;
import com.dell.dims.Parser.Utils.FileUtility;
import com.dell.dims.Utils.PropertiesUtil;
import com.dell.dims.Utils.XSDUtils;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import soa.model.project.OutputProject;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.util.*;

*/
/**
 * Created by Pramod_Kumar_Tyagi on 5/31/2017.
 *//*


public class BuilderMain {

    private static Configuration cfg;
    private static Stack<TbwProcess> processStack= new Stack<>();
    private static Stack<Scope> scopeStack=new Stack<>();
    private static int prefixCounter;
    private static Process bpelProcess;
    private static OutputProject outputProject =new OutputProject();
    private static Map ftlMap =new HashMap();
    // private static List<Variable> globalProcessData = new ArrayList<>();

    static void init() throws Exception {
//This should be main process name fetched from tibco
        addNewProcessToStack(new TbwProcess("inBoundBatchFileAdapter"));

        // Create your Configuration instance, and specify if up to what FreeMarker
// version (here 2.3.25) do you want to apply the fixes that are not 100%
// backward-compatible. See the Configuration JavaDoc for details.
        setCfg(new Configuration(Configuration.VERSION_2_3_25));

        // Specify the source where the template files come from. Here I set a
// plain directory for it, but non-file-system sources are possible too:

        File file = new File(BuilderMain.class.getClassLoader().getResource("templates").getFile());
        getCfg().setDirectoryForTemplateLoading(file);

// Set the preferred charset template files are stored in. UTF-8 is
// a good choice in most applications:
        getCfg().setDefaultEncoding("UTF-8");

// Sets how errors will appear.
// During web page *development* TemplateExceptionHandler.HTML_DEBUG_HANDLER is better.
        getCfg().setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

// Don't log exceptions inside FreeMarker that it will thrown at you anyway:
        getCfg().setLogTemplateExceptions(false);

        InitializeOutputProject();
        bpelProcess=createBpelProcess();
    }

    public static void main(String[] args) {
        try {
            init();
            PropertiesUtil.setProps(PropertiesUtil.getPropertyFile("tibco.properties"));
            GlobalVariableParser parser = new GlobalVariableParser();
            GlobalVariablesRepository repository = parser.parseVariable("C:\\Tibco2OracleSOA\\IESN_BatchFileAdapter_27X\\defaultVars");
            createGlobalVariablesXSD(repository);
            createGlobalVariablesDVM(repository);//in GLOBAL BUILDER
            ExtendedQName xqname_global_variable = createGlobalVariable();

            final Variable variable_global = createBpelVariable(xqname_global_variable, "_globalVariables");
            addVariableToBpelProcess(variable_global);

            final Import tImport = createImport(xqname_global_variable);
            addImportToBpelProcess(tImport);
            //add Global Variables, Empty Variable and Process Context to a global list accessable from all process.
            addVariableToGlobalProcessData(variable_global);
            //create empty variable

            ExtendedQName xqname_empty = createEmptyVariable();
            final Variable variable_empty = createBpelVariable(xqname_empty, "empty");
            addVariableToBpelProcess(variable_empty);
            //Add empty variable to bpel namespaces and imports
            final Import import_empty = createImport(xqname_empty);
            addImportToBpelProcess(import_empty);

            //add empty variable to global data list
            addVariableToGlobalProcessData(variable_empty);
            final Scope scope_main = createScope("main");
            addScopeToStack(scope_main);
            addMainScopeToBpelProcess(scope_main);

            Assign assign_global = createAssign("assign_global_variables");

            for (GlobalVariables globalVariables : repository.getGlobalVariables()) {

                for (GlobalVariable globalVariable : globalVariables.getGlobalVariables()) {
                    String to=globalVariable.getXpath();
                    String from = "dvm:lookupValue(\"DVM/" + outputProject.getProcessName() + "/GlobalVariables.dvm\",\"Name\"," + globalVariable.getCategory() + "_" + globalVariable.getName() + ",\"Value\",\"\")";
                    Copy copy = createCopy(from,to);
                    assign_global.getCopyOrExtensionAssignOperation().add(copy);
                }
            }
            AddActivityToCurrentSequence(assign_global);
            //   ftlMap.put("assign", assign_global);
            // String bpel = processTemplate(ftlMap, "bpel_imports.ftl");

            // FileUtility.writeFile(getFilePathToWrite("BPEL", getCurrentProcess()), outputProject.getProcessName() + ".bpel", bpel, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            //  variable.setName("_globalVariables");
            //  variable.setElement(xqname);
            //   bpelProcess.getVariables().getVariable().add(variable);
            //   final Sequence sequence = factory.createSequence();
            //    sequence.setName("main");
            //   sequence.setSources();
            //    String bpel = processTemplate(ftlMap,"bpel_imports.ftl");
            //   FileUtility.writeFile(project.getOutputProjectFullPath()+ File.separator +"SOA"+ File.separator +"BPEL",project.getProcessName()+".bpel",bpel,  StandardOpenOption.CREATE, StandardOpenOption.APPEND);

//For Every Activity First we have to get input and output schema for the activity.
// If the Activity Type is CallProcessActivity , its input schema is defined within <startType> tags of the subprocess and output schema is defined within  <endType> tag
            //  of the subprocess
            //The input schema is saved in file named  Activityname_input.xsd and output schema is saved in file Activityname_output.xsd...with targetnamespace as
            // targetNamespace="http://xmlns.oracle.com/${application.projectName}/${application.compositeFileName}/$(processName}/${subprocessName}/${activityName}"
//for list files input schema is
      */
/*

       <xsd:element name="ftlMap">
            <xsd:complexType>
                <xsd:sequence>
                    <xsd:element name="rootPath" type="xsd:string"/>
                    <xsd:element name="fileExtensions" type="xsd:string" minOccurs="0" maxOccurs="unbounded"/>
                </xsd:sequence>
            </xsd:complexType>
        </xsd:element>


       *//*

//and output schema is
      */
/*
       <xsd:element name="ftlMap">
            <xsd:complexType>
                <xsd:sequence>
                    <xsd:element name="fileNames" type="xsd:string" minOccurs="0" maxOccurs="unbounded"/>
                </xsd:sequence>
            </xsd:complexType>
        </xsd:element>

       *//*


            //A new process and scope is created for every CallProcessActivity with same name as subprocess
            // TibcoBWProcess listFiles_process = new TibcoBWProcess("listFiles");
            //  listFiles_process.setParentProcess(getCurrentProcess());
            // final Scope scope_listFiles = factory.createScope("listFiles");
//
            //final Sequence sequence_listFiles = factory.createSequence();
            //  scope_listFiles.setSequence(sequence_listFiles);
            String xml = "<activity name=\"listFiles\">" +
                    "            <type>com.tibco.pe.core.CallProcessActivity</type>" +
                    "            <resourceType>ae.process.subprocess</resourceType>" +
                    "            <x>220</x>" +
                    "            <y>381</y>" +
                    "            <config>" +
                    "                <processName>/CommonProcesses/listFiles.process</processName>" +
                    "            </config>" +
                    "            <inputBindings>" +

                    "                    <rootPath>" +
                    "                        <value-of select=\"$_globalVariables/ns1:GlobalVariables/FileAdapter/PollFolder\"/>" +
                    "                    </rootPath>" +
                    "                    <for-each select=\"tib:tokenize($_globalVariables/ns1:GlobalVariables/FileAdapter/fileExtensions, &quot;,&quot;)\">" +
                    "                        <fileExtensions>" +
                    "                            <value-of select=\"normalize-space(.)\"/>" +
                    "                        </fileExtensions>" +
                    "                    </for-each>" +

                    "            </inputBindings>" +
                    "        </activity>";

            String inputBindings = "  <root>" +
                    "                    <rootPath>" +
                    "                        <value-of select=\"$_globalVariables/ns1:GlobalVariables/FileAdapter/PollFolder\"/>" +
                    "                    </rootPath>" +
                    "                    <for-each select=\"tib:tokenize($_globalVariables/ns1:GlobalVariables/FileAdapter/fileExtensions, &quot;,&quot;)\">" +
                    "                        <fileExtensions>" +
                    "                            <value-of select=\"normalize-space(.)\"/>" +
                    "                        </fileExtensions>" +
                    "                    </for-each>" +
                    "                </root>";

            CallProcessActivityParser cpa_parser = new CallProcessActivityParser();
            final Activity callProcessActivity = cpa_parser.parse(getNode(xml), false);
            callProcessActivity.setInputBindings(inputBindings);
            //save the input and out put schema for the activity to file...
            setInputSchemaQname(callProcessActivity);
            setOutputSchemaQname(callProcessActivity);
            writeInputSchemaToFile(callProcessActivity,"activity_schema_input.ftl");
            writeOutputSchemaToFile(callProcessActivity,"activity_schema_output.ftl");

            //create input and output variables for the activity
            final Variable listFiles_input_variable = createBpelVariable(callProcessActivity.getInputSchemaQname(), callProcessActivity.getName()+"_in");
            final Import import_listFiles_in = createImport(listFiles_input_variable.getXqname());
            addImportToBpelProcess(import_listFiles_in);
            //Add variables to current scope
            addVariableToCurrentScope(listFiles_input_variable);
            final Variable listFiles_output_variable = createBpelVariable(callProcessActivity.getOutputSchemaQname(), callProcessActivity.getName());
            final Import import_listFiles_out = createImport(listFiles_output_variable.getXqname());
            addImportToBpelProcess(import_listFiles_out);
            createTransformation(getCurrentProcess().getProcessData(),listFiles_input_variable,callProcessActivity.getName());
            addVariableToCurrentScope(listFiles_output_variable);

            //Add transformation to the current sequence of the scope

            Assign assign_listFiles_transformation = doXSLTransformation(callProcessActivity);;

            AddActivityToCurrentSequence(assign_listFiles_transformation);

//As there is no further processing to be done in CallProcessActivity ..add output variable of the activity  to processData
            addVariableToProcessData(listFiles_output_variable);

            // after callProcessActivity next activity in the flow is Start   will have new process starting at
            //start .

            //With new subprocess we push new TbwProcess in process stack
            addNewProcessToStack(new TbwProcess(callProcessActivity.getName()));

            //with new subprocess there will be new scope in bpel with the same name as sub process...

            final Scope scope_listFiles = createScope(callProcessActivity.getName());
            AddActivityToCurrentSequence(scope_listFiles);
            addScopeToStack(scope_listFiles);


            //In start we just assign the ouput of previous activity transformation to $start
            final Variable Start_listFiles = createBpelVariable(callProcessActivity.getOutputSchemaQname(), "Start");

            //Add the input and output variable to current scope
            addVariableToCurrentScope(Start_listFiles);

            final Assign assign_listFiles = createAssign("Assign_Starter");
            Copy copy_listFiles =createCopy("$listFiles_in","$Start");
            assign_listFiles.getCopyOrExtensionAssignOperation().add(copy_listFiles);
            //Add assign activity to sequence.
            AddActivityToCurrentSequence(assign_listFiles);

            //After finishing all the tasks in a activity , we must add the output variable of the activity which has same name as activity name to process data.Add Start as process data
            addVariableToProcessData(Start_listFiles);

            //getCurrentScope().setAssign();
            //first step will be to create input and output schema for the activity, for JavaActivity the input and output schema has to be created from
            //following tags...
      */
/*

      <outputData>
                <row>
                    <fieldName>fileNames</fieldName>
                    <fieldType>string</fieldType>
                    <fieldRequired>repeating</fieldRequired>
                </row>
            </outputData>
            <inputData>
                <row>
                    <fieldName>rootPath</fieldName>
                    <fieldType>string</fieldType>
                    <fieldRequired>required</fieldRequired>
                </row>
                <row>
                    <fieldName>fileExtensions</fieldName>
                    <fieldType>string</fieldType>
                    <fieldRequired>repeating</fieldRequired>
                </row>
            </inputData>
       *//*



            String InFolders_String = " <activity name=\"InFolders\">" +
                    "        <type>com.tibco.plugin.java.JavaActivity</type>" +
                    "        <resourceType>ae.javapalette.javaActivity</resourceType>" +
                    "        <x>296</x>" +
                    "        <y>160</y>" +
                    "        <config>" +
                    "            <fileName>listFilesInFolders</fileName>" +
                    "            <packageName>CommonProcesses.listFiles</packageName>" +
                    "            <fullsource>package CommonProcesses.listFiles;" +
                    "import java.util.*;" +
                    "import java.io.*;" +
                    "import java.lang.*;" +
                    "public class listFilesInFolders{" +
                    "*/
/****** START SET/GET METHOD, DO NOT MODIFY *****//*
" +
                    "	protected String rootPath = \"\";" +
                    "	protected String[] fileExtensions = null;" +
                    "	protected String[] fileNames = null;" +
                    "	public String getrootPath() {" +
                    "		return rootPath;" +
                    "	}" +
                    "	public void setrootPath(String val) {" +
                    "		rootPath = val;" +
                    "	}" +
                    "	public String[] getfileExtensions() {" +
                    "		return fileExtensions;" +
                    "	}" +
                    "	public void setfileExtensions(String[] val) {" +
                    "		fileExtensions = val;" +
                    "	}" +
                    "	public String[] getfileNames() {" +
                    "		return fileNames;" +
                    "	}" +
                    "	public void setfileNames(String[] val) {" +
                    "		fileNames = val;" +
                    "	}" +
                    "*/
/****** END SET/GET METHOD, DO NOT MODIFY *****//*
" +
                    "	public listFilesInFolders() {" +
                    "	}" +
                    "	public void invoke() throws Exception {" +
                    "*/
/* Available Variables: DO NOT MODIFY" +
                    "	In  : String rootPath" +
                    "	In  : String[] fileExtensions" +
                    "	Out : String[] fileNames" +
                    "* Available Variables: DO NOT MODIFY *****//*
" +
                    "	Vector v = new Vector();" +
                    "        int counter = 0;" +
                    "   	File root = new File(rootPath);" +
                    "       	listFilesRecursive(v, root,fileExtensions);" +
                    "       	Enumeration e = v.elements();" +
                    "        String[] fileNames = new String[v.size()];" +
                    "	while(e.hasMoreElements())" +
                    "      	{" +
                    "	  File fn;" +
                    "	  fn = (File)e.nextElement();" +
                    "	 // System.out.println(fn.getPath());" +
                    "         fileNames[counter++] = fn.getPath();" +
                    "       }" +
                    "      setfileNames(fileNames);	               " +
                    "}" +
                    "	   public static void listFilesRecursive(Vector list, File rootPath, String[] fileExtensions) {" +
                    "		   if (rootPath.isFile()) {" +
                    "		    list.addElement(rootPath);" +
                    "		    return;" +
                    "		   }" +
                    "		   File[] files = rootPath.listFiles();" +
                    "		   for (int i=0; i &lt; files.length; i++) {" +
                    "		    if ( files[i].isFile()){" +
                    "                         for(int f = 0; f &lt; fileExtensions.length; f++) {" +
                    "                           if ( files[i].getName().endsWith(fileExtensions[f]) ) {" +
                    "		               list.addElement(files[i]);" +
                    "				//return;" +
                    "                            }" +
                    "                          }" +
                    "		    }" +
                    "		    if ( files[i].isDirectory()) {" +
                    "		*/
/*Ignore archive and fromhphc folders *//*
	" +
                    "		    	if(!(files[i].getAbsolutePath().endsWith(\"arch\".toLowerCase()) ||  " +
                    "		    			files[i].getAbsolutePath().endsWith(\"fromhphc\".toLowerCase()) ||" +
                    "		    			files[i].getAbsolutePath().endsWith(\"archive\".toLowerCase()) " +
                    "		    			)){		    	" +
                    "		    	" +
                    "				     listFilesRecursive(list,files[i], fileExtensions);" +
                    "		    	}" +
                    "		    }" +
                    "		   }" +
                    "	   }" +
                    "}" +
                    "</fullsource>" +
                    "            <outputData>" +
                    "                <row>" +
                    "                    <fieldName>fileNames</fieldName>" +
                    "                    <fieldType>string</fieldType>" +
                    "                    <fieldRequired>repeating</fieldRequired>" +
                    "                </row>" +
                    "            </outputData>" +
                    "            <inputData>" +
                    "                <row>" +
                    "                    <fieldName>rootPath</fieldName>" +
                    "                    <fieldType>string</fieldType>" +
                    "                    <fieldRequired>required</fieldRequired>" +
                    "                </row>" +
                    "                <row>" +
                    "                    <fieldName>fileExtensions</fieldName>" +
                    "                    <fieldType>string</fieldType>" +
                    "                    <fieldRequired>repeating</fieldRequired>" +
                    "                </row>" +
                    "            </inputData>" +
                    "            <byteCode>" +
                    "                <class>" +
                    "                    <name>listFilesInFolders</name>" +
                    "                    <byteCode>yv66vgAAAC4AbQkAHQA5CQAdADoJAB0AOwoAHgA8CAA9BwA+CgAGADwHAD8KAAgAQAoAHQBBCgAGAEIKAAYAQwcARAsARQBGCwBFAEcKAAgASAoAHQBJCgAIAEoKAAYASwoACABMCgAIAE0KAA0ATgoACABPCgAIAFAIAFEKAA0AUggAUwgAVAcAVQcAVgEACHJvb3RQYXRoAQASTGphdmEvbGFuZy9TdHJpbmc7AQAOZmlsZUV4dGVuc2lvbnMBABNbTGphdmEvbGFuZy9TdHJpbmc7AQAJZmlsZU5hbWVzAQALZ2V0cm9vdFBhdGgBABQoKUxqYXZhL2xhbmcvU3RyaW5nOwEABENvZGUBAA9MaW5lTnVtYmVyVGFibGUBAAtzZXRyb290UGF0aAEAFShMamF2YS9sYW5nL1N0cmluZzspVgEAEWdldGZpbGVFeHRlbnNpb25zAQAVKClbTGphdmEvbGFuZy9TdHJpbmc7AQARc2V0ZmlsZUV4dGVuc2lvbnMBABYoW0xqYXZhL2xhbmcvU3RyaW5nOylWAQAMZ2V0ZmlsZU5hbWVzAQAMc2V0ZmlsZU5hbWVzAQAGPGluaXQ+AQADKClWAQAGaW52b2tlAQAKRXhjZXB0aW9ucwcAVwEAEmxpc3RGaWxlc1JlY3Vyc2l2ZQEANihMamF2YS91dGlsL1ZlY3RvcjtMamF2YS9pby9GaWxlO1tMamF2YS9sYW5nL1N0cmluZzspVgEAClNvdXJjZUZpbGUBABdsaXN0RmlsZXNJbkZvbGRlcnMuamF2YQwAHwAgDAAhACIMACMAIgwAMAAxAQAAAQAQamF2YS91dGlsL1ZlY3RvcgEADGphdmEvaW8vRmlsZQwAMAApDAA1ADYMAFgAWQwAWgBbAQAQamF2YS9sYW5nL1N0cmluZwcAXAwAXQBeDABfAGAMAGEAJQwALwAtDABiAF4MAGMAZAwAZQBmDABnACUMAGgAaQwAagBeDABrACUBAARhcmNoDABsACUBAAhmcm9taHBoYwEAB2FyY2hpdmUBACxDb21tb25Qcm9jZXNzZXMvbGlzdEZpbGVzL2xpc3RGaWxlc0luRm9sZGVycwEAEGphdmEvbGFuZy9PYmplY3QBABNqYXZhL2xhbmcvRXhjZXB0aW9uAQAIZWxlbWVudHMBABkoKUxqYXZhL3V0aWwvRW51bWVyYXRpb247AQAEc2l6ZQEAAygpSQEAFWphdmEvdXRpbC9FbnVtZXJhdGlvbgEAD2hhc01vcmVFbGVtZW50cwEAAygpWgEAC25leHRFbGVtZW50AQAUKClMamF2YS9sYW5nL09iamVjdDsBAAdnZXRQYXRoAQAGaXNGaWxlAQAKYWRkRWxlbWVudAEAFShMamF2YS9sYW5nL09iamVjdDspVgEACWxpc3RGaWxlcwEAESgpW0xqYXZhL2lvL0ZpbGU7AQAHZ2V0TmFtZQEACGVuZHNXaXRoAQAVKExqYXZhL2xhbmcvU3RyaW5nOylaAQALaXNEaXJlY3RvcnkBAA9nZXRBYnNvbHV0ZVBhdGgBAAt0b0xvd2VyQ2FzZQAhAB0AHgAAAAMABAAfACAAAAAEACEAIgAAAAQAIwAiAAAACQABACQAJQABACYAAAAdAAEAAQAAAAUqtAABsAAAAAEAJwAAAAYAAQAAAAsAAQAoACkAAQAmAAAAIgACAAIAAAAGKiu1AAGxAAAAAQAnAAAACgACAAAADgAFAA8AAQAqACsAAQAmAAAAHQABAAEAAAAFKrQAArAAAAABACcAAAAGAAEAAAARAAEALAAtAAEAJgAAACIAAgACAAAABiortQACsQAAAAEAJwAAAAoAAgAAABQABQAVAAEALgArAAEAJgAAAB0AAQABAAAABSq0AAOwAAAAAQAnAAAABgABAAAAFwABAC8ALQABACYAAAAiAAIAAgAAAAYqK7UAA7EAAAABACcAAAAKAAIAAAAaAAUAGwABADAAMQABACYAAAA9AAIAAQAAABUqtwAEKhIFtQABKgG1AAIqAbUAA7EAAAABACcAAAAWAAUAAAAdAAQABwAKAAgADwAJABQAHgABADIAMQACACYAAACaAAMABwAAAFq7AAZZtwAHTAM9uwAIWSq0AAG3AAlOKy0qtAACuAAKK7YACzoEK7YADL0ADToFGQS5AA4BAJkAHhkEuQAPAQDAAAg6BhkFHIQCARkGtgAQU6f/3ioZBbYAEbEAAAABACcAAAAuAAsAAAAlAAgAJgAKACcAFgAoAB8AKQAlACoALgArADgALgBEADAAUwAyAFkAMwAzAAAABAABADQACQA1ADYAAQAmAAAA7wADAAYAAACfK7YAEpkACSortgATsSu2ABROAzYEFQQtvqIAhS0VBDK2ABKZACwDNgUVBSy+ogAiLRUEMrYAFSwVBTK2ABaZAAsqLRUEMrYAE4QFAaf/3S0VBDK2ABeZAEItFQQytgAYEhm2ABq2ABaaADAtFQQytgAYEhu2ABq2ABaaAB4tFQQytgAYEhy2ABq2ABaaAAwqLRUEMiy4AAqEBAGn/3qxAAAAAQAnAAAAPgAPAAAANwAHADgADAA5AA0AOwASADwAHAA9ACYAPgAwAD8AQQBAAEkAPgBPAEUAWQBHAI8ATACYADwAngBQAAEANwAAAAIAOA==</byteCode>" +
                    "                </class>" +
                    "            </byteCode>" +
                    "        </config>" +
                    "        <inputBindings>" +
                    "            <javaCodeActivityInput>" +
                    "                <rootPath>" +
                    "                    <value-of select=\"utils:ReplaceAll($Start/root/rootPath, &quot;\\\\&quot;, &quot;/&quot;)\"/>" +
                    "                </rootPath>" +
                    "                <for-each select=\"$Start/root/fileExtensions\">" +
                    "                    <fileExtensions>" +
                    "                        <value-of select=\"normalize-space(.)\"/>" +
                    "                    </fileExtensions>" +
                    "                </for-each>" +
                    "            </javaCodeActivityInput>" +
                    "        </inputBindings>" +
                    "    </activity>";

            JavaActivityParser java_parser = new JavaActivityParser();
            final JavaActivity javaActivity =(JavaActivity)java_parser.parse(getNode(InFolders_String), false);


            // javaActivity.set
            //save the input and out put schema for the activity to file...
            setInputSchemaQname(javaActivity);
            setOutputSchemaQname(javaActivity);
            writeInputSchemaToFile(javaActivity,"activity_schema_input.ftl");
            writeOutputSchemaToFile(javaActivity,"activity_schema_output.ftl");
            final Variable java_activity_input_variable = createBpelVariable(javaActivity.getInputSchemaQname(), javaActivity.getName()+"_in");
            final Import import_inFolder_in = createImport(java_activity_input_variable.getXqname());
            addImportToBpelProcess(import_inFolder_in);
            addVariableToCurrentScope(java_activity_input_variable);
            final Variable java_activity_output_variable = createBpelVariable(javaActivity.getOutputSchemaQname(), javaActivity.getName());
            final Import import_inFolder_out = createImport(java_activity_output_variable.getXqname());
            addImportToBpelProcess(import_inFolder_out);
            addVariableToCurrentScope(java_activity_output_variable);
            createTransformation(getCurrentProcess().getProcessData(),java_activity_input_variable,javaActivity.getName());
            // Setup schema compiler

            //sc.forcePackageName(javaActivity.getPackageName());

            // Setup SAX InputSource
            File schemaFile_in = new File(getFilePathToWrite("Schemas", getCurrentProcess()), javaActivity.getName() + "_in" + ".xsd");
            File schemaFile_out = new File(getFilePathToWrite("Schemas", getCurrentProcess()), javaActivity.getName() + "_out" + ".xsd");
            File directory = new File(getFilePathToWrite("SCA-INF/src", null));
            if (!directory.exists()) {
                directory.mkdirs();
                // If you require it to make the entire directory path including parents,
                // use directory.mkdirs(); here instead.
            }
            XSDUtils.xjcCreateJavaClassesFromXSD(schemaFile_in, directory);
            XSDUtils.xjcCreateJavaClassesFromXSD(schemaFile_out, directory);
            // replace(".", "/")
            List java_file_imports= new ArrayList();
            String import1 = XSDUtils.convertToPackageName(javaActivity.getInputSchemaQname().getNamespaceURI())+".JavaCodeActivityInput";
            String import2= XSDUtils.convertToPackageName(javaActivity.getOutputSchemaQname().getNamespaceURI())+".JavaCodeActivityOutput";
            java_file_imports.add(import1);
            java_file_imports.add(import2);
            getFtlMap().put("java_imports" , java_file_imports);

            String java_class = processTemplate(getFtlMap(), "java_activity_class.ftl");
            FileUtility.writeFile(  getFilePathToWrite("SCA-INF/src"+ File.separator +javaActivity.getPackageName().replace(".", File.separator), null),javaActivity.getFileName()+".java",java_class);
            String java_interface = processTemplate(getFtlMap(), "java_activity_interface.ftl");
            FileUtility.writeFile(  getFilePathToWrite("SCA-INF/src"+ File.separator +javaActivity.getPackageName().replace(".", File.separator), null),"I"+javaActivity.getFileName()+".java",java_interface);
            String java_subclass = processTemplate(getFtlMap(), "java_activity_subclass.ftl");
            FileUtility.writeFile(  getFilePathToWrite("SCA-INF/src"+ File.separator + javaActivity.getPackageName().replace(".", File.separator), null),javaActivity.getFileName()+"_sub"+".java",java_subclass);

            String java_wsdl = processTemplate(getFtlMap(), "java_activity_wsdl.ftl");
            FileUtility.writeFile(  getFilePathToWrite("WSDLs", null),"I"+javaActivity.getFileName()+".wsdl",java_wsdl);

            String java_wsdl_wrapper = processTemplate(getFtlMap(), "java_activity_Interface_wsdl.ftl");
            FileUtility.writeFile(  getFilePathToWrite("WSDLs", null),"I"+javaActivity.getFileName()+"Wrapper"+".wsdl",java_wsdl_wrapper);

            //Add transformation to the current sequence of the scope

            Assign assign_InFolder_transformation = doXSLTransformation(javaActivity);


            AddActivityToCurrentSequence(assign_InFolder_transformation);



*/
/*
 <invoke name="Invoke_listFilesInFolders" inputVariable="Invoke_listFilesInFolders_invoke_InputVariable"
                        outputVariable="Invoke_listFilesInFolders_invoke_OutputVariable"
                        partnerLink="listFilesInFolders.test" portType="ns5:IlistFilesInFolders" operation="invoke"
                        bpelx:invokeAsDetail="no"/>
 *//*


            final Invoke invoke_InFolder = getBpelProcessFactory().createTInvoke();


//after all the activities in javaCallProcess activities are complete add activity output variable to process data
            addVariableToProcessData(java_activity_output_variable);
            createBpelProcessFlow(getBpelProcess());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void addNewProcessToStack(TbwProcess item) {
        getProcessStack().push(item);
    }

    private static void addVariableToProcessData(Variable listFiles_output_variable) {
        getProcessStack().peek().getProcessData().add(listFiles_output_variable);
    }

    private static void addVariableToCurrentScope(Variable listFiles_input_variable) {
        getCurrentScope().getVariables().getVariable().add(listFiles_input_variable);
    }

    private static void setOutputSchemaQname(Activity callProcessActivity) throws ParserConfigurationException, IOException, SAXException, TemplateException, IllegalAccessException, ClassNotFoundException, InstantiationException {
        callProcessActivity.setOutputSchemaQname(doCreateOrFindOutputSchema(callProcessActivity));
    }

    private static void setInputSchemaQname(Activity callProcessActivity) throws ParserConfigurationException, IOException, SAXException, TemplateException, IllegalAccessException, ClassNotFoundException, InstantiationException {
        callProcessActivity.setInputSchemaQname(doCreateOrFindInputSchema(callProcessActivity));
    }

    private static Copy createCopy(String fromVar , String toVar) {
        To to = GenericBuilder.of(To::new)
                .with(To::setVariable, toVar).build();
        From from = GenericBuilder.of(From::new)
                .with(From::setVariable, fromVar).build();
        return GenericBuilder.of(Copy::new)
                .with(Copy::setFrom, from).with(Copy::setTo, to).build();
    }

    private static Assign createAssign(String name) {
        return getBpelProcessFactory().createAssign(name);
    }

    private static void addMainScopeToBpelProcess(Scope scope_main) {
        getBpelProcess().setScope(scope_main);
    }

    private static Sequence createSequence(String main) {
        return getBpelProcessFactory().createSequence(main);
    }

    private static void addScopeToStack(Scope scope_main) {
        getScopeStack().push(scope_main);
    }

    private static Scope createScope(String name) {
        Scope scope= getBpelProcessFactory().createScope(name);
        final Sequence sequence = createSequence(name);
        final Variables variables = getBpelProcessFactory().createTVariables();
        scope.setVariables(variables);
        scope.setSequence(sequence);
        return scope;
    }

    private static ExtendedQName createEmptyVariable() {
        ExtendedQNameBuilder builder_empty = new ExtendedQNameBuilder();
        builder_empty.setNamespaceURI(getNamespace(getCurrentProcess(), "Empty")).setLocation("../Schemas"+ getRecursiveProcessPath("/")+"/Misc.xsd").setPrefix("misc").setType(ExtendedQNameType.ElementType.getType()).setLocalPart("empty");
        return new ExtendedQName(builder_empty);
    }

    private static void addVariableToGlobalProcessData(Variable variable_global) {
        getCurrentProcess().getGlobalData().add(variable_global);
    }

    private static void addVariableToBpelProcess(Variable variable_global) {
        getBpelProcess().getVariables().getVariable().add(variable_global);
    }

    private static Variable createBpelVariable(ExtendedQName xqname, String variable) {
        return getBpelProcessFactory().createVariable(variable, xqname);
    }

    private static void addImportToBpelProcess(Import tImport) {
        getBpelProcess().getImport().add(tImport);
    }

    private static Import createImport(ExtendedQName xqname_global_variable) {
        return getBpelProcessFactory().createImport(xqname_global_variable);
    }

    private static ExtendedQName createGlobalVariable() {
        ExtendedQNameBuilder builder_global_variable = new ExtendedQNameBuilder();
        builder_global_variable.setNamespaceURI(getNamespace(getCurrentProcess(), "GlobalVariables")).setLocation("../Schemas"+ getRecursiveProcessPath("/")+"GlobalVariables.xsd").setPrefix("gbl").setType(ExtendedQNameType.ElementType.getType()).setLocalPart("GlobalVariables");
        return new ExtendedQName(builder_global_variable);
    }

    private static Process createBpelProcess() {
        final Process bpel_process = getBpelProcessFactory().createProcess();
        bpel_process.setName(outputProject.getProcessName());
        bpel_process.setTargetNamespace(getNamespace(getCurrentProcess(), null));
        bpel_process.setVariables(getBpelProcessFactory().createTVariables());
        return bpel_process;
    }

    private static void createGlobalVariablesDVM(GlobalVariablesRepository repository) throws IOException, TemplateException {
        initializeFtlMap();
        getFtlMap().put("repository", repository);
        String dvm = processTemplate(getFtlMap(), "global_variables_dvm.ftl");
        FileUtility.writeFile(getFilePathToWrite("DVM", getCurrentProcess()), "GlobalVariables.dvm", dvm);
    }

    private static void createGlobalVariablesXSD(GlobalVariablesRepository repository) throws IOException, TemplateException {
        initializeFtlMap();
        getFtlMap().put("repository", repository);
        String xsd = processTemplate(getFtlMap(), "GlobalVariables_xsd.ftl");
        FileUtility.writeFile(getFilePathToWrite("Schemas", getCurrentProcess()), "GlobalVariables.xsd", xsd);
    }

    private static void InitializeOutputProject() {

        outputProject.setProjectFolder("C:\\Tibco2OracleSOA\\oracle_soa_output");
        outputProject.setProjectName("IESN_BatchFileAdapter_27X");
        outputProject.setProcessName(getCurrentProcess().getProcessName());
        //composite file name should be same as project name
        outputProject.setCompositeFileName("IESN_BatchFileAdapter_27X");
        outputProject.createProjectDirectoriesStructure();
    }

    private static void AddActivityToCurrentSequence(com.dell.dims.Model.bpel.Activity activity) {
        getCurrentScope().getSequence().getActivity().add(activity);
    }

    private static Assign doXSLTransformation(Activity activity) {
        Assign assign_InFolder_transformation = createAssign(activity.getName()+"_inputBindings");

        To to_InFolder_transformation = GenericBuilder.of(To::new)
                .with(To::setVariable, activity.getName()+"_in").build();
        String fromVariable_InFolder_transformation = "ora:doXSLTransformForDoc("+"\""+"../Transformations"+"\""+ getRecursiveProcessPath("/")+"/"+activity.getName()+".xsl,"+getParametersForTransformation();
        From from_InFolder_transformation = GenericBuilder.of(From::new)
                .with(From::setVariable, fromVariable_InFolder_transformation).build();
        Copy copy_InFolder_transformation = GenericBuilder.of(Copy::new)
                .with(Copy::setFrom, from_InFolder_transformation).with(Copy::setTo, to_InFolder_transformation).build();
        assign_InFolder_transformation.getCopyOrExtensionAssignOperation().add(copy_InFolder_transformation);
        return assign_InFolder_transformation;
    }

    private static void initializeFtlMap() {
        getFtlMap().clear();
        getFtlMap().put("projectName", outputProject.getProjectName());
        getFtlMap().put("processName", outputProject.getProcessName());
        getFtlMap().put("compositeFileName", outputProject.getCompositeFileName());
    }


    static String processTemplate(Object root, String templateName) throws IOException, TemplateException {
        Template template = getCfg().getTemplate(templateName);

        // 2.3. Generate the output

        StringWriter stringWriter = new StringWriter();


// get the String from the StringWriter

        try {
            template.process(root, stringWriter);
        } finally {
            stringWriter.close();
        }

        return stringWriter.toString();
    }


    public static Node getNode(String xml) throws ParserConfigurationException, IOException, SAXException {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new InputSource(new StringReader(xml)));
    }

    static String getFilePathToWrite(String folder, TbwProcess process) {
        String path;
        if (process != null && StringUtils.isNotEmpty(folder)) {
            path = outputProject.getOutputProjectFullPath() + File.separator + "SOA" + File.separator + folder + File.separator + getRecursiveProcessPath();
        } else if(StringUtils.isNotEmpty(folder)){
            path = outputProject.getOutputProjectFullPath() + File.separator + "SOA" + File.separator + folder;
        }else
        {
            path = outputProject.getOutputProjectFullPath() + File.separator + "SOA";
        }
        return path;
    }


    static String getNamespace(TbwProcess process, String str) {
        if (str != null && !str.isEmpty()) {
            return "http://xmlns.oracle.com/" + outputProject.getProjectName() +  getRecursiveProcessPath("/") + "/" + str;
        } else {
            return "http://xmlns.oracle.com/" + outputProject.getProjectName() + getRecursiveProcessPath("/");
        }
    }



    public static ExtendedQName doCreateOrFindInputSchema(Activity activity) throws ParserConfigurationException, IOException, SAXException, TemplateException, IllegalAccessException, ClassNotFoundException, InstantiationException {
        String inputSchema = findInputSchema(activity);
        if (inputSchema != null) {
            String location = "../Schemas/Tibco_Defined_Schemas.xsd";
            String namespaceURI = "http://www.tibco.com/ns/activityschemas";
            String localPart = getRootNodeNameForInputSchema(activity,inputSchema);
            String prefix = "tbc";
            String type=ExtendedQNameType.ElementType.getType();
            return new ExtendedQNameBuilder().setNamespaceURI(namespaceURI).setLocalPart(localPart).setPrefix(prefix).setLocation(location).setSchema(inputSchema).setType(type).createExtendedQName();
        } else {
            String location = getLocationForInputSchema(activity);
            String namespaceURI = getNamespaceURIForInputSchema(activity);
            String prefix = getPrefix(activity);
            inputSchema = createInputSchema(activity);
            String localPart = getRootNodeNameForInputSchema(activity,inputSchema);
            String type=ExtendedQNameType.ElementType.getType();
            return new ExtendedQNameBuilder().setNamespaceURI(namespaceURI).setLocalPart(localPart).setPrefix(prefix).setLocation(location).setSchema(inputSchema).setType(type).createExtendedQName();

        }
    }


    public static ExtendedQName doCreateOrFindOutputSchema(Activity activity) throws ParserConfigurationException, IOException, SAXException, TemplateException, IllegalAccessException, ClassNotFoundException, InstantiationException {
        String outputSchema = findOutputSchema(activity);
        if (outputSchema != null) {
            String location = "../Schemas/Tibco_Defined_Schemas.xsd";
            String namespaceURI = "http://www.tibco.com/ns/activityschemas";
            String localPart = getRootNodeNameForOutputSchema(activity,outputSchema);
            String prefix = "tbc";
            String type=ExtendedQNameType.ElementType.getType();
            return new ExtendedQNameBuilder().setNamespaceURI(namespaceURI).setLocalPart(localPart).setPrefix(prefix).setLocation(location).setSchema(outputSchema).setType(type).createExtendedQName();
        } else {
            String prefix = getPrefix(activity);
            String location = getLocationForOutputSchema(activity);
            String namespaceURI = getNamespaceURIForOutputSchema(activity);
            outputSchema = createOutputSchema(activity);
            String localPart = getRootNodeNameForOutputSchema(activity,outputSchema);
            String type=ExtendedQNameType.ElementType.getType();
            return new ExtendedQNameBuilder().setNamespaceURI(namespaceURI).setLocalPart(localPart).setPrefix(prefix).setLocation(location).setSchema(outputSchema).setType(type).createExtendedQName();

        }
    }


    static String createInputSchema(Activity activity) throws IOException, TemplateException {

        String schema_in = null;
        getFtlMap().put("activity", activity);
        //TBD: / If the Activity Type is CallProcessActivity , its input schema is defined within <startType> tags of the subprocess and output schema is defined within  <endType> tag
        //  of the subprocess
        //The input schema is saved in file named  Activityname_input.xsd and output schema is saved in file Activityname_output.xsd...with targetnamespace as
        // targetNamespace="http://xmlns.oracle.com/${application.projectName}/${application.compositeFileName}/$(processName}/${subprocessName}/${activityName}"
        if (activity.getType().getName().equals(ActivityType.callProcessActivityType.getName())) {
            schema_in = " <xsd:element name=\"root\">" +
                    "            <xsd:complexType>" +
                    "                <xsd:sequence>" +
                    "                    <xsd:element name=\"rootPath\" type=\"xsd:string\"/>" +
                    "                    <xsd:element name=\"fileExtensions\" type=\"xsd:string\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>" +
                    "                </xsd:sequence>" +
                    "            </xsd:complexType>" +
                    "        </xsd:element>";

        } else if (activity.getType().getName().equals(ActivityType.javaActivityType.getName())) {

            schema_in = processTemplate(getFtlMap(), "java_activity_input_schema.ftl");

        }
        return schema_in;
    }


    static String createOutputSchema(Activity activity) throws IOException, TemplateException {

        String schema_out = null;
        //TBD: / If the Activity Type is CallProcessActivity , its input schema is defined within <startType> tags of the subprocess and output schema is defined within  <endType> tag
        //  of the subprocess
        //The input schema is saved in file named  Activityname_input.xsd and output schema is saved in file Activityname_output.xsd...with targetnamespace as
        // targetNamespace="http://xmlns.oracle.com/${application.projectName}/${application.compositeFileName}/$(processName}/${subprocessName}/${activityName}"
        if (activity.getType().getName().equals(ActivityType.callProcessActivityType.getName())) {
            schema_out = "<xsd:element name=\"root\">" +
                    "            <xsd:complexType>" +
                    "                <xsd:sequence>" +
                    "                    <xsd:element name=\"fileNames\" type=\"xsd:string\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>" +
                    "                </xsd:sequence>" +
                    "            </xsd:complexType>" +
                    "        </xsd:element>";
        } else if (activity.getType().getName().equals(ActivityType.javaActivityType.getName())) {
            getFtlMap().put("activity", activity);
            schema_out = processTemplate(getFtlMap(), "java_activity_output_schema.ftl");
        }

        return schema_out;
    }

    static String findInputSchema(Activity activity) {
        return null;
    }


    static String findOutputSchema(Activity activity) {
        return null;

    }


    static String getRootNodeNameForInputSchema(Activity activity,String schema) throws ParserConfigurationException, IOException, SAXException, InstantiationException, IllegalAccessException, ClassNotFoundException {

        Element root;
        if (activity.getType().getName().equals(ActivityType.javaActivityType.getName())) {
            return "javaCodeActivityInput";
        }else{

            root = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                    .parse(new ByteArrayInputStream(schema.getBytes()))
                    .getDocumentElement();}
        return root.getAttribute("name");
    }


    static String getRootNodeNameForOutputSchema(Activity activity,String schema) throws ParserConfigurationException, IOException, SAXException, InstantiationException, IllegalAccessException, ClassNotFoundException {
        Element root;
        if (activity.getType().getName().equals(ActivityType.javaActivityType.getName())) {
            return "javaCodeActivityOutput";
        }else{
            root = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                    .parse(new ByteArrayInputStream(schema.getBytes()))
                    .getDocumentElement();}
        return root.getAttribute("name");
    }

    static String getPrefix(Activity activity) {
        return "ns" + getPrefixCounter();
    }


    static String getNamespaceURIForInputSchema(Activity activity) {
        if (activity != null) {
            return "http://xmlns.oracle.com/" + outputProject.getProjectName() +  getRecursiveProcessPath("/") + "/" + activity.getName() + "_input";
        } else {
            return "http://xmlns.oracle.com/" + outputProject.getProjectName() +  getRecursiveProcessPath("/");
        }
    }

    static String getNamespaceURIForOutputSchema(Activity activity) {
        if (activity != null) {
            return "http://xmlns.oracle.com/" + outputProject.getProjectName() + getRecursiveProcessPath("/") + "/" + activity.getName() + "_output";
        } else {
            return "http://xmlns.oracle.com/" + outputProject.getProjectName() +  getRecursiveProcessPath("/");
        }
    }


    static String getLocationForInputSchema(Activity activity) {
        return ".." + "/"+ "Schemas" + getRecursiveProcessPath("/")+"/"+activity.getName() + "_in" + ".xsd";
    }

    static String getLocationForOutputSchema(Activity activity) {
        return ".." + "/"+ "Schemas" + getRecursiveProcessPath("/")+"/"+activity.getName() + "_out" + ".xsd";
    }



    public static synchronized int getPrefixCounter() {
        return prefixCounter++;
    }

    static String getRecursiveProcessPath() {
        String path="" ;

        for(TbwProcess process : getProcessStack()) {
            path = path+File.separator+process.getProcessName() ;
        }
        return path;
    }

    static String getRecursiveProcessPath(String fileSeperator) {
        String path="" ;

        for(TbwProcess process : getProcessStack()) {
            path =  path+ fileSeperator+process.getProcessName()  ;
        }
        return path;
    }


    public static void createTransformation(List<Variable> sources,Variable target, String activityName) throws IOException, TemplateException {


        getFtlMap().put("sources", sources);
        getFtlMap().put("target", target);
        String xslt = processTemplate(getFtlMap(), "xslt.ftl");
        FileUtility.writeFile(getFilePathToWrite("Transformations", getCurrentProcess()), activityName + ".xsl", xslt);

    }

    public static void writeInputSchemaToFile(Activity activity,String templateName) throws IOException, TemplateException {

        getFtlMap().put("activity",activity);
        String xsd_in = processTemplate(getFtlMap(), templateName);
        FileUtility.writeFile(  getFilePathToWrite("Schemas",getCurrentProcess()),activity.getName()+"_in"+".xsd",xsd_in);

    }


    public static void writeOutputSchemaToFile(Activity activity,String templateName) throws IOException, TemplateException {

        getFtlMap().put("activity",activity);
        String xsd_out = processTemplate(getFtlMap(), templateName);
        FileUtility.writeFile(  getFilePathToWrite("Schemas",getCurrentProcess()),activity.getName()+"_out"+".xsd",xsd_out);

    }

    static TbwProcess  getCurrentProcess()
    {
        return  getProcessStack().peek();
    }

    static Scope  getCurrentScope()
    {
        return  getScopeStack().peek();
    }

    static String   getParametersForTransformation()
    {
        String param= "$empty";
        for (Variable var : getCurrentProcess().getProcessData()) {
            //, $empty, "_globalVariables", $_globalVariables
            if(!var.getName().equalsIgnoreCase("empty"))
                param = param+","+ "\""+var.getName()+"\""+","+"$"+var.getName();
        }
        return param;
    }

    static void  createBpelProcessFlow(Process process) throws IOException, TemplateException {
        initializeFtlMap();
        StringBuilder builder = new StringBuilder();
        builder.append("<?xml version = \"1.0\" encoding = \"UTF-8\" ?>");
        builder.append(ProcessImports(process.getImport()));
        builder.append(ProcessVariables(process.getVariables()));
        builder.append(ProcessScope(process.getScope()));
        builder.append("</process>");
        FileUtility.writeFile(  getFilePathToWrite("BPEL", null), outputProject.getProcessName()+".bpel",builder.toString());

    }

    static String ProcessScope(Scope scope) throws IOException, TemplateException {
        StringBuilder builder = new StringBuilder();
        builder.append(" <scope name=\""+scope.getName()+"\">");
        builder.append(ProcessVariables(scope.getVariables()));
        builder.append(ProcessSequence(scope.getSequence()));
        builder.append("</scope>");
        return builder.toString();
    }

    static String ProcessVariables(Variables variables) throws IOException, TemplateException {
        getFtlMap().put("variables",variables);
        return processTemplate(getFtlMap(), "bpel_variables.ftl");
    }

    static String ProcessImports(List<Import> imports) throws IOException, TemplateException {
        getFtlMap().put("imports",imports);
        return processTemplate(getFtlMap(), "bpel_imports.ftl");
    }

    static String ProcessSequence(Sequence sequence) throws IOException, TemplateException {
        StringBuilder builder = new StringBuilder();
        builder.append(" <sequence name=\""+sequence.getName()+"\">");
        for (com.dell.dims.Model.bpel.Activity activity : sequence.getActivity()) {

            String str="";
            if(activity instanceof Assign )
            {
                Assign assign=(Assign)activity;
                getFtlMap().put("assign",assign);
                str = processTemplate(getFtlMap(), "bpel_assign.ftl");

            }
            else if(activity instanceof Scope )
            {
                str = ProcessScope((Scope)activity);
            }
            builder.append(str);
        }
        builder.append("<sequence>");
        return builder.toString();

    }

    public static Configuration getCfg() {
        return cfg;
    }

    public static void setCfg(Configuration cfg) {
        BuilderMain.cfg = cfg;
    }

    public static Stack<TbwProcess> getProcessStack() {
        return processStack;
    }

    public static void setProcessStack(Stack<TbwProcess> processStack) {
        BuilderMain.processStack = processStack;
    }

    public static Stack<Scope> getScopeStack() {
        return scopeStack;
    }

    public static void setScopeStack(Stack<Scope> scopeStack) {
        BuilderMain.scopeStack = scopeStack;
    }

    public static void setPrefixCounter(int prefixCounter) {
        BuilderMain.prefixCounter = prefixCounter;
    }

    public static Map getFtlMap() {
        return ftlMap;
    }

    public static Map getFtlMap(OutputProject outputProject) {
        Map ftlMap=new HashMap();
        ftlMap.put("projectName", outputProject.getProjectName());
        ftlMap.put("processName", outputProject.getProcessName());
        ftlMap.put("compositeFileName", outputProject.getCompositeFileName());
        return ftlMap;
    }


    public static ObjectFactory getBpelProcessFactory() {
        return new ObjectFactory();
    }


    public static Process getBpelProcess() {
        return bpelProcess;
    }

    public static void setBpelProcess(Process bpelProcess) {
        BuilderMain.bpelProcess = bpelProcess;
    }
}

*/
