package com.dell.dims.Model;

/**
 * Created by Manoj_Mehta on 5/30/2017.
 */
public class RVRequestActivity extends Activity {
    public RVRequestActivity(String name, ActivityType type) {
        super(name, type);
    }

    public RVRequestActivity() throws Exception {
    }
}
