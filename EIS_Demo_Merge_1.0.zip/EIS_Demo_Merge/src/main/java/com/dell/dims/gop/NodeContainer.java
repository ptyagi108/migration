package com.dell.dims.gop;

/**
 * @author pramod
 */
public interface NodeContainer {
    public void addNode(GopNode node);

    public GopNode getNode(Long id);
}
