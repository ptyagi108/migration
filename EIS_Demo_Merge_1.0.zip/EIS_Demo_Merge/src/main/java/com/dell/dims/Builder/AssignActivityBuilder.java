package com.dell.dims.Builder;


import com.dell.dims.Model.Activity;

public class AssignActivityBuilder extends AbstractActivityBuilder
{

    @Override
    public void build(Activity activity) {

    }
}


