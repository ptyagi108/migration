//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.5-2
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a>
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen.
// Generado el: PM.02.21 a las 09:44:00 PM CET
//


package com.dell.dims.Model.bpel;

import com.dell.dims.Model.ExtendedQName;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the org.oasis_open.docs.wsbpel._2_0.process.executable package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Query_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "query");
    private final static QName _Link_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "link");
    private final static QName _Scope_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "scope");
    private final static QName _While_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "while");
    private final static QName _RepeatEvery_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "repeatEvery");
    private final static QName _Catch_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "catch");
    private final static QName _CorrelationSets_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "correlationSets");
    private final static QName _MessageExchanges_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "messageExchanges");
    private final static QName _From_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "from");
    private final static QName _If_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "if");
    private final static QName _Throw_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "throw");
    private final static QName _Receive_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "receive");
    private final static QName _Targets_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "targets");
    private final static QName _ToParts_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "toParts");
    private final static QName _Reply_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "reply");
    private final static QName _Pick_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "pick");
    private final static QName _FinalCounterValue_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "finalCounterValue");
    private final static QName _Links_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "links");
    private final static QName _FromPart_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "fromPart");
    private final static QName _Source_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "source");
    private final static QName _ExtensionActivity_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "extensionActivity");
    private final static QName _EventHandlers_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "eventHandlers");
    private final static QName _Invoke_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "invoke");
    private final static QName _Sequence_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "sequence");
    private final static QName _Extension_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "extension");
    private final static QName _Process_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "process");
    private final static QName _OnEvent_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "onEvent");
    private final static QName _CatchAll_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "catchAll");
    private final static QName _MessageExchange_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "messageExchange");
    private final static QName _Variable_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "variable");
    private final static QName _Literal_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "literal");
    private final static QName _Documentation_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "documentation");
    private final static QName _Target_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "target");
    private final static QName _FaultHandlers_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "faultHandlers");
    private final static QName _For_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "for");
    private final static QName _To_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "to");
    private final static QName _Assign_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "assign");
    private final static QName _Extensions_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "extensions");
    private final static QName _Validate_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "validate");
    private final static QName _Sources_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "sources");
    private final static QName _Until_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "until");
    private final static QName _CompletionCondition_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "completionCondition");
    private final static QName _StartCounterValue_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "startCounterValue");
    private final static QName _JoinCondition_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "joinCondition");
    private final static QName _Wait_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "wait");
    private final static QName _CompensationHandler_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "compensationHandler");
    private final static QName _PartnerLink_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "partnerLink");
    private final static QName _Flow_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "flow");
    private final static QName _ExtensionAssignOperation_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "extensionAssignOperation");
    private final static QName _FromParts_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "fromParts");
    private final static QName _Branches_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "branches");
    private final static QName _Copy_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "copy");
    private final static QName _Empty_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "empty");
    private final static QName _Import_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "import");
    private final static QName _ToPart_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "toPart");
    private final static QName _Condition_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "condition");
    private final static QName _ForEach_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "forEach");
    private final static QName _Else_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "else");
    private final static QName _Rethrow_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "rethrow");
    private final static QName _CorrelationSet_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "correlationSet");
    private final static QName _CompensateScope_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "compensateScope");
    private final static QName _Exit_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "exit");
    private final static QName _Variables_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "variables");
    private final static QName _TerminationHandler_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "terminationHandler");
    private final static QName _PartnerLinks_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "partnerLinks");
    private final static QName _RepeatUntil_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "repeatUntil");
    private final static QName _Compensate_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "compensate");
    private final static QName _TransitionCondition_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "transitionCondition");
    private final static QName _Elseif_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "elseif");
    private final static QName _OnMessage_QNAME = new QName("http://docs.oasis-open.org/wsbpel/2.0/process/executable", "onMessage");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.oasis_open.docs.wsbpel._2_0.process.executable
     *
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link To }
     *
     */
    public To createTTo() {
        return new ToBuilder().createTo();
    }

    /**
     * Create an instance of {@link Assign }
     *
     */
    public Assign createAssign() {
        return new Assign();
    }

    public Assign createAssign(String name) {
        return new Assign(name);
    }

    /**
     * Create an instance of {@link DurationExpr }
     *
     */
    public DurationExpr createTDurationExpr() {
        return new DurationExpr();
    }

    /**
     * Create an instance of {@link Condition }
     *
     */
    public Condition createTCondition() {
        return new Condition();
    }

    /**
     * Create an instance of {@link Wait }
     *
     */
    public Wait createTWait() {
        return new Wait();
    }

    /**
     * Create an instance of {@link ActivityContainer }
     *
     */
    public ActivityContainer createTActivityContainer() {
        return new ActivityContainer();
    }

    /**
     * Create an instance of {@link PartnerLink }
     *
     */
    public PartnerLink createTPartnerLink() {
        return new PartnerLink();
    }

    /**
     * Create an instance of {@link Flow }
     *
     */
    public Flow createTFlow() {
        return new Flow();
    }

    /**
     * Create an instance of {@link Extensions }
     *
     */
    public Extensions createTExtensions() {
        return new Extensions();
    }

    /**
     * Create an instance of {@link Validate }
     *
     */
    public Validate createTValidate() {
        return new Validate();
    }

    /**
     * Create an instance of {@link Sources }
     *
     */
    public Sources createTSources() {
        return new Sources();
    }

    /**
     * Create an instance of {@link DeadlineExpr }
     *
     */
    public DeadlineExpr createTDeadlineExpr() {
        return new DeadlineExpr();
    }

    /**
     * Create an instance of {@link Expression }
     *
     */
    public Expression createTExpression() {
        return new Expression();
    }

    /**
     * Create an instance of {@link CompletionCondition }
     *
     */
    public CompletionCondition createTCompletionCondition() {
        return new CompletionCondition();
    }

    /**
     * Create an instance of {@link ExtensionAssignOperation }
     *
     */
    public ExtensionAssignOperation createTExtensionAssignOperation() {
        return new ExtensionAssignOperation();
    }

    /**
     * Create an instance of {@link Empty }
     *
     */
    public Empty createTEmpty() {
        return new Empty();
    }

    /**
     * Create an instance of {@link Import }
     *
     */
    public Import createImport() {
        return new Import();
    }

    public Import createImport(ExtendedQName xqname) {
        return new Import(xqname);
    }

    /**
     * Create an instance of {@link ToPart }
     *
     */
    public ToPart createTToPart() {
        return new ToPart();
    }

    /**
     * Create an instance of {@link FromParts }
     *
     */
    public FromParts createTFromParts() {
        return new FromParts();
    }

    /**
     * Create an instance of {@link Branches }
     *
     */
    public Branches createTBranches() {
        return new Branches();
    }

    /**
     * Create an instance of {@link Copy }
     *
     */
    public Copy createTCopy() {
        return new Copy();
    }

    /**
     * Create an instance of {@link Rethrow }
     *
     */
    public Rethrow createTRethrow() {
        return new Rethrow();
    }

    /**
     * Create an instance of {@link CorrelationSet }
     *
     */
    public CorrelationSet createTCorrelationSet() {
        return new CorrelationSet();
    }

    /**
     * Create an instance of {@link CompensateScope }
     *
     */
    public CompensateScope createTCompensateScope() {
        return new CompensateScope();
    }

    /**
     * Create an instance of {@link BooleanExpr }
     *
     */
    public BooleanExpr createTBooleanExpr() {
        return new BooleanExpr();
    }

    /**
     * Create an instance of {@link ForEach }
     *
     */
    public ForEach createTForEach() {
        return new ForEach();
    }

    /**
     * Create an instance of {@link Exit }
     *
     */
    public Exit createTExit() {
        return new Exit();
    }

    /**
     * Create an instance of {@link Variables }
     *
     */
    public Variables createTVariables() {
        return new Variables();
    }

    /**
     * Create an instance of {@link PartnerLinks }
     *
     */
    public PartnerLinks createTPartnerLinks() {
        return new PartnerLinks();
    }

    /**
     * Create an instance of {@link RepeatUntil }
     *
     */
    public RepeatUntil createTRepeatUntil() {
        return new RepeatUntil();
    }

    /**
     * Create an instance of {@link Elseif }
     *
     */
    public Elseif createTElseif() {
        return new Elseif();
    }

    /**
     * Create an instance of {@link OnMessage }
     *
     */
    public OnMessage createTOnMessage() {
        return new OnMessage();
    }

    /**
     * Create an instance of {@link Compensate }
     *
     */
    public Compensate createTCompensate() {
        return new Compensate();
    }

    /**
     * Create an instance of {@link Scope }
     *
     */
    public Scope createScope() {
        return new Scope();
    }

    public Scope createScope(String name) {
        return new Scope(name);
    }

    /**
     * Create an instance of {@link Query }
     *
     */
    public Query createTQuery() {
        return new Query();
    }

    /**
     * Create an instance of {@link Link }
     *
     */
    public Link createTLink() {
        return new Link();
    }

    /**
     * Create an instance of {@link Catch }
     *
     */
    public Catch createTCatch() {
        return new Catch();
    }

    /**
     * Create an instance of {@link CorrelationSets }
     *
     */
    public CorrelationSets createTCorrelationSets() {
        return new CorrelationSets();
    }

    /**
     * Create an instance of {@link MessageExchanges }
     *
     */
    public MessageExchanges createTMessageExchanges() {
        return new MessageExchanges();
    }

    /**
     * Create an instance of {@link From }
     *
     */
    public From createTFrom() {
        return new From.FromBuilder().createFrom();
    }

    /**
     * Create an instance of {@link While }
     *
     */
    public While createTWhile() {
        return new While();
    }

    /**
     * Create an instance of {@link Throw }
     *
     */
    public Throw createTThrow() {
        return new Throw();
    }

    /**
     * Create an instance of {@link If }
     *
     */
    public If createTIf() {
        return new If();
    }

    /**
     * Create an instance of {@link Reply }
     *
     */
    public Reply createTReply() {
        return new Reply();
    }

    /**
     * Create an instance of {@link ToParts }
     *
     */
    public ToParts createTToParts() {
        return new ToParts();
    }

    /**
     * Create an instance of {@link Pick }
     *
     */
    public Pick createTPick() {
        return new Pick();
    }

    /**
     * Create an instance of {@link Receive }
     *
     */
    public Receive createTReceive() {
        return new Receive();
    }

    /**
     * Create an instance of {@link Targets }
     *
     */
    public Targets createTTargets() {
        return new Targets();
    }

    /**
     * Create an instance of {@link Links }
     *
     */
    public Links createTLinks() {
        return new Links();
    }

    /**
     * Create an instance of {@link FromPart }
     *
     */
    public FromPart createTFromPart() {
        return new FromPart();
    }

    /**
     * Create an instance of {@link OnEvent }
     *
     */
    public OnEvent createTOnEvent() {
        return new OnEvent();
    }

    /**
     * Create an instance of {@link Process }
     *
     */
    public Process createProcess() {
        return new Process();
    }

    /**
     * Create an instance of {@link Extension }
     *
     */
    public Extension createTExtension() {
        return new Extension();
    }

    /**
     * Create an instance of {@link Source }
     *
     */
    public Source createTSource() {
        return new Source();
    }

    /**
     * Create an instance of {@link EventHandlers }
     *
     */
    public EventHandlers createTEventHandlers() {
        return new EventHandlers();
    }

    /**
     * Create an instance of {@link ExtensionActivity }
     *
     */
    public ExtensionActivity createTExtensionActivity() {
        return new ExtensionActivity();
    }

    /**
     * Create an instance of {@link Sequence }
     *
     */
    public Sequence createSequence() {
        return new Sequence();
    }

    public Sequence createSequence(String name) {
        return new Sequence(name);
    }


    /**
     * Create an instance of {@link Invoke }
     *
     */
    public Invoke createTInvoke() {
        return new Invoke();
    }

    /**
     * Create an instance of {@link Target }
     *
     */
    public Target createTTarget() {
        return new Target();
    }

    /**
     * Create an instance of {@link Documentation }
     *
     */
    public Documentation createTDocumentation() {
        return new Documentation();
    }

    /**
     * Create an instance of {@link FaultHandlers }
     *
     */
    public FaultHandlers createTFaultHandlers() {
        return new FaultHandlers();
    }

    /**
     * Create an instance of {@link MessageExchange }
     *
     */
    public MessageExchange createTMessageExchange() {
        return new MessageExchange();
    }

    /**
     * Create an instance of {@link Variable }
     *
     */
    public Variable createVariable() {
        return new Variable();
    }

    public Variable createVariable(String name , ExtendedQName xqname) {
        return new Variable( name,xqname);
    }

    /**
     * Create an instance of {@link Literal }
     *
     */
    public Literal createTLiteral() {
        return new Literal();
    }

    /**
     * Create an instance of {@link OnMsgCommon }
     *
     */
    public OnMsgCommon createTOnMsgCommon() {
        return new OnMsgCommon();
    }

    /**
     * Create an instance of {@link ExtensibleElements }
     *
     */
    public ExtensibleElements createTExtensibleElements() {
        return new ExtensibleElements();
    }

    /**
     * Create an instance of {@link Activity }
     *
     */
    public Activity createTActivity() {
        return new Activity();
    }

    /**
     * Create an instance of {@link OnAlarmPick }
     *
     */
    public OnAlarmPick createTOnAlarmPick() {
        return new OnAlarmPick();
    }

    /**
     * Create an instance of {@link Correlation }
     *
     */
    public Correlation createTCorrelation() {
        return new Correlation();
    }

    /**
     * Create an instance of {@link CorrelationWithPattern }
     *
     */
    public CorrelationWithPattern createTCorrelationWithPattern() {
        return new CorrelationWithPattern();
    }

    /**
     * Create an instance of {@link OnAlarmEvent }
     *
     */
    public OnAlarmEvent createTOnAlarmEvent() {
        return new OnAlarmEvent();
    }

    /**
     * Create an instance of {@link CorrelationsWithPattern }
     *
     */
    public CorrelationsWithPattern createTCorrelationsWithPattern() {
        return new CorrelationsWithPattern();
    }

    /**
     * Create an instance of {@link Correlations }
     *
     */
    public Correlations createTCorrelations() {
        return new Correlations();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Query }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "query")
    public JAXBElement<Query> createQuery(Query value) {
        return new JAXBElement<Query>(_Query_QNAME, Query.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Link }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "link")
    public JAXBElement<Link> createLink(Link value) {
        return new JAXBElement<Link>(_Link_QNAME, Link.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Scope }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "scope")
    public JAXBElement<Scope> createScope(Scope value) {
        return new JAXBElement<Scope>(_Scope_QNAME, Scope.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link While }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "while")
    public JAXBElement<While> createWhile(While value) {
        return new JAXBElement<While>(_While_QNAME, While.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DurationExpr }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "repeatEvery")
    public JAXBElement<DurationExpr> createRepeatEvery(DurationExpr value) {
        return new JAXBElement<DurationExpr>(_RepeatEvery_QNAME, DurationExpr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Catch }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "catch")
    public JAXBElement<Catch> createCatch(Catch value) {
        return new JAXBElement<Catch>(_Catch_QNAME, Catch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CorrelationSets }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "correlationSets")
    public JAXBElement<CorrelationSets> createCorrelationSets(CorrelationSets value) {
        return new JAXBElement<CorrelationSets>(_CorrelationSets_QNAME, CorrelationSets.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageExchanges }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "messageExchanges")
    public JAXBElement<MessageExchanges> createMessageExchanges(MessageExchanges value) {
        return new JAXBElement<MessageExchanges>(_MessageExchanges_QNAME, MessageExchanges.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link From }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "from")
    public JAXBElement<From> createFrom(From value) {
        return new JAXBElement<From>(_From_QNAME, From.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link If }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "if")
    public JAXBElement<If> createIf(If value) {
        return new JAXBElement<If>(_If_QNAME, If.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Throw }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "throw")
    public JAXBElement<Throw> createThrow(Throw value) {
        return new JAXBElement<Throw>(_Throw_QNAME, Throw.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Receive }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "receive")
    public JAXBElement<Receive> createReceive(Receive value) {
        return new JAXBElement<Receive>(_Receive_QNAME, Receive.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Targets }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "targets")
    public JAXBElement<Targets> createTargets(Targets value) {
        return new JAXBElement<Targets>(_Targets_QNAME, Targets.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ToParts }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "toParts")
    public JAXBElement<ToParts> createToParts(ToParts value) {
        return new JAXBElement<ToParts>(_ToParts_QNAME, ToParts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Reply }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "reply")
    public JAXBElement<Reply> createReply(Reply value) {
        return new JAXBElement<Reply>(_Reply_QNAME, Reply.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pick }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "pick")
    public JAXBElement<Pick> createPick(Pick value) {
        return new JAXBElement<Pick>(_Pick_QNAME, Pick.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Expression }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "finalCounterValue")
    public JAXBElement<Expression> createFinalCounterValue(Expression value) {
        return new JAXBElement<Expression>(_FinalCounterValue_QNAME, Expression.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Links }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "links")
    public JAXBElement<Links> createLinks(Links value) {
        return new JAXBElement<Links>(_Links_QNAME, Links.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FromPart }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "fromPart")
    public JAXBElement<FromPart> createFromPart(FromPart value) {
        return new JAXBElement<FromPart>(_FromPart_QNAME, FromPart.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Source }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "source")
    public JAXBElement<Source> createSource(Source value) {
        return new JAXBElement<Source>(_Source_QNAME, Source.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtensionActivity }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "extensionActivity")
    public JAXBElement<ExtensionActivity> createExtensionActivity(ExtensionActivity value) {
        return new JAXBElement<ExtensionActivity>(_ExtensionActivity_QNAME, ExtensionActivity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EventHandlers }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "eventHandlers")
    public JAXBElement<EventHandlers> createEventHandlers(EventHandlers value) {
        return new JAXBElement<EventHandlers>(_EventHandlers_QNAME, EventHandlers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Invoke }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "invoke")
    public JAXBElement<Invoke> createInvoke(Invoke value) {
        return new JAXBElement<Invoke>(_Invoke_QNAME, Invoke.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sequence }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "sequence")
    public JAXBElement<Sequence> createSequence(Sequence value) {
        return new JAXBElement<Sequence>(_Sequence_QNAME, Sequence.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Extension }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "extension")
    public JAXBElement<Extension> createExtension(Extension value) {
        return new JAXBElement<Extension>(_Extension_QNAME, Extension.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Process }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "process")
    public JAXBElement<Process> createProcess(Process value) {
        return new JAXBElement<Process>(_Process_QNAME, Process.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnEvent }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "onEvent")
    public JAXBElement<OnEvent> createOnEvent(OnEvent value) {
        return new JAXBElement<OnEvent>(_OnEvent_QNAME, OnEvent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActivityContainer }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "catchAll")
    public JAXBElement<ActivityContainer> createCatchAll(ActivityContainer value) {
        return new JAXBElement<ActivityContainer>(_CatchAll_QNAME, ActivityContainer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageExchange }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "messageExchange")
    public JAXBElement<MessageExchange> createMessageExchange(MessageExchange value) {
        return new JAXBElement<MessageExchange>(_MessageExchange_QNAME, MessageExchange.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Variable }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "variable")
    public JAXBElement<Variable> createVariable(Variable value) {
        return new JAXBElement<Variable>(_Variable_QNAME, Variable.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Literal }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "literal")
    public JAXBElement<Literal> createLiteral(Literal value) {
        return new JAXBElement<Literal>(_Literal_QNAME, Literal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Documentation }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "documentation")
    public JAXBElement<Documentation> createDocumentation(Documentation value) {
        return new JAXBElement<Documentation>(_Documentation_QNAME, Documentation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Target }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "target")
    public JAXBElement<Target> createTarget(Target value) {
        return new JAXBElement<Target>(_Target_QNAME, Target.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaultHandlers }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "faultHandlers")
    public JAXBElement<FaultHandlers> createFaultHandlers(FaultHandlers value) {
        return new JAXBElement<FaultHandlers>(_FaultHandlers_QNAME, FaultHandlers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DurationExpr }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "for")
    public JAXBElement<DurationExpr> createFor(DurationExpr value) {
        return new JAXBElement<DurationExpr>(_For_QNAME, DurationExpr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link To }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "to")
    public JAXBElement<To> createTo(To value) {
        return new JAXBElement<To>(_To_QNAME, To.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Assign }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "assign")
    public JAXBElement<Assign> createAssign(Assign value) {
        return new JAXBElement<Assign>(_Assign_QNAME, Assign.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Extensions }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "extensions")
    public JAXBElement<Extensions> createExtensions(Extensions value) {
        return new JAXBElement<Extensions>(_Extensions_QNAME, Extensions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Validate }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "validate")
    public JAXBElement<Validate> createValidate(Validate value) {
        return new JAXBElement<Validate>(_Validate_QNAME, Validate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sources }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "sources")
    public JAXBElement<Sources> createSources(Sources value) {
        return new JAXBElement<Sources>(_Sources_QNAME, Sources.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeadlineExpr }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "until")
    public JAXBElement<DeadlineExpr> createUntil(DeadlineExpr value) {
        return new JAXBElement<DeadlineExpr>(_Until_QNAME, DeadlineExpr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CompletionCondition }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "completionCondition")
    public JAXBElement<CompletionCondition> createCompletionCondition(CompletionCondition value) {
        return new JAXBElement<CompletionCondition>(_CompletionCondition_QNAME, CompletionCondition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Expression }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "startCounterValue")
    public JAXBElement<Expression> createStartCounterValue(Expression value) {
        return new JAXBElement<Expression>(_StartCounterValue_QNAME, Expression.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Condition }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "joinCondition")
    public JAXBElement<Condition> createJoinCondition(Condition value) {
        return new JAXBElement<Condition>(_JoinCondition_QNAME, Condition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Wait }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "wait")
    public JAXBElement<Wait> createWait(Wait value) {
        return new JAXBElement<Wait>(_Wait_QNAME, Wait.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActivityContainer }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "compensationHandler")
    public JAXBElement<ActivityContainer> createCompensationHandler(ActivityContainer value) {
        return new JAXBElement<ActivityContainer>(_CompensationHandler_QNAME, ActivityContainer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartnerLink }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "partnerLink")
    public JAXBElement<PartnerLink> createPartnerLink(PartnerLink value) {
        return new JAXBElement<PartnerLink>(_PartnerLink_QNAME, PartnerLink.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Flow }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "flow")
    public JAXBElement<Flow> createFlow(Flow value) {
        return new JAXBElement<Flow>(_Flow_QNAME, Flow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtensionAssignOperation }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "extensionAssignOperation")
    public JAXBElement<ExtensionAssignOperation> createExtensionAssignOperation(ExtensionAssignOperation value) {
        return new JAXBElement<ExtensionAssignOperation>(_ExtensionAssignOperation_QNAME, ExtensionAssignOperation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FromParts }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "fromParts")
    public JAXBElement<FromParts> createFromParts(FromParts value) {
        return new JAXBElement<FromParts>(_FromParts_QNAME, FromParts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Branches }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "branches")
    public JAXBElement<Branches> createBranches(Branches value) {
        return new JAXBElement<Branches>(_Branches_QNAME, Branches.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Copy }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "copy")
    public JAXBElement<Copy> createCopy(Copy value) {
        return new JAXBElement<Copy>(_Copy_QNAME, Copy.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Empty }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "empty")
    public JAXBElement<Empty> createEmpty(Empty value) {
        return new JAXBElement<Empty>(_Empty_QNAME, Empty.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Import }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "import")
    public JAXBElement<Import> createImport(Import value) {
        return new JAXBElement<Import>(_Import_QNAME, Import.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ToPart }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "toPart")
    public JAXBElement<ToPart> createToPart(ToPart value) {
        return new JAXBElement<ToPart>(_ToPart_QNAME, ToPart.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanExpr }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "condition")
    public JAXBElement<BooleanExpr> createCondition(BooleanExpr value) {
        return new JAXBElement<BooleanExpr>(_Condition_QNAME, BooleanExpr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ForEach }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "forEach")
    public JAXBElement<ForEach> createForEach(ForEach value) {
        return new JAXBElement<ForEach>(_ForEach_QNAME, ForEach.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActivityContainer }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "else")
    public JAXBElement<ActivityContainer> createElse(ActivityContainer value) {
        return new JAXBElement<ActivityContainer>(_Else_QNAME, ActivityContainer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Rethrow }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "rethrow")
    public JAXBElement<Rethrow> createRethrow(Rethrow value) {
        return new JAXBElement<Rethrow>(_Rethrow_QNAME, Rethrow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CorrelationSet }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "correlationSet")
    public JAXBElement<CorrelationSet> createCorrelationSet(CorrelationSet value) {
        return new JAXBElement<CorrelationSet>(_CorrelationSet_QNAME, CorrelationSet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CompensateScope }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "compensateScope")
    public JAXBElement<CompensateScope> createCompensateScope(CompensateScope value) {
        return new JAXBElement<CompensateScope>(_CompensateScope_QNAME, CompensateScope.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Exit }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "exit")
    public JAXBElement<Exit> createExit(Exit value) {
        return new JAXBElement<Exit>(_Exit_QNAME, Exit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Variables }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "variables")
    public JAXBElement<Variables> createVariables(Variables value) {
        return new JAXBElement<Variables>(_Variables_QNAME, Variables.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActivityContainer }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "terminationHandler")
    public JAXBElement<ActivityContainer> createTerminationHandler(ActivityContainer value) {
        return new JAXBElement<ActivityContainer>(_TerminationHandler_QNAME, ActivityContainer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartnerLinks }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "partnerLinks")
    public JAXBElement<PartnerLinks> createPartnerLinks(PartnerLinks value) {
        return new JAXBElement<PartnerLinks>(_PartnerLinks_QNAME, PartnerLinks.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RepeatUntil }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "repeatUntil")
    public JAXBElement<RepeatUntil> createRepeatUntil(RepeatUntil value) {
        return new JAXBElement<RepeatUntil>(_RepeatUntil_QNAME, RepeatUntil.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Compensate }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "compensate")
    public JAXBElement<Compensate> createCompensate(Compensate value) {
        return new JAXBElement<Compensate>(_Compensate_QNAME, Compensate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Condition }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "transitionCondition")
    public JAXBElement<Condition> createTransitionCondition(Condition value) {
        return new JAXBElement<Condition>(_TransitionCondition_QNAME, Condition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Elseif }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "elseif")
    public JAXBElement<Elseif> createElseif(Elseif value) {
        return new JAXBElement<Elseif>(_Elseif_QNAME, Elseif.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnMessage }{@code >}}
     *
     */
    @XmlElementDecl(namespace = "http://docs.oasis-open.org/wsbpel/2.0/process/executable", name = "onMessage")
    public JAXBElement<OnMessage> createOnMessage(OnMessage value) {
        return new JAXBElement<OnMessage>(_OnMessage_QNAME, OnMessage.class, null, value);
    }

}
