package soa.model;

public abstract interface Source
  extends IEndpoint
{}
