package soa.model.binding.file;

import soa.model.soap.Binding;
import soa.model.soap.ConcreteBinding;

public class FileBinding
  extends ConcreteBinding
{
  public FileBinding(Binding binding)
  {
    super(binding);
  }
}
