package soa.model;

public abstract interface Target
  extends IEndpoint
{}
