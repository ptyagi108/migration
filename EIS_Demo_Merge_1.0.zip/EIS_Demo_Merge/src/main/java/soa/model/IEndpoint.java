package soa.model;

abstract interface IEndpoint
{
  public abstract String getUri();
}
