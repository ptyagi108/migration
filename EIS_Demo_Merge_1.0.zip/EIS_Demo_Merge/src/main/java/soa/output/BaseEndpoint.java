package soa.output;

abstract interface BaseEndpoint
{
  public abstract String getUniqueName();
}
